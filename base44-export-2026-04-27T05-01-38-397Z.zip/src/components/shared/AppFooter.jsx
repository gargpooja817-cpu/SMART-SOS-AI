import React from 'react';
import { Link } from 'react-router-dom';
import { Radio, CheckCircle, Github, Twitter } from 'lucide-react';

export default function AppFooter() {
  return (
    <footer className="border-t border-white/[0.05] mt-auto py-6 px-4 sm:px-6">
      <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded-lg" style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }} />
          <span className="font-grotesk font-black text-foreground">NeuraRescue</span>
          <span className="text-muted-foreground">© {new Date().getFullYear()}</span>
        </div>

        {/* Links */}
        <div className="flex items-center gap-4">
          <Link to="/about" className="hover:text-foreground transition-colors">About</Link>
          <Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link>
          <Link to="/responders" className="hover:text-foreground transition-colors">Responders</Link>
        </div>

        {/* Status */}
        <div className="flex items-center gap-1.5">
          <CheckCircle className="w-3 h-3 text-neon-green" />
          <span className="text-neon-green font-semibold">All systems operational</span>
        </div>
      </div>
    </footer>
  );
}