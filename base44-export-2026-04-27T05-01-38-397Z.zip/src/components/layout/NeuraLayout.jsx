import React, { useState, useEffect } from 'react';
import { Outlet, Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Users, Home, Menu, X, Bell, Radio, Wifi, WifiOff, ChevronRight
} from 'lucide-react';
import LivePulse from '@/components/ui/LivePulse';

const nav = [
  { path: '/', icon: Home, label: 'Home', exact: true },
  { path: '/dashboard', icon: LayoutDashboard, label: 'Command Center' },
  { path: '/responders', icon: Users, label: 'Responder Panel' },
];

export default function NeuraLayout() {
  const [open, setOpen] = useState(false);
  const [online, setOnline] = useState(navigator.onLine);
  const [time, setTime] = useState(new Date());
  const loc = useLocation();

  useEffect(() => {
    const onOnline = () => setOnline(true);
    const onOffline = () => setOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => { window.removeEventListener('online', onOnline); window.removeEventListener('offline', onOffline); };
  }, []);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const isActive = (path, exact) => exact ? loc.pathname === path : loc.pathname.startsWith(path);

  return (
    <div className="min-h-screen bg-background scanline">
      {/* Header */}
      <header className="fixed top-0 inset-x-0 z-50 glass-strong h-14 flex items-center justify-between px-4 md:px-6 border-b border-white/[0.06]">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <button className="md:hidden p-1.5 rounded-lg hover:bg-white/5 transition-colors" onClick={() => setOpen(v => !v)}>
            {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="relative w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
              <Radio className="w-4 h-4 text-white" />
              <div className="absolute inset-0 rounded-xl" style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', filter: 'blur(8px)', opacity: 0.5, zIndex: -1 }} />
            </div>
            <div>
              <span className="font-grotesk text-sm font-800 tracking-tight">
                <span className="text-gradient-neon font-black">Neura</span>
                <span className="text-foreground font-black">Rescue</span>
              </span>
              <span className="hidden md:block text-[9px] text-muted-foreground tracking-widest uppercase font-mono">Smart SOS AI+</span>
            </div>
          </Link>
        </div>

        {/* Center nav — desktop */}
        <nav className="hidden md:flex items-center gap-1">
          {nav.map(({ path, icon: Icon, label, exact }) => (
            <Link
              key={path}
              to={path}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-200 ${
                isActive(path, exact)
                  ? 'bg-white/8 text-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {label}
            </Link>
          ))}
        </nav>

        {/* Right */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-2">
            {online
              ? <LivePulse label="Online" color="green" />
              : <span className="flex items-center gap-1 text-[10px] text-neon-yellow font-bold tracking-wider"><WifiOff className="w-3 h-3" /> OFFLINE</span>
            }
          </div>
          <span className="hidden lg:block text-xs font-mono text-muted-foreground bg-white/5 px-3 py-1 rounded-lg">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </span>
          <button className="relative p-2 rounded-xl hover:bg-white/5 transition-colors">
            <Bell className="w-4 h-4 text-muted-foreground" />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-neon-red shadow-neon-red" />
          </button>
        </div>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm md:hidden"
              onClick={() => setOpen(false)}
            />
            <motion.aside
              initial={{ x: '-100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 left-0 bottom-0 z-50 w-72 glass-strong border-r border-white/[0.06] md:hidden flex flex-col pt-4 pb-8 px-4"
            >
              <div className="flex items-center justify-between mb-8 px-2">
                <span className="text-gradient-neon font-grotesk font-black text-xl">NeuraRescue</span>
                <button onClick={() => setOpen(false)} className="p-1.5 hover:bg-white/5 rounded-lg"><X className="w-5 h-5" /></button>
              </div>
              <nav className="space-y-1">
                {nav.map(({ path, icon: Icon, label, exact }) => (
                  <Link
                    key={path}
                    to={path}
                    onClick={() => setOpen(false)}
                    className={`flex items-center justify-between px-4 py-3.5 rounded-xl text-sm font-semibold transition-all ${
                      isActive(path, exact)
                        ? 'bg-gradient-to-r from-neon-cyan/10 to-neon-purple/10 text-foreground border border-neon-cyan/20'
                        : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center gap-3"><Icon className="w-5 h-5" />{label}</div>
                    <ChevronRight className="w-4 h-4 opacity-40" />
                  </Link>
                ))}
              </nav>
              <div className="mt-auto glass-card rounded-2xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  {online ? <LivePulse label="All Systems Operational" color="green" /> : <span className="text-xs text-neon-yellow">⚡ Offline Mode</span>}
                </div>
                <p className="text-xs text-muted-foreground">{time.toLocaleString()}</p>
              </div>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Main */}
      <main className="pt-14 min-h-screen">
        <Outlet />
      </main>
    </div>
  );
}