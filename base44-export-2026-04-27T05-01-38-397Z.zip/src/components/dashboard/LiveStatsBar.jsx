import React from 'react';
import { AlertTriangle, CheckCircle, Clock, Users } from 'lucide-react';
import StatCard from '@/components/shared/StatCard';

export default function LiveStatsBar({ alerts = [], responders = [] }) {
  const active = alerts.filter(a => ['pending', 'assigned', 'in_progress'].includes(a.status)).length;
  const critical = alerts.filter(a => a.priority === 'critical' && a.status !== 'resolved').length;
  const resolved = alerts.filter(a => a.status === 'resolved').length;
  const availableResponders = responders.filter(r => r.status === 'available').length;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      <StatCard icon={AlertTriangle} label="Active Alerts" value={active} color="text-red-400" trend={12} />
      <StatCard icon={Clock} label="Critical" value={critical} color="text-orange-400" />
      <StatCard icon={CheckCircle} label="Resolved" value={resolved} color="text-green-400" trend={-8} />
      <StatCard icon={Users} label="Responders Online" value={availableResponders} color="text-blue-400" />
    </div>
  );
}