import React from 'react';

const FILTERS = [
  { key: 'all',      label: 'All',       icon: '🗺️' },
  { key: 'hospital', label: 'Hospitals', icon: '🏥' },
  { key: 'clinic',   label: 'Clinics',   icon: '🩺' },
  { key: 'pharmacy', label: 'Pharmacies',icon: '💊' },
];

export default function FilterBar({ active, onChange, total }) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      {FILTERS.map(f => (
        <button
          key={f.key}
          onClick={() => onChange(f.key)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all"
          style={active === f.key
            ? { background: 'rgba(0,198,255,0.15)', border: '1px solid rgba(0,198,255,0.4)', color: '#00C6FF' }
            : { background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', color: '#888' }
          }
        >
          <span>{f.icon}</span> {f.label}
        </button>
      ))}
      <span className="ml-auto text-[10px] text-muted-foreground">{total} found</span>
    </div>
  );
}