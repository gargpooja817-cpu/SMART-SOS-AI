import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, MapPin, User, Phone, WifiOff, ShieldAlert } from 'lucide-react';
import { format } from 'date-fns';
import UrgencyBadge from '@/components/shared/UrgencyBadge';
import AlertTypeIcon from '@/components/shared/AlertTypeIcon';
import { Badge } from '@/components/ui/badge';

export default function AlertsList({ alerts = [], onSelectAlert }) {
  if (alerts.length === 0) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <ShieldAlert className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-40" />
        <p className="text-sm text-muted-foreground">No active alerts</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <AnimatePresence>
        {alerts.map((alert, index) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            transition={{ delay: index * 0.05 }}
            onClick={() => onSelectAlert && onSelectAlert(alert)}
            className={`glass rounded-xl p-4 cursor-pointer hover:bg-white/[0.04] transition-all duration-200 border-l-2 ${
              alert.priority === 'critical' ? 'border-l-red-500' :
              alert.priority === 'high' ? 'border-l-orange-500' :
              alert.priority === 'medium' ? 'border-l-yellow-500' : 'border-l-green-500'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 min-w-0 flex-1">
                <div className="mt-0.5">
                  <AlertTypeIcon type={alert.alert_type} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <UrgencyBadge priority={alert.priority} />
                    {alert.is_fake && (
                      <Badge variant="outline" className="text-[10px] border-red-500/30 text-red-400 bg-red-500/10">
                        FLAGGED
                      </Badge>
                    )}
                    {alert.offline_mode && (
                      <WifiOff className="w-3.5 h-3.5 text-yellow-400" />
                    )}
                    <Badge variant="outline" className="text-[10px] border-white/10 text-muted-foreground capitalize">
                      {alert.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-foreground truncate">{alert.message}</p>
                  <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                    {alert.reporter_name && (
                      <span className="flex items-center gap-1">
                        <User className="w-3 h-3" /> {alert.reporter_name}
                      </span>
                    )}
                    {alert.address && (
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {alert.address}
                      </span>
                    )}
                  </div>
                </div>
              </div>
              <div className="text-right shrink-0">
                <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {alert.created_date ? format(new Date(alert.created_date), 'h:mm a') : ''}
                </span>
                {alert.urgency_score != null && (
                  <div className="mt-1 text-xs font-mono font-bold text-foreground">
                    {alert.urgency_score}
                    <span className="text-muted-foreground font-normal">/100</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}