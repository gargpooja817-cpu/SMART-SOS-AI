import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, Users, Shield, User, Radio, Heart } from 'lucide-react';
import { useNeuraAuth } from '@/lib/authContext';

export default function MobileBottomNav() {
  const loc = useLocation();
  const { user } = useNeuraAuth();
  const role = user?.role || 'user';

  const allLinks = [
    { path: '/dashboard', icon: LayoutDashboard, label: 'Home', roles: ['user', 'admin', 'responder'] },
    { path: '/nearby', icon: Heart, label: 'Nearby', roles: ['user', 'admin', 'responder'] },
    { path: '/responders', icon: Radio, label: 'Dispatch', roles: ['responder', 'admin'] },
    { path: '/admin', icon: Shield, label: 'Admin', roles: ['admin'] },
    { path: '/profile', icon: User, label: 'Profile', roles: ['user', 'admin', 'responder'] },
  ];

  const links = allLinks.filter(l => l.roles.includes(role));

  return (
    <div className="fixed bottom-0 inset-x-0 z-50 md:hidden" style={{ background: 'rgba(8,11,22,0.95)', backdropFilter: 'blur(30px)', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
      <div className="flex items-center justify-around px-2 py-2 safe-area-pb">
        {links.map(link => {
          const active = loc.pathname === link.path;
          return (
            <Link key={`${link.path}-${link.label}`} to={link.path} className="flex-1">
              <div className="flex flex-col items-center gap-1 py-1 relative">
                {active && (
                  <motion.div layoutId="nav-pill" className="absolute inset-0 rounded-xl mx-1"
                    style={{ background: 'rgba(0,198,255,0.1)' }}
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }} />
                )}
                <div className={`relative z-10 p-1 rounded-lg transition-colors ${active ? 'text-neon-cyan' : 'text-muted-foreground'}`}>
                  <link.icon className="w-5 h-5" />
                  {active && <span className="absolute -bottom-0.5 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-neon-cyan" style={{ boxShadow: '0 0 6px #00C6FF' }} />}
                </div>
                <span className={`text-[9px] font-semibold relative z-10 ${active ? 'text-neon-cyan' : 'text-muted-foreground'}`}>{link.label}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}