import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, MapPin, User, ChevronDown, ChevronUp, AlertOctagon, WifiOff, ShieldCheck } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import NeuraBadge from '@/components/ui/NeuraBadge';
import ConfidenceMeter from '@/components/ui/ConfidenceMeter';
import ResourceChips from '@/components/ui/ResourceChips';
import { CATEGORY_CONFIG } from '@/lib/aiEngine';

const priorityBorderClass = { critical: 'priority-critical', high: 'priority-high', medium: 'priority-medium', low: 'priority-low' };

function AlertRow({ alert, index }) {
  const [expanded, setExpanded] = useState(false);
  const cat = CATEGORY_CONFIG[alert.alert_type] || CATEGORY_CONFIG.general;

  return (
    <motion.div
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 20 }}
      transition={{ delay: index * 0.04 }}
      className={`glass-card rounded-xl overflow-hidden ${priorityBorderClass[alert.priority] || 'priority-low'} ${
        alert.is_fake ? 'opacity-50' : ''
      }`}
    >
      <div
        className="p-3.5 cursor-pointer hover:bg-white/[0.02] transition-colors"
        onClick={() => setExpanded(v => !v)}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5 min-w-0 flex-1">
            <span className="text-xl mt-0.5 shrink-0">{cat.icon}</span>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <NeuraBadge priority={alert.priority} />
                {alert.is_fake && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-neon-yellow/10 text-neon-yellow border border-neon-yellow/20">
                    <AlertOctagon className="w-3 h-3" /> FLAGGED
                  </span>
                )}
                {alert.offline_mode && <WifiOff className="w-3 h-3 text-neon-yellow" />}
                {alert.status === 'resolved' && <ShieldCheck className="w-3.5 h-3.5 text-neon-green" />}
                <span className="text-[10px] text-muted-foreground capitalize">{alert.status}</span>
              </div>
              <p className="text-xs text-foreground/90 line-clamp-1">{alert.message}</p>
              <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground">
                {alert.reporter_name && <span className="flex items-center gap-1"><User className="w-3 h-3" />{alert.reporter_name}</span>}
                {alert.address && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{alert.address}</span>}
              </div>
            </div>
          </div>
          <div className="shrink-0 text-right flex flex-col items-end gap-1">
            <span className="text-[10px] text-muted-foreground flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {alert.created_date ? formatDistanceToNow(new Date(alert.created_date), { addSuffix: true }) : ''}
            </span>
            {alert.urgency_score != null && (
              <span className="text-xs font-mono font-bold text-foreground">{alert.urgency_score}<span className="text-muted-foreground font-normal">/100</span></span>
            )}
            {expanded ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground mt-1" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground mt-1" />}
          </div>
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-3.5 pb-3.5 border-t border-white/[0.04]"
          >
            <div className="pt-3 space-y-3">
              <ConfidenceMeter score={alert.urgency_score || 0} label="Urgency Score" />
              {alert.assigned_responder_name && (
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Assigned to</span>
                  <span className="text-neon-cyan font-semibold">{alert.assigned_responder_name}</span>
                </div>
              )}
              {alert.fake_reason && (
                <div className="text-[10px] text-neon-yellow bg-neon-yellow/5 border border-neon-yellow/15 rounded-lg px-3 py-2">
                  ⚠️ {alert.fake_reason}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function AlertFeed({ alerts = [] }) {
  const [filter, setFilter] = useState('all');
  const filters = [
    { key: 'all', label: 'All' },
    { key: 'critical', label: '🔴 Critical' },
    { key: 'high', label: '🟠 High' },
    { key: 'medium', label: '🟡 Medium' },
    { key: 'pending', label: 'Pending' },
    { key: 'fake', label: 'Flagged' },
  ];

  const filtered = filter === 'all' ? alerts :
    filter === 'fake' ? alerts.filter(a => a.is_fake) :
    filter === 'pending' ? alerts.filter(a => a.status === 'pending') :
    alerts.filter(a => a.priority === filter);

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-3 scrollbar-none">
        {filters.map(f => (
          <button key={f.key} onClick={() => setFilter(f.key)}
            className={`shrink-0 px-3 py-1 rounded-lg text-[10px] font-semibold transition-all ${
              filter === f.key
                ? 'bg-neon-cyan/15 text-neon-cyan border border-neon-cyan/30'
                : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto space-y-2 pr-0.5">
        <AnimatePresence>
          {filtered.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">No alerts found</div>
          ) : (
            filtered.map((a, i) => <AlertRow key={a.id} alert={a} index={i} />)
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}