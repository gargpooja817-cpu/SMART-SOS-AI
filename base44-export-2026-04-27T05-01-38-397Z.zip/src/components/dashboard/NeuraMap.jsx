import React, { useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, ZoomControl } from 'react-leaflet';
import { PRIORITY_CONFIG, CATEGORY_CONFIG } from '@/lib/aiEngine';
import NeuraBadge from '@/components/ui/NeuraBadge';
import { format } from 'date-fns';
import 'leaflet/dist/leaflet.css';

const priorityHex = {
  critical: '#FF2D55',
  high: '#FF6B2B',
  medium: '#FFD60A',
  low: '#00FF88',
};

export default function NeuraMap({ alerts = [], responders = [], height = '100%', center = [40.7128, -74.006] }) {
  const [activeAlert, setActiveAlert] = useState(null);
  const visible = alerts.filter(a => a.latitude && a.longitude && a.status !== 'fake');

  return (
    <div className="relative rounded-2xl overflow-hidden border border-white/[0.06]" style={{ height }}>
      <MapContainer center={center} zoom={12} style={{ height: '100%', width: '100%' }} zoomControl={false}>
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        />
        <ZoomControl position="bottomright" />

        {/* Heatmap aura */}
        {visible.map(a => (
          <CircleMarker key={`aura-${a.id}`}
            center={[a.latitude, a.longitude]}
            radius={a.priority === 'critical' ? 50 : a.priority === 'high' ? 38 : a.priority === 'medium' ? 26 : 18}
            pathOptions={{ color: 'transparent', fillColor: priorityHex[a.priority] || '#FFD60A', fillOpacity: 0.07 }}
          />
        ))}
        {/* Medium heatmap */}
        {visible.map(a => (
          <CircleMarker key={`mid-${a.id}`}
            center={[a.latitude, a.longitude]}
            radius={a.priority === 'critical' ? 28 : a.priority === 'high' ? 20 : 12}
            pathOptions={{ color: 'transparent', fillColor: priorityHex[a.priority] || '#FFD60A', fillOpacity: 0.12 }}
          />
        ))}

        {/* Alert dots */}
        {visible.map(a => (
          <CircleMarker key={a.id}
            center={[a.latitude, a.longitude]}
            radius={7}
            pathOptions={{
              color: priorityHex[a.priority] || '#FFD60A',
              fillColor: priorityHex[a.priority] || '#FFD60A',
              fillOpacity: 0.95,
              weight: 2,
              opacity: 1,
            }}
            eventHandlers={{ click: () => setActiveAlert(a) }}
          >
            <Popup>
              <div className="min-w-[200px] space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-base">{CATEGORY_CONFIG[a.alert_type]?.icon || '⚠️'}</span>
                  <div>
                    <p className="font-bold text-xs capitalize">{(a.alert_type || 'general').replace('_', ' ')}</p>
                    <NeuraBadge priority={a.priority} size="sm" />
                  </div>
                </div>
                <p className="text-xs text-gray-300 leading-relaxed">{a.message}</p>
                {a.reporter_name && <p className="text-[10px] text-gray-500">👤 {a.reporter_name}</p>}
                <p className="text-[10px] text-gray-500">
                  {a.created_date ? format(new Date(a.created_date), 'MMM d, h:mm a') : ''}
                </p>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] text-gray-500">Urgency:</span>
                  <span className="text-[10px] font-mono font-bold text-white">{a.urgency_score}/100</span>
                </div>
              </div>
            </Popup>
          </CircleMarker>
        ))}

        {/* Responder dots */}
        {responders.filter(r => r.latitude && r.longitude && r.status === 'available').map(r => (
          <CircleMarker key={`resp-${r.id}`}
            center={[r.latitude, r.longitude]}
            radius={5}
            pathOptions={{ color: '#00C6FF', fillColor: '#00C6FF', fillOpacity: 0.8, weight: 1.5 }}
          >
            <Popup>
              <div>
                <p className="font-bold text-xs">{r.name}</p>
                <p className="text-[10px] text-gray-400 capitalize">{r.type} • Available</p>
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>

      {/* Overlay legend */}
      <div className="absolute bottom-4 left-4 glass-strong rounded-xl px-3 py-2 flex items-center gap-3 z-[1000]">
        {Object.entries(priorityHex).map(([p, hex]) => (
          <div key={p} className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ background: hex, boxShadow: `0 0 6px ${hex}` }} />
            <span className="text-[9px] text-muted-foreground uppercase tracking-wider">{p}</span>
          </div>
        ))}
        <div className="w-px h-3 bg-white/10" />
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full inline-block bg-neon-cyan" style={{ boxShadow: '0 0 6px #00C6FF' }} />
          <span className="text-[9px] text-muted-foreground">Responder</span>
        </div>
      </div>

      {/* Alert count overlay */}
      <div className="absolute top-4 right-4 glass-strong rounded-xl px-3 py-2 z-[1000]">
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Active Alerts</p>
        <p className="text-xl font-grotesk font-black text-neon-red text-glow-red">{visible.length}</p>
      </div>
    </div>
  );
}