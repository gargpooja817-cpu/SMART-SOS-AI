const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { Users, AlertTriangle, Map, Plus, Loader2, AlertCircle } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import ResponderGrid from '@/components/responders/ResponderGrid';
import AlertDispatch from '@/components/responders/AlertDispatch';
import NeuraMap from '@/components/dashboard/NeuraMap';
import ResponderForm from '@/components/responders/ResponderForm';
import { useNeuraAuth } from '@/lib/authContext';

const SEED_RESPONDERS = [
  { name: 'Dr. Sarah Chen', type: 'doctor', status: 'available', phone: '+1 555-0101', specialization: 'Trauma Surgery', rating: 4.9, total_responses: 234, latitude: 40.7128, longitude: -74.006 },
  { name: 'Officer Mike Torres', type: 'police', status: 'available', phone: '+1 555-0102', specialization: 'Patrol', rating: 4.7, total_responses: 189, latitude: 40.7188, longitude: -74.001 },
  { name: 'Firefighter Jake Lee', type: 'firefighter', status: 'available', phone: '+1 555-0103', specialization: 'Rescue', rating: 4.8, total_responses: 156, latitude: 40.7058, longitude: -74.011 },
  { name: 'Paramedic Ana Ruiz', type: 'paramedic', status: 'available', phone: '+1 555-0104', specialization: 'Advanced Life Support', rating: 4.6, total_responses: 312, latitude: 40.7228, longitude: -73.998 },
  { name: 'Dr. James Okafor', type: 'doctor', status: 'busy', phone: '+1 555-0105', specialization: 'Cardiology', rating: 4.9, total_responses: 97, latitude: 40.7098, longitude: -74.015 },
  { name: 'Officer Lisa Park', type: 'police', status: 'available', phone: '+1 555-0106', specialization: 'Homicide', rating: 4.5, total_responses: 203, latitude: 40.7168, longitude: -73.994 },
  { name: 'Volunteer Tom Wright', type: 'volunteer', status: 'available', phone: '+1 555-0107', specialization: 'First Aid', rating: 4.2, total_responses: 45, latitude: 40.7148, longitude: -74.008 },
  { name: 'Paramedic Chloe Xu', type: 'paramedic', status: 'offline', phone: '+1 555-0108', specialization: 'Pediatric Emergency', rating: 4.8, total_responses: 178, latitude: 40.7208, longitude: -74.003 },
];

export default function Responders() {
  const queryClient = useQueryClient();
  const { user } = useNeuraAuth();
  const isAdmin = user?.role === 'admin';

  const [showForm, setShowForm] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [seeding, setSeeding] = useState(false);

  const { data: responders = [], isLoading: loadingR, isError: respError } = useQuery({
    queryKey: ['responders'],
    queryFn: () => db.entities.Responder.list(),
    refetchInterval: 10000,
    retry: 2,
  });

  const { data: alerts = [], isLoading: loadingAlerts } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => db.entities.Alert.list('-created_date', 100),
    refetchInterval: 4000,
    retry: 2,
  });

  const handleUpdate = () => {
    queryClient.invalidateQueries({ queryKey: ['alerts'] });
    queryClient.invalidateQueries({ queryKey: ['responders'] });
  };

  if (respError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <div className="w-12 h-12 rounded-2xl bg-neon-red/10 border border-neon-red/20 flex items-center justify-center">
          <AlertTriangle className="w-6 h-6 text-neon-red" />
        </div>
        <p className="text-sm text-muted-foreground">Failed to load responder data</p>
        <button onClick={() => queryClient.invalidateQueries({ queryKey: ['responders'] })}
          className="px-4 py-2 glass-card rounded-xl text-xs font-semibold text-neon-cyan border border-neon-cyan/20 hover:bg-white/5 transition-colors">
          Retry
        </button>
      </div>
    );
  }

  const handleDelete = async (r) => {
    if (!window.confirm(`Remove ${r.name} from the system?`)) return;
    try {
      await db.entities.Responder.delete(r.id);
      queryClient.invalidateQueries({ queryKey: ['responders'] });
      toast.success(`${r.name} removed`);
    } catch {
      toast.error('Failed to remove responder.');
    }
  };

  const handleSeedData = async () => {
    setSeeding(true);
    try {
      await db.entities.Responder.bulkCreate(SEED_RESPONDERS);
      queryClient.invalidateQueries({ queryKey: ['responders'] });
      toast.success('Sample responders added!');
    } catch {
      toast.error('Failed to seed responders.');
    } finally {
      setSeeding(false);
    }
  };

  const pendingCount = alerts.filter(a => a.status === 'pending' && !a.is_fake).length;

  return (
    <div className="space-y-5">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-neon-cyan animate-ping-slow" />
          <span className="text-[10px] text-neon-cyan font-bold tracking-widest uppercase">Responder Operations</span>
        </div>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-grotesk font-black text-foreground">Responder Panel</h1>
            <p className="text-sm text-muted-foreground">Dispatch management & team overview</p>
          </div>
          {isAdmin && (
            <div className="flex items-center gap-2 shrink-0">
              {responders.length === 0 && !loadingR && (
                <button onClick={handleSeedData} disabled={seeding}
                  className="flex items-center gap-2 px-3 py-2 glass-card rounded-xl text-xs font-semibold text-neon-yellow hover:bg-white/5 transition-all border border-neon-yellow/20 disabled:opacity-50">
                  {seeding ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : '⚡'}
                  Seed Sample Data
                </button>
              )}
              <button onClick={() => { setEditTarget(null); setShowForm(true); }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.25)' }}>
                <Plus className="w-4 h-4" /> Add Responder
              </button>
            </div>
          )}
        </div>
      </motion.div>

      {/* Quick stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Pending Alerts', value: pendingCount, color: 'text-neon-red' },
          { label: 'Available Responders', value: responders.filter(r => r.status === 'available').length, color: 'text-neon-green' },
          { label: 'In Progress', value: alerts.filter(a => a.status === 'in_progress').length, color: 'text-neon-cyan' },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}
            className="glass-card rounded-2xl p-4 text-center">
            {(loadingR && i === 1) || (loadingAlerts && i !== 1)
              ? <div className="h-8 w-12 shimmer rounded-lg mx-auto mb-1" />
              : <p className={`text-2xl font-grotesk font-black ${s.color}`}>{s.value}</p>
            }
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">{s.label}</p>
          </motion.div>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="dispatch" className="w-full">
        <TabsList className="glass-card border border-white/[0.08] p-1">
          <TabsTrigger value="dispatch" className="text-xs data-[state=active]:bg-white/10 gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" />
            Dispatch Queue
            {pendingCount > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full text-[9px] font-black"
                style={{ background: '#FF2D55', color: '#fff', boxShadow: '0 0 8px #FF2D55' }}>
                {pendingCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="team" className="text-xs data-[state=active]:bg-white/10 gap-1.5">
            <Users className="w-3.5 h-3.5" /> Team ({responders.length})
          </TabsTrigger>
          <TabsTrigger value="map" className="text-xs data-[state=active]:bg-white/10 gap-1.5">
            <Map className="w-3.5 h-3.5" /> Live Map
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dispatch" className="mt-4">
          <AlertDispatch alerts={alerts} responders={responders} onUpdate={handleUpdate} />
        </TabsContent>

        <TabsContent value="team" className="mt-4">
          <ResponderGrid
            responders={responders}
            canManage={isAdmin}
            onEdit={(r) => { setEditTarget(r); setShowForm(true); }}
            onDelete={handleDelete}
          />
        </TabsContent>

        <TabsContent value="map" className="mt-4">
          <NeuraMap alerts={alerts} responders={responders} height="600px" />
        </TabsContent>
      </Tabs>

      {/* Add/Edit Modal */}
      <AnimatePresence>
        {showForm && (
          <ResponderForm
            responder={editTarget}
            onClose={() => { setShowForm(false); setEditTarget(null); }}
            onSaved={handleUpdate}
          />
        )}
      </AnimatePresence>
    </div>
  );
}