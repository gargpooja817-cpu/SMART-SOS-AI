import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShieldX, ArrowLeft } from 'lucide-react';
import { useNeuraAuth, getRoleHomePath } from '@/lib/authContext';

export default function Unauthorized() {
  const { user } = useNeuraAuth();
  const home = user ? getRoleHomePath(user.role) : '/';

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass-card rounded-3xl p-10 text-center max-w-sm w-full border border-neon-red/20"
      >
        <div className="w-16 h-16 rounded-2xl bg-neon-red/10 border border-neon-red/20 flex items-center justify-center mx-auto mb-5">
          <ShieldX className="w-8 h-8 text-neon-red" />
        </div>
        <h1 className="text-xl font-grotesk font-black text-foreground mb-2">Access Denied</h1>
        <p className="text-sm text-muted-foreground mb-6">
          You don't have permission to access this area.<br />
          Your role: <span className="text-foreground font-semibold capitalize">{user?.role || 'unknown'}</span>
        </p>
        <Link
          to={home}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all"
          style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', color: '#fff' }}
        >
          <ArrowLeft className="w-4 h-4" /> Go to my dashboard
        </Link>
      </motion.div>
    </div>
  );
}