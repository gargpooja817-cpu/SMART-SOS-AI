import React from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle, Users, Activity, TrendingUp, Clock } from 'lucide-react';

function Stat({ icon: Icon, label, value, sub, color = 'text-neon-cyan', delay = 0 }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay, duration: 0.4, ease: [0.21, 0.47, 0.32, 0.98] }}
      className="glass-card rounded-2xl p-4 hover:bg-white/[0.03] transition-colors"
    >
      <div className="flex items-start justify-between mb-3">
        <div className={`p-2.5 rounded-xl bg-white/5 ${color}`}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <p className="text-2xl font-grotesk font-black text-foreground leading-none mb-1 count-up">{value}</p>
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</p>
      {sub && <p className="text-[10px] text-muted-foreground/60 mt-0.5">{sub}</p>}
    </motion.div>
  );
}

export default function CommandStats({ alerts = [], responders = [] }) {
  const active = alerts.filter(a => ['pending', 'assigned', 'in_progress'].includes(a.status) && !a.is_fake).length;
  const critical = alerts.filter(a => a.priority === 'critical' && a.status !== 'resolved').length;
  const resolved = alerts.filter(a => a.status === 'resolved').length;
  const available = responders.filter(r => r.status === 'available').length;
  const avgScore = alerts.length ? Math.round(alerts.reduce((s, a) => s + (a.urgency_score || 0), 0) / alerts.length) : 0;
  const flagged = alerts.filter(a => a.is_fake).length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-3">
      <Stat icon={AlertTriangle} label="Active" value={active} color="text-neon-red" delay={0} sub="alerts in progress" />
      <Stat icon={Activity} label="Critical" value={critical} color="text-neon-orange" delay={0.05} />
      <Stat icon={CheckCircle} label="Resolved" value={resolved} color="text-neon-green" delay={0.1} />
      <Stat icon={Users} label="Online" value={available} color="text-neon-cyan" delay={0.15} sub="responders" />
      <Stat icon={TrendingUp} label="Avg Urgency" value={avgScore} color="text-neon-purple" delay={0.2} sub="score /100" />
      <Stat icon={Clock} label="Flagged" value={flagged} color="text-neon-yellow" delay={0.25} sub="fake alerts" />
    </div>
  );
}