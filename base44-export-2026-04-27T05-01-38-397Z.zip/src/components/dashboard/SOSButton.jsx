const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, MapPin, Send, X, Loader2, WifiOff, Camera } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

import { calculateUrgencyScore, getPriorityFromScore, detectFakeSOS } from '@/lib/emergencyUtils';
import { toast } from 'sonner';

export default function SOSButton({ onAlertCreated }) {
  const [expanded, setExpanded] = useState(false);
  const [sending, setSending] = useState(false);
  const [form, setForm] = useState({
    message: '',
    alert_type: 'medical',
    reporter_name: '',
    reporter_phone: ''
  });

  const getLocation = () => {
    return new Promise((resolve) => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
          () => resolve({ lat: 40.7128 + (Math.random() - 0.5) * 0.05, lng: -74.006 + (Math.random() - 0.5) * 0.05 })
        );
      } else {
        resolve({ lat: 40.7128 + (Math.random() - 0.5) * 0.05, lng: -74.006 + (Math.random() - 0.5) * 0.05 });
      }
    });
  };

  const handleSOS = async () => {
    if (!form.message.trim()) {
      toast.error('Please describe the emergency');
      return;
    }

    setSending(true);

    const fakeCheck = detectFakeSOS(form.message, form.reporter_name);
    const urgencyScore = calculateUrgencyScore(form.message, form.alert_type);
    const priority = getPriorityFromScore(urgencyScore);
    const location = await getLocation();
    const isOffline = !navigator.onLine;

    const alertData = {
      message: form.message,
      alert_type: form.alert_type,
      priority,
      status: fakeCheck.isFake ? 'fake' : 'pending',
      latitude: location.lat,
      longitude: location.lng,
      urgency_score: urgencyScore,
      is_fake: fakeCheck.isFake,
      fake_reason: fakeCheck.isFake ? fakeCheck.reasons.join(', ') : '',
      reporter_name: form.reporter_name || 'Anonymous',
      reporter_phone: form.reporter_phone || '',
      offline_mode: isOffline,
      address: `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}`
    };

    await db.entities.Alert.create(alertData);

    if (fakeCheck.isFake) {
      toast.warning('Alert flagged for review — possible false alarm detected');
    } else if (isOffline) {
      toast.info('Alert queued for SMS delivery (offline mode)');
    } else {
      toast.success('SOS Alert sent! Help is on the way.');
    }

    setForm({ message: '', alert_type: 'medical', reporter_name: '', reporter_phone: '' });
    setExpanded(false);
    setSending(false);
    if (onAlertCreated) onAlertCreated();
  };

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {!expanded ? (
          <motion.button
            key="sos-btn"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setExpanded(true)}
            className="sos-pulse w-full h-32 rounded-2xl bg-gradient-to-br from-red-500 to-red-700 flex flex-col items-center justify-center gap-2 text-white font-bold shadow-2xl shadow-red-500/30 cursor-pointer border-2 border-red-400/30"
          >
            <AlertTriangle className="w-10 h-10" />
            <span className="text-xl tracking-wider">SOS EMERGENCY</span>
            <span className="text-xs font-normal opacity-80">Tap to send alert</span>
          </motion.button>
        ) : (
          <motion.div
            key="sos-form"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="glass rounded-2xl p-5 border border-red-500/20"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
                <h3 className="text-sm font-bold text-red-400 uppercase tracking-wider">Emergency Alert</h3>
              </div>
              <Button variant="ghost" size="icon" onClick={() => setExpanded(false)} className="text-muted-foreground h-8 w-8">
                <X className="w-4 h-4" />
              </Button>
            </div>

            <div className="space-y-3">
              <Select value={form.alert_type} onValueChange={(v) => setForm({ ...form, alert_type: v })}>
                <SelectTrigger className="bg-white/5 border-white/10">
                  <SelectValue placeholder="Emergency type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="medical">🏥 Medical Emergency</SelectItem>
                  <SelectItem value="fire">🔥 Fire</SelectItem>
                  <SelectItem value="attack">⚔️ Attack / Violence</SelectItem>
                  <SelectItem value="accident">🚗 Accident</SelectItem>
                  <SelectItem value="natural_disaster">🌊 Natural Disaster</SelectItem>
                  <SelectItem value="other">⚠️ Other</SelectItem>
                </SelectContent>
              </Select>

              <Textarea
                placeholder="Describe the emergency..."
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="bg-white/5 border-white/10 min-h-[80px] resize-none"
              />

              <div className="grid grid-cols-2 gap-3">
                <Input
                  placeholder="Your name"
                  value={form.reporter_name}
                  onChange={(e) => setForm({ ...form, reporter_name: e.target.value })}
                  className="bg-white/5 border-white/10"
                />
                <Input
                  placeholder="Phone number"
                  value={form.reporter_phone}
                  onChange={(e) => setForm({ ...form, reporter_phone: e.target.value })}
                  className="bg-white/5 border-white/10"
                />
              </div>

              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <MapPin className="w-3.5 h-3.5" />
                <span>Location will be auto-detected</span>
                <span className="mx-1">•</span>
                <Camera className="w-3.5 h-3.5" />
                <span>Evidence auto-capture enabled</span>
              </div>

              {!navigator.onLine && (
                <div className="flex items-center gap-2 text-xs text-yellow-400 bg-yellow-500/10 rounded-lg px-3 py-2">
                  <WifiOff className="w-3.5 h-3.5" />
                  <span>Offline — alert will be sent via SMS fallback</span>
                </div>
              )}

              <Button
                onClick={handleSOS}
                disabled={sending}
                className="w-full h-12 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold shadow-lg shadow-red-500/25"
              >
                {sending ? (
                  <Loader2 className="w-5 h-5 animate-spin mr-2" />
                ) : (
                  <Send className="w-5 h-5 mr-2" />
                )}
                {sending ? 'Sending Alert...' : 'SEND SOS NOW'}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}