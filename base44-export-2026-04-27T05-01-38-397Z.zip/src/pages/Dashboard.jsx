const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect } from 'react';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { MapPin, List, BarChart3, Zap, AlertTriangle, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import SOSCore from '@/components/dashboard/SOSCore';
import NeuraMap from '@/components/dashboard/NeuraMap';
import AlertFeed from '@/components/dashboard/AlertFeed';
import CommandStats from '@/components/dashboard/CommandStats';
import AIInsightsPanel from '@/components/dashboard/AIInsightsPanel';
import { offlineManager } from '@/lib/offlineManager';
import { toast } from 'sonner';

const NEON_COLORS = ['#FF2D55', '#FF6B2B', '#FFD60A', '#00FF88', '#00C6FF', '#7F00FF'];

export default function Dashboard() {
  const queryClient = useQueryClient();

  const { data: alerts = [], isLoading: loadingAlerts, isError: alertsError } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => db.entities.Alert.list('-created_date', 100),
    refetchInterval: 5000,
    retry: 2,
  });

  const { data: responders = [], isLoading: loadingResponders } = useQuery({
    queryKey: ['responders'],
    queryFn: () => db.entities.Responder.list(),
    refetchInterval: 15000,
    retry: 2,
  });

  // Sync offline queue when connection restores — attach once on mount
  useEffect(() => {
    const syncQueue = async () => {
      const queue = offlineManager.getQueue();
      if (queue.length > 0) {
        toast.info(`Back online — syncing ${queue.length} queued alert(s)...`);
        for (const entry of queue) {
          const { _offlineId, _queuedAt, _smsSent, ...data } = entry;
          await db.entities.Alert.create(data);
          offlineManager.dequeue(_offlineId);
        }
        queryClient.invalidateQueries({ queryKey: ['alerts'] });
        toast.success('All offline alerts synced!');
      }
    };
    const onOffline = () => toast.warning('Connection lost — offline mode active');
    window.addEventListener('online', syncQueue);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', syncQueue);
      window.removeEventListener('offline', onOffline);
    };
  }, [queryClient]);

  const handleAlertCreated = () => queryClient.invalidateQueries({ queryKey: ['alerts'] });

  // Chart data
  const typeCounts = {};
  alerts.forEach(a => { const t = a.alert_type || 'general'; typeCounts[t] = (typeCounts[t] || 0) + 1; });
  const chartData = Object.entries(typeCounts).map(([name, value]) => ({ name: name.replace('_', ' '), value }));

  const CustomTip = ({ active, payload }) => active && payload?.length
    ? <div className="glass-strong rounded-xl px-3 py-2 text-xs border border-white/10"><p className="font-bold text-foreground">{payload[0].value}</p></div>
    : null;

  if (alertsError) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] gap-4">
        <div className="w-12 h-12 rounded-2xl bg-neon-red/10 border border-neon-red/20 flex items-center justify-center">
          <Zap className="w-6 h-6 text-neon-red" />
        </div>
        <p className="text-sm text-muted-foreground">Failed to load dashboard data</p>
        <button onClick={() => queryClient.invalidateQueries({ queryKey: ['alerts'] })}
          className="px-4 py-2 glass-card rounded-xl text-xs font-semibold text-neon-cyan border border-neon-cyan/20 hover:bg-white/5 transition-colors">
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-neon-red animate-ping-slow" />
          <span className="text-[10px] text-neon-red font-bold tracking-widest uppercase">Live Operations</span>
        </div>
        <h1 className="text-2xl font-grotesk font-black text-foreground">Command Center</h1>
        <p className="text-sm text-muted-foreground">Real-time emergency monitoring & AI dispatch</p>
      </motion.div>

      {/* Nearby Help Banner */}
      <Link to="/nearby">
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          whileHover={{ scale: 1.01 }} whileTap={{ scale: 0.99 }}
          className="flex items-center gap-3 px-4 py-3 rounded-2xl cursor-pointer mb-1"
          style={{ background: 'rgba(0,255,136,0.06)', border: '1px solid rgba(0,255,136,0.2)' }}>
          <div className="w-9 h-9 rounded-xl flex items-center justify-center text-xl shrink-0" style={{ background: 'rgba(0,255,136,0.15)' }}>🏥</div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-neon-green">Find Nearby Hospitals & Clinics</p>
            <p className="text-[11px] text-muted-foreground">Free OSM-powered map · no API key required</p>
          </div>
          <Heart className="w-4 h-4 text-neon-green shrink-0" />
        </motion.div>
      </Link>

      {/* Stats */}
      <CommandStats alerts={alerts} responders={responders} />

      {/* Main grid */}
      <div className="grid lg:grid-cols-3 gap-4">
        {/* LEFT: SOS + Alert Feed + AI Insights */}
        <div className="lg:col-span-1 space-y-4">
          <SOSCore onAlertCreated={handleAlertCreated} responders={responders} />

          <AIInsightsPanel alerts={alerts} responders={responders} />

          <div className="glass-card rounded-2xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <List className="w-4 h-4 text-neon-red" />
              <h2 className="text-sm font-bold text-foreground">Live Alert Feed</h2>
              <div className="ml-auto flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-ping-slow" />
                <span className="text-[9px] text-neon-green font-bold uppercase tracking-wider">Live</span>
              </div>
            </div>
            <div className="h-[420px] overflow-hidden">
              <AlertFeed alerts={alerts} />
            </div>
          </div>
        </div>

        {/* RIGHT: Map + Charts */}
        <div className="lg:col-span-2 space-y-4">
          <Tabs defaultValue="map" className="w-full">
            <TabsList className="glass-card border border-white/[0.08] p-1">
              <TabsTrigger value="map" className="text-xs data-[state=active]:bg-white/10 gap-1.5">
                <MapPin className="w-3.5 h-3.5" /> Crisis Heatmap
              </TabsTrigger>
              <TabsTrigger value="analytics" className="text-xs data-[state=active]:bg-white/10 gap-1.5">
                <BarChart3 className="w-3.5 h-3.5" /> Analytics
              </TabsTrigger>
            </TabsList>

            <TabsContent value="map" className="mt-3">
              <NeuraMap alerts={alerts} responders={responders} height="520px" />
            </TabsContent>

            <TabsContent value="analytics" className="mt-3 space-y-4">
              <div className="glass-card rounded-2xl p-5">
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Alerts by Category</p>
                {chartData.length > 0 ? (
                  <ResponsiveContainer width="100%" height={280}>
                    <BarChart data={chartData} barSize={22}>
                      <XAxis dataKey="name" tick={{ fill: 'hsl(215 20% 50%)', fontSize: 11 }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fill: 'hsl(215 20% 50%)', fontSize: 11 }} axisLine={false} tickLine={false} />
                      <Tooltip content={<CustomTip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
                      <Bar dataKey="value" radius={[8, 8, 0, 0]}>
                        {chartData.map((_, i) => <Cell key={i} fill={NEON_COLORS[i % NEON_COLORS.length]} fillOpacity={0.85} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                    <BarChart3 className="w-10 h-10 opacity-20 mb-3" />
                    <p className="text-sm">No alert data yet</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}