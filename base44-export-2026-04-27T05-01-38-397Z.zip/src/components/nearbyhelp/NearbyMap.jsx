import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import { getDirectionsUrl } from '@/lib/overpassApi';

// Fix default icon
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function makeIcon(color, size = 14) {
  return L.divIcon({
    className: '',
    html: `<div style="width:${size}px;height:${size}px;border-radius:50%;background:${color};border:2px solid white;box-shadow:0 0 12px ${color}99"></div>`,
    iconAnchor: [size / 2, size / 2],
  });
}

function makeUserIcon() {
  return L.divIcon({
    className: '',
    html: `<div style="width:16px;height:16px;border-radius:50%;background:#00C6FF;border:3px solid white;box-shadow:0 0 20px rgba(0,198,255,0.8)"></div>`,
    iconAnchor: [8, 8],
  });
}

function MapFlyTo({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.flyTo(center, 14, { duration: 1.2 });
  }, [center, map]);
  return null;
}

const TYPE_COLORS = {
  hospital: '#FF2D55',
  clinic:   '#00C6FF',
  doctors:  '#00C6FF',
  pharmacy: '#00FF88',
};

export default function NearbyMap({ userLoc, places, focusedPlace, nearestId }) {
  if (!userLoc) return (
    <div className="w-full h-full flex items-center justify-center bg-black/30 rounded-2xl">
      <p className="text-sm text-muted-foreground">Waiting for location…</p>
    </div>
  );

  const flyTarget = focusedPlace
    ? [focusedPlace.lat, focusedPlace.lng]
    : [userLoc.lat, userLoc.lng];

  return (
    <MapContainer
      center={[userLoc.lat, userLoc.lng]}
      zoom={14}
      style={{ width: '100%', height: '100%', borderRadius: '1rem' }}
      zoomControl={false}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
      />

      <MapFlyTo center={flyTarget} />

      {/* User marker */}
      <Marker position={[userLoc.lat, userLoc.lng]} icon={makeUserIcon()}>
        <Popup>
          <div style={{ fontFamily: 'Inter, sans-serif', minWidth: 120 }}>
            <strong style={{ color: '#00C6FF' }}>📍 You are here</strong>
            {userLoc.accuracy && (
              <p style={{ fontSize: 11, color: '#888', margin: '4px 0 0' }}>Accuracy: ~{Math.round(userLoc.accuracy)}m</p>
            )}
          </div>
        </Popup>
      </Marker>

      {/* Accuracy circle */}
      {userLoc.accuracy && (
        <Circle
          center={[userLoc.lat, userLoc.lng]}
          radius={userLoc.accuracy}
          pathOptions={{ color: '#00C6FF', fillColor: '#00C6FF', fillOpacity: 0.06, weight: 1 }}
        />
      )}

      {/* Place markers */}
      {places.map(place => {
        const isNearest = place.id === nearestId;
        const color = isNearest ? '#FF2D55' : (TYPE_COLORS[place.type] || '#00C6FF');
        const size = isNearest ? 20 : 13;
        return (
          <Marker
            key={place.id}
            position={[place.lat, place.lng]}
            icon={makeIcon(color, size)}
          >
            <Popup maxWidth={220}>
              <div style={{ fontFamily: 'Inter, sans-serif', minWidth: 160 }}>
                {isNearest && <div style={{ fontSize: 10, fontWeight: 900, color: '#FF2D55', marginBottom: 4 }}>★ NEAREST</div>}
                <strong style={{ fontSize: 13 }}>{place.name}</strong>
                <div style={{ fontSize: 11, color: '#888', marginTop: 2, textTransform: 'capitalize' }}>{place.type}</div>
                <div style={{ fontSize: 12, marginTop: 4, fontWeight: 700, color: color }}>{place.distKm} km away</div>
                {place.address && <div style={{ fontSize: 11, color: '#888', marginTop: 2 }}>{place.address}</div>}
                <a
                  href={getDirectionsUrl(place.lat, place.lng)}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{
                    display: 'inline-block', marginTop: 8, padding: '5px 12px',
                    background: 'linear-gradient(135deg,#00C6FF,#7F00FF)', color: 'white',
                    borderRadius: 8, fontSize: 11, fontWeight: 700, textDecoration: 'none'
                  }}
                >
                  🧭 Get Directions
                </a>
              </div>
            </Popup>
          </Marker>
        );
      })}
    </MapContainer>
  );
}