import React, { useEffect, useRef } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, useMap } from 'react-leaflet';
import { PRIORITY_CONFIG } from '@/lib/emergencyUtils';
import UrgencyBadge from '@/components/shared/UrgencyBadge';
import AlertTypeIcon from '@/components/shared/AlertTypeIcon';
import { format } from 'date-fns';
import 'leaflet/dist/leaflet.css';

const priorityColors = {
  critical: '#ef4444',
  high: '#f97316',
  medium: '#eab308',
  low: '#22c55e'
};

function MapUpdater({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

export default function CrisisMap({ alerts = [], center = [40.7128, -74.006], height = '100%' }) {
  const validAlerts = alerts.filter(a => a.latitude && a.longitude && a.status !== 'fake');

  return (
    <div className="rounded-2xl overflow-hidden border border-white/10" style={{ height }}>
      <MapContainer
        center={center}
        zoom={12}
        style={{ height: '100%', width: '100%' }}
        zoomControl={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />
        <MapUpdater center={center} />

        {/* Heatmap-style circles (larger, more transparent) */}
        {validAlerts.map(alert => (
          <CircleMarker
            key={`heat-${alert.id}`}
            center={[alert.latitude, alert.longitude]}
            radius={alert.priority === 'critical' ? 40 : alert.priority === 'high' ? 30 : 20}
            pathOptions={{
              color: 'transparent',
              fillColor: priorityColors[alert.priority] || '#eab308',
              fillOpacity: 0.15
            }}
          />
        ))}

        {/* Alert markers */}
        {validAlerts.map(alert => (
          <CircleMarker
            key={alert.id}
            center={[alert.latitude, alert.longitude]}
            radius={8}
            pathOptions={{
              color: priorityColors[alert.priority] || '#eab308',
              fillColor: priorityColors[alert.priority] || '#eab308',
              fillOpacity: 0.8,
              weight: 2
            }}
          >
            <Popup className="dark-popup">
              <div className="min-w-[200px] p-1">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTypeIcon type={alert.alert_type} size="sm" />
                  <span className="font-semibold text-sm">{alert.alert_type?.replace('_', ' ')}</span>
                  <UrgencyBadge priority={alert.priority} />
                </div>
                <p className="text-xs text-gray-600 mb-1">{alert.message}</p>
                <p className="text-[10px] text-gray-400">
                  {alert.created_date ? format(new Date(alert.created_date), 'MMM d, h:mm a') : ''}
                </p>
              </div>
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}