const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { AlertTriangle, MapPin, Send, X, Loader2, WifiOff, Camera, Mic, ChevronDown, CheckCircle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

import { analyzeEmergency, detectFakeAlert } from '@/lib/aiEngine';
import { offlineManager } from '@/lib/offlineManager';
import NeonButton from '@/components/ui/NeonButton';
import ConfidenceMeter from '@/components/ui/ConfidenceMeter';
import NeuraBadge from '@/components/ui/NeuraBadge';
import ResourceChips from '@/components/ui/ResourceChips';
import { allocateResources } from '@/lib/aiEngine';
import { toast } from 'sonner';

const EMERGENCY_TYPES = [
  { value: 'medical', label: '🚑 Medical Emergency' },
  { value: 'fire', label: '🔥 Fire / Explosion' },
  { value: 'crime', label: '🚨 Crime / Attack' },
  { value: 'accident', label: '🚗 Road Accident' },
  { value: 'natural_disaster', label: '🌊 Natural Disaster' },
  { value: 'general', label: '⚠️ General Emergency' },
];

const steps = ['type', 'describe', 'confirm', 'sent'];

export default function SOSCore({ onAlertCreated, responders = [] }) {
  const [step, setStep] = useState(null); // null = button view
  const [form, setForm] = useState({ message: '', alert_type: 'medical', reporter_name: '', reporter_phone: '' });
  const [analysis, setAnalysis] = useState(null);
  const [sending, setSending] = useState(false);
  const [location, setLocation] = useState(null);
  const msgRef = useRef(null);

  const getLocation = () => new Promise(res => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        p => res({ lat: p.coords.latitude, lng: p.coords.longitude }),
        () => res({ lat: 40.7128 + (Math.random() - 0.5) * 0.08, lng: -74.006 + (Math.random() - 0.5) * 0.08 })
      );
    } else {
      res({ lat: 40.7128 + (Math.random() - 0.5) * 0.08, lng: -74.006 + (Math.random() - 0.5) * 0.08 });
    }
  });

  const handleAnalyze = async () => {
    if (!form.message.trim()) return toast.error('Please describe the emergency');
    const ai = analyzeEmergency(form.message);
    const loc = await getLocation();
    setLocation(loc);
    setAnalysis(ai);
    setStep('confirm');
  };

  const handleSend = async () => {
    setSending(true);
    try {
      const fake = detectFakeAlert({ message: form.message, reporterName: form.reporter_name });
      allocateResources(analysis.category, analysis.priorityLabel, responders);

      const data = {
        message: form.message.trim(),
        alert_type: analysis.category,
        priority: analysis.priorityLabel,
        status: fake.isFake ? 'fake' : 'pending',
        latitude: location?.lat,
        longitude: location?.lng,
        address: `${location?.lat?.toFixed(4)}, ${location?.lng?.toFixed(4)}`,
        urgency_score: analysis.priority,
        is_fake: fake.isFake,
        fake_reason: fake.isFake ? fake.flags.join('; ') : '',
        reporter_name: form.reporter_name.trim() || 'Anonymous',
        reporter_phone: form.reporter_phone.trim(),
        offline_mode: !navigator.onLine,
      };

      if (!navigator.onLine) {
        offlineManager.enqueue(data);
        toast.warning('No internet — alert queued & SMS fallback active');
      } else {
        await db.entities.Alert.create(data);
        if (fake.isFake) {
          toast.warning(`⚠️ Alert flagged (trust score: ${fake.trustScore}%). Pending review.`);
        } else {
          toast.success('🚨 SOS Dispatched! Responders notified.');
        }
      }

      setStep('sent');
      setTimeout(() => {
        setStep(null);
        setForm({ message: '', alert_type: 'medical', reporter_name: '', reporter_phone: '' });
        setAnalysis(null);
      }, 3000);
      if (onAlertCreated) onAlertCreated();
    } catch (err) {
      toast.error('Failed to dispatch alert. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const reset = () => { setStep(null); setAnalysis(null); setForm({ message: '', alert_type: 'medical', reporter_name: '', reporter_phone: '' }); };

  return (
    <div className="relative">
      <AnimatePresence mode="wait">
        {/* ── SOS TRIGGER BUTTON ── */}
        {step === null && (
          <motion.div key="trigger" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.9 }}>
            <button
              onClick={() => setStep('form')}
              className="w-full relative group"
            >
              {/* Rings */}
              <div className="absolute inset-0 rounded-3xl bg-neon-red/20 scale-0 group-hover:scale-110 opacity-0 group-hover:opacity-100 transition-all duration-500" />
              <div className="relative rounded-3xl overflow-hidden border border-neon-red/30 hover:border-neon-red/60 transition-all duration-300 shadow-neon-red hover:shadow-[0_0_60px_rgba(255,45,85,0.3)]"
                style={{ background: 'linear-gradient(135deg, rgba(255,45,85,0.12) 0%, rgba(255,107,43,0.08) 100%)' }}
              >
                <div className="flex flex-col items-center justify-center py-8 gap-3">
                  <div className="relative">
                    <div className="absolute inset-0 rounded-full bg-neon-red/40 animate-ping-slow" />
                    <div className="relative w-20 h-20 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #FF2D55, #FF6B2B)', boxShadow: '0 0 40px rgba(255,45,85,0.6)' }}>
                      <AlertTriangle className="w-9 h-9 text-white" strokeWidth={2.5} />
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-grotesk font-black text-neon-red text-glow-red tracking-wider">SOS EMERGENCY</p>
                    <p className="text-xs text-muted-foreground mt-1">Tap to activate crisis response</p>
                  </div>
                </div>
              </div>
            </button>
          </motion.div>
        )}

        {/* ── FORM ── */}
        {step === 'form' && (
          <motion.div key="form" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}
            className="glass-card rounded-2xl p-5 border border-neon-red/20"
          >
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-neon-red animate-ping-slow" />
                <span className="text-xs font-bold text-neon-red tracking-widest uppercase">Emergency Protocol</span>
              </div>
              <button onClick={reset} className="p-1.5 hover:bg-white/5 rounded-lg transition-colors"><X className="w-4 h-4 text-muted-foreground" /></button>
            </div>

            <div className="space-y-3">
              <Select value={form.alert_type} onValueChange={v => setForm(f => ({ ...f, alert_type: v }))}>
                <SelectTrigger className="bg-white/5 border-white/10 h-11 text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EMERGENCY_TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                </SelectContent>
              </Select>

              <div className="relative">
                <textarea
                  ref={msgRef}
                  value={form.message}
                  onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                  placeholder="Describe the emergency in detail..."
                  className="w-full h-24 bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground resize-none focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
                <div className="absolute bottom-2.5 right-3 text-[10px] text-muted-foreground font-mono">{form.message.length}/500</div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <input value={form.reporter_name} onChange={e => setForm(f => ({ ...f, reporter_name: e.target.value }))}
                  placeholder="Your name" className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors" />
                <input value={form.reporter_phone} onChange={e => setForm(f => ({ ...f, reporter_phone: e.target.value }))}
                  placeholder="Phone (optional)" className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors" />
              </div>

              <div className="flex items-center gap-3 text-[10px] text-muted-foreground px-1">
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3 text-neon-cyan" /> Auto-location</span>
                <span className="flex items-center gap-1"><Camera className="w-3 h-3 text-neon-purple" /> Evidence capture</span>
                <span className="flex items-center gap-1"><Mic className="w-3 h-3 text-neon-green" /> Audio log</span>
                {!navigator.onLine && <span className="flex items-center gap-1 text-neon-yellow"><WifiOff className="w-3 h-3" /> SMS fallback</span>}
              </div>

              <NeonButton variant="red" size="lg" className="w-full font-black tracking-wide" onClick={handleAnalyze}>
                <Send className="w-4 h-4" /> ANALYZE & DISPATCH
              </NeonButton>
            </div>
          </motion.div>
        )}

        {/* ── CONFIRM + AI ANALYSIS ── */}
        {step === 'confirm' && analysis && (
          <motion.div key="confirm" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -16 }}
            className="glass-card rounded-2xl p-5 border border-neon-cyan/20"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-neon-cyan tracking-widest uppercase">AI Analysis Complete</span>
              <button onClick={() => setStep('form')} className="p-1.5 hover:bg-white/5 rounded-lg"><X className="w-4 h-4 text-muted-foreground" /></button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-4">
              <ConfidenceMeter score={analysis.priority} label="Urgency" size="circle" />
              <ConfidenceMeter score={Math.round(analysis.confidence * 100)} label="Confidence" size="circle" />
              <div className="flex flex-col items-center justify-center gap-2">
                <span className="text-3xl">{analysis.icon}</span>
                <span className="text-[10px] text-muted-foreground capitalize">{analysis.category}</span>
              </div>
            </div>

            <div className="space-y-2.5 mb-4">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Priority Level</span>
                <NeuraBadge priority={analysis.priorityLabel} animate />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">Category</span>
                <span className="text-xs font-semibold text-foreground capitalize">{analysis.category.replace('_', ' ')}</span>
              </div>
              {analysis.keywords?.length > 0 && (
                <div className="flex items-start justify-between gap-2">
                  <span className="text-xs text-muted-foreground shrink-0">Key signals</span>
                  <div className="flex flex-wrap gap-1 justify-end">
                    {analysis.keywords.slice(0, 4).map(kw => (
                      <span key={kw} className="text-[10px] bg-neon-cyan/10 text-neon-cyan border border-neon-cyan/20 px-2 py-0.5 rounded-full">{kw}</span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="mb-4">
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Required Resources</p>
              <ResourceChips resources={analysis.resources} shortage={allocateResources(analysis.category, analysis.priorityLabel, responders).shortage} />
            </div>

            <div className="flex gap-2">
              <NeonButton variant="glass" size="md" className="flex-1" onClick={() => setStep('form')}>Edit</NeonButton>
              <NeonButton variant="red" size="md" className="flex-1 font-black" onClick={handleSend} disabled={sending}>
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Send className="w-4 h-4" /> DISPATCH</>}
              </NeonButton>
            </div>
          </motion.div>
        )}

        {/* ── SENT CONFIRMATION ── */}
        {step === 'sent' && (
          <motion.div key="sent" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}
            className="glass-card rounded-2xl p-8 text-center border border-neon-green/20"
          >
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }}
              className="w-16 h-16 rounded-full bg-neon-green/15 border border-neon-green/30 flex items-center justify-center mx-auto mb-4 shadow-neon-green"
            >
              <CheckCircle className="w-8 h-8 text-neon-green" />
            </motion.div>
            <p className="text-lg font-grotesk font-bold text-foreground mb-1">Alert Dispatched</p>
            <p className="text-xs text-muted-foreground">Responders are being notified in real-time</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}