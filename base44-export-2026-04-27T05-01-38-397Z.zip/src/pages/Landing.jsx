import React, { useEffect, useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import {
  Radio, Brain, MapPin, Users, Shield, WifiOff, Camera,
  ArrowRight, Zap, Activity, CheckCircle, ChevronRight, LogIn, Loader2,
  Flame, Star, Globe, Clock, TrendingUp, Lock
} from 'lucide-react';
import { useNeuraAuth, getRoleHomePath } from '@/lib/authContext';
import { useAuth } from '@/lib/AuthContext';

const features = [
  { icon: Zap, title: 'Instant SOS', desc: 'One-tap emergency dispatch with auto location capture in under 3 seconds', color: 'neon-red', gradient: 'from-[#FF2D55]/20 via-[#FF6B2B]/5 to-transparent' },
  { icon: Brain, title: 'AI Urgency Engine', desc: 'Multi-signal NLP classifier across 6 categories with 1–100 urgency scoring', color: 'neon-cyan', gradient: 'from-[#00C6FF]/20 via-[#7F00FF]/5 to-transparent' },
  { icon: Users, title: 'Smart Dispatch', desc: 'Optimal responder matching by type, proximity, rating & real-time availability', color: 'neon-purple', gradient: 'from-[#7F00FF]/20 via-[#00C6FF]/5 to-transparent' },
  { icon: MapPin, title: 'Crisis Heatmap', desc: 'Real-time color-coded alert visualization on live cartographic map', color: 'neon-green', gradient: 'from-[#00FF88]/20 via-[#00C6FF]/5 to-transparent' },
  { icon: Shield, title: 'Fake Detection', desc: 'Trust scoring & multi-rule flagging with complete audit trail', color: 'neon-orange', gradient: 'from-[#FF6B2B]/20 via-[#FFD60A]/5 to-transparent' },
  { icon: WifiOff, title: 'Offline Mode', desc: 'IndexedDB queue with SMS simulation — auto-sync on reconnect', color: 'neon-yellow', gradient: 'from-[#FFD60A]/20 via-[#FF6B2B]/5 to-transparent' },
];

const stats = [
  { value: '< 3s', label: 'Avg Dispatch Time', icon: Clock },
  { value: '99.97%', label: 'System Uptime', icon: TrendingUp },
  { value: '6', label: 'Alert Categories', icon: Globe },
  { value: '24/7', label: 'AI Monitoring', icon: Activity },
];

const testimonials = [
  { name: 'Sarah Chen', role: 'Emergency Director, NYC', text: 'NeuraRescue cut our response time by 40%. The AI dispatch is extraordinary.', avatar: 'S' },
  { name: 'Officer Mike Torres', role: 'Police Commander', text: 'The fake alert detection alone saves us thousands of officer hours monthly.', avatar: 'M' },
  { name: 'Dr. Ana Ruiz', role: 'Trauma Surgeon, General Hospital', text: 'Real-time heatmaps and instant SOS changed how we pre-position ambulances.', avatar: 'A' },
];

const colorMap = {
  'neon-red': { text: 'text-neon-red', border: 'border-neon-red/20', shadow: '#FF2D55' },
  'neon-cyan': { text: 'text-neon-cyan', border: 'border-neon-cyan/20', shadow: '#00C6FF' },
  'neon-purple': { text: 'text-neon-purple', border: 'border-neon-purple/20', shadow: '#7F00FF' },
  'neon-green': { text: 'text-neon-green', border: 'border-neon-green/20', shadow: '#00FF88' },
  'neon-orange': { text: 'text-neon-orange', border: 'border-neon-orange/20', shadow: '#FF6B2B' },
  'neon-yellow': { text: 'text-neon-yellow', border: 'border-neon-yellow/20', shadow: '#FFD60A' },
};

function FloatingParticles() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: i % 3 === 0 ? '#00C6FF' : i % 3 === 1 ? '#7F00FF' : '#FF2D55',
            opacity: 0.3,
          }}
          animate={{
            y: [0, -30, 0],
            opacity: [0.1, 0.5, 0.1],
          }}
          transition={{
            duration: 3 + Math.random() * 4,
            repeat: Infinity,
            delay: Math.random() * 3,
          }}
        />
      ))}
    </div>
  );
}

export default function Landing() {
  const { user } = useNeuraAuth();
  const { navigateToLogin } = useAuth();
  const [online, setOnline] = useState(navigator.onLine);
  const [signingIn, setSigningIn] = useState(false);
  const [activeTestimonial, setActiveTestimonial] = useState(0);
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({ target: heroRef, offset: ['start start', 'end start'] });
  const heroOpacity = useTransform(scrollYProgress, [0, 0.8], [1, 0]);
  const heroY = useTransform(scrollYProgress, [0, 1], [0, 80]);

  useEffect(() => {
    const h1 = () => setOnline(true);
    const h2 = () => setOnline(false);
    window.addEventListener('online', h1);
    window.addEventListener('offline', h2);
    return () => { window.removeEventListener('online', h1); window.removeEventListener('offline', h2); };
  }, []);

  useEffect(() => {
    const t = setInterval(() => setActiveTestimonial(i => (i + 1) % testimonials.length), 4000);
    return () => clearInterval(t);
  }, []);

  const dashPath = user ? getRoleHomePath(user.role) : '/dashboard';
  const handleSignIn = () => { setSigningIn(true); navigateToLogin(); };

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      {/* ── NAV ── */}
      <nav className="fixed top-0 inset-x-0 z-50 h-14 flex items-center" style={{ background: 'rgba(8,11,22,0.85)', backdropFilter: 'blur(30px)', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.4)' }}>
              <Radio className="w-4 h-4 text-white" />
            </div>
            <span className="font-grotesk font-black text-sm">
              <span className="text-gradient-neon">Neura</span><span className="text-foreground">Rescue</span>
            </span>
          </div>

          <div className="hidden md:flex items-center gap-6">
            <Link to="/about" className="text-xs text-muted-foreground hover:text-foreground transition-colors">About</Link>
            <Link to="/contact" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Contact</Link>
            <div className="flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${online ? 'bg-neon-green' : 'bg-neon-yellow'}`} style={{ boxShadow: online ? '0 0 6px #00FF88' : '0 0 6px #FFD60A' }} />
              <span className="text-[10px] text-muted-foreground">{online ? 'All Systems Online' : 'Offline Mode'}</span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user && (
              <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <div className="w-6 h-6 rounded-lg flex items-center justify-center text-[11px] font-black text-neon-cyan" style={{ background: 'linear-gradient(135deg, rgba(0,198,255,0.25), rgba(127,0,255,0.25))' }}>
                  {user.full_name?.charAt(0)?.toUpperCase() || '?'}
                </div>
                <span className="text-xs font-semibold text-foreground max-w-[90px] truncate">{user.full_name?.split(' ')[0]}</span>
              </div>
            )}
            {user ? (
              <Link to={dashPath}>
                <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white"
                  style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.3)' }}>
                  Dashboard <ArrowRight className="w-3.5 h-3.5" />
                </motion.button>
              </Link>
            ) : (
              <motion.button onClick={handleSignIn} disabled={signingIn} whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white disabled:opacity-70"
                style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.3)' }}>
                {signingIn ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <LogIn className="w-3.5 h-3.5" />}
                {signingIn ? 'Loading...' : 'Sign In'}
              </motion.button>
            )}
          </div>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section ref={heroRef} className="relative min-h-screen flex items-center justify-center pt-14 px-4 sm:px-6 overflow-hidden">
        {/* Background layers */}
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 120% 80% at 50% -10%, rgba(0,198,255,0.07) 0%, transparent 60%)' }} />
        <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse 80% 60% at 80% 80%, rgba(127,0,255,0.05) 0%, transparent 60%)' }} />
        <div className="absolute inset-0 grid-bg opacity-50" />
        <FloatingParticles />

        <motion.div style={{ opacity: heroOpacity, y: heroY }} className="max-w-5xl mx-auto text-center relative z-10">
          {/* Badge */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}
            className="inline-flex items-center gap-2 mb-8 px-4 py-2 rounded-full"
            style={{ background: 'rgba(0,198,255,0.08)', border: '1px solid rgba(0,198,255,0.2)' }}>
            <span className="w-2 h-2 rounded-full bg-neon-green" style={{ boxShadow: '0 0 8px #00FF88' }} />
            <span className="text-xs text-muted-foreground font-medium">AI-Powered Crisis Response Platform</span>
            <span className="text-[10px] font-bold text-neon-cyan px-2 py-0.5 rounded-full" style={{ background: 'rgba(0,198,255,0.15)' }}>v2.0</span>
          </motion.div>

          {/* Headline */}
          <motion.h1 initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1, duration: 0.7 }}
            className="text-5xl sm:text-7xl lg:text-8xl font-grotesk font-black tracking-tighter leading-[0.95] mb-6">
            <span className="text-foreground">Every</span>{' '}
            <span className="relative inline-block">
              <span className="text-gradient-neon">Second</span>
              <motion.span className="absolute -bottom-1 left-0 right-0 h-0.5 rounded-full" style={{ background: 'linear-gradient(90deg, #00C6FF, #7F00FF)' }}
                initial={{ scaleX: 0 }} animate={{ scaleX: 1 }} transition={{ delay: 0.8, duration: 0.6 }} />
            </span>
            <br />
            <span className="text-foreground">Saves a</span>{' '}
            <span className="text-gradient-danger">Life</span>
          </motion.h1>

          <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, duration: 0.6 }}
            className="text-base sm:text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed font-light">
            NeuraRescue uses advanced AI to detect, classify, and dispatch emergency response
            in <span className="text-foreground font-semibold">under 3 seconds</span> — connecting the right help to the right place, instantly.
          </motion.p>

          {/* CTAs */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.6 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
            {user ? (
              <Link to={dashPath}>
                <motion.button whileHover={{ scale: 1.04, boxShadow: '0 0 60px rgba(255,45,85,0.5)' }} whileTap={{ scale: 0.97 }}
                  className="group flex items-center gap-3 px-8 py-4 rounded-2xl text-base font-black text-white transition-all"
                  style={{ background: 'linear-gradient(135deg, #FF2D55, #FF6B2B)', boxShadow: '0 0 30px rgba(255,45,85,0.35)' }}>
                  <Zap className="w-5 h-5 group-hover:animate-bounce" />
                  Activate SOS System
                </motion.button>
              </Link>
            ) : (
              <motion.button onClick={handleSignIn} disabled={signingIn}
                whileHover={{ scale: 1.04, boxShadow: '0 0 60px rgba(255,45,85,0.5)' }} whileTap={{ scale: 0.97 }}
                className="group flex items-center gap-3 px-8 py-4 rounded-2xl text-base font-black text-white transition-all disabled:opacity-70"
                style={{ background: 'linear-gradient(135deg, #FF2D55, #FF6B2B)', boxShadow: '0 0 30px rgba(255,45,85,0.35)' }}>
                {signingIn ? <Loader2 className="w-5 h-5 animate-spin" /> : <Zap className="w-5 h-5 group-hover:animate-bounce" />}
                {signingIn ? 'Signing In...' : 'Get Started — Free'}
              </motion.button>
            )}
            <Link to="/about">
              <motion.button whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-6 py-4 rounded-2xl text-base font-semibold text-foreground transition-all"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)' }}>
                See How It Works <ArrowRight className="w-4 h-4" />
              </motion.button>
            </Link>
          </motion.div>

          {/* Animated SOS visual */}
          <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.5, duration: 0.8, type: 'spring' }}
            className="flex items-center justify-center">
            <div className="relative">
              {[1, 2, 3].map(i => (
                <motion.div key={i} className="absolute inset-0 rounded-full"
                  style={{ border: `1px solid rgba(255,45,85,${0.4 - i * 0.1})` }}
                  animate={{ scale: [1, 1 + i * 0.4], opacity: [0.8, 0] }}
                  transition={{ duration: 2, delay: i * 0.4, repeat: Infinity, ease: 'easeOut' }} />
              ))}
              <motion.div
                animate={{ boxShadow: ['0 0 40px rgba(255,45,85,0.4)', '0 0 80px rgba(255,45,85,0.7)', '0 0 40px rgba(255,45,85,0.4)'] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="relative w-28 h-28 rounded-full flex items-center justify-center"
                style={{ background: 'linear-gradient(135deg, #FF2D55, #FF6B2B)' }}>
                <span className="text-4xl font-grotesk font-black text-white">SOS</span>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1"
          animate={{ y: [0, 6, 0] }} transition={{ duration: 2, repeat: Infinity }}>
          <span className="text-[10px] text-muted-foreground uppercase tracking-widest">Scroll</span>
          <div className="w-5 h-8 rounded-full border border-white/20 flex items-start justify-center p-1">
            <motion.div className="w-1.5 h-1.5 rounded-full bg-neon-cyan"
              animate={{ y: [0, 14, 0] }} transition={{ duration: 2, repeat: Infinity }} />
          </div>
        </motion.div>
      </section>

      {/* ── STATS ── */}
      <section className="py-16 px-4 sm:px-6 relative">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {stats.map((s, i) => (
              <motion.div key={s.label} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className="relative group rounded-2xl p-6 text-center overflow-hidden cursor-default"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <motion.div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: 'radial-gradient(ellipse at center, rgba(0,198,255,0.04), transparent)' }} />
                <s.icon className="w-5 h-5 text-neon-cyan mx-auto mb-3 opacity-60" />
                <p className="text-3xl font-grotesk font-black text-gradient-neon mb-1">{s.value}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{s.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-center mb-16">
            <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full text-[10px] font-bold text-neon-cyan uppercase tracking-widest" style={{ background: 'rgba(0,198,255,0.08)', border: '1px solid rgba(0,198,255,0.15)' }}>
              <Flame className="w-3 h-3" /> Platform Features
            </div>
            <h2 className="text-3xl sm:text-5xl font-grotesk font-black text-foreground mb-4 tracking-tight">
              Built for Real Emergencies
            </h2>
            <p className="text-sm text-muted-foreground max-w-lg mx-auto leading-relaxed">
              Every feature engineered to reduce response time and save lives at scale
            </p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {features.map((f, i) => {
              const c = colorMap[f.color];
              return (
                <motion.div key={f.title}
                  initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.07 }}
                  whileHover={{ y: -8, transition: { duration: 0.2 } }}
                  className={`group relative rounded-2xl p-6 overflow-hidden cursor-default border ${c.border}`}
                  style={{ background: 'rgba(255,255,255,0.02)' }}>
                  <div className={`absolute inset-0 bg-gradient-to-br ${f.gradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
                  <div className="relative z-10">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 ${c.text}`}
                      style={{ background: `${c.shadow}12`, boxShadow: `0 0 20px ${c.shadow}15` }}>
                      <f.icon className="w-5 h-5" />
                    </div>
                    <h3 className="text-sm font-bold text-foreground mb-2">{f.title}</h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
                    <div className={`mt-4 flex items-center gap-1 text-[10px] font-bold ${c.text} opacity-0 group-hover:opacity-100 transition-opacity`}>
                      Learn more <ChevronRight className="w-3 h-3" />
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section className="py-20 px-4 sm:px-6" style={{ background: 'rgba(255,255,255,0.01)' }}>
        <div className="max-w-4xl mx-auto">
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-center mb-16">
            <div className="inline-flex items-center gap-2 mb-4 px-3 py-1.5 rounded-full text-[10px] font-bold text-neon-purple uppercase tracking-widest" style={{ background: 'rgba(127,0,255,0.08)', border: '1px solid rgba(127,0,255,0.15)' }}>
              <Activity className="w-3 h-3" /> How It Works
            </div>
            <h2 className="text-3xl sm:text-4xl font-grotesk font-black text-foreground">
              From Alert to Response in Seconds
            </h2>
          </motion.div>

          <div className="relative">
            <div className="absolute left-6 top-8 bottom-8 w-px hidden sm:block" style={{ background: 'linear-gradient(to bottom, #00C6FF, #7F00FF, #FF2D55)' }} />
            <div className="space-y-6">
              {[
                { step: '01', title: 'Alert Triggered', desc: 'Civilian taps SOS or types emergency. GPS location captured automatically.', color: '#00C6FF', icon: Zap },
                { step: '02', title: 'AI Analysis', desc: 'NLP engine classifies type, priority, and urgency score in milliseconds.', color: '#7F00FF', icon: Brain },
                { step: '03', title: 'Smart Dispatch', desc: 'Nearest available responder matched by type, rating, and proximity.', color: '#FF2D55', icon: Users },
                { step: '04', title: 'Live Tracking', desc: 'All parties get real-time updates. Command center monitors via heatmap.', color: '#00FF88', icon: MapPin },
              ].map((item, i) => (
                <motion.div key={item.step} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="flex items-start gap-6 pl-0 sm:pl-16 relative">
                  <div className="absolute left-0 top-2 w-12 h-12 rounded-full items-center justify-center font-black text-sm hidden sm:flex shrink-0"
                    style={{ background: `${item.color}15`, border: `1px solid ${item.color}40`, color: item.color, boxShadow: `0 0 20px ${item.color}20` }}>
                    {item.step}
                  </div>
                  <div className="glass-card rounded-2xl p-5 flex-1 border border-white/[0.05] hover:border-white/10 transition-colors">
                    <div className="flex items-center gap-3 mb-2">
                      <item.icon className="w-4 h-4" style={{ color: item.color }} />
                      <h3 className="text-sm font-bold text-foreground">{item.title}</h3>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-center mb-12">
            <div className="flex items-center justify-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 text-neon-yellow fill-current" style={{ filter: 'drop-shadow(0 0 4px #FFD60A)' }} />)}
            </div>
            <h2 className="text-2xl sm:text-3xl font-grotesk font-black text-foreground">Trusted by Emergency Services</h2>
          </motion.div>

          <div className="relative h-48">
            <AnimatePresence mode="wait">
              <motion.div key={activeTestimonial}
                initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 glass-card rounded-2xl p-8 border border-white/[0.06] flex flex-col justify-between">
                <p className="text-sm text-foreground/80 leading-relaxed italic">"{testimonials[activeTestimonial].text}"</p>
                <div className="flex items-center gap-3 mt-4">
                  <div className="w-9 h-9 rounded-xl flex items-center justify-center font-black text-sm text-neon-cyan"
                    style={{ background: 'linear-gradient(135deg, rgba(0,198,255,0.2), rgba(127,0,255,0.2))' }}>
                    {testimonials[activeTestimonial].avatar}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-foreground">{testimonials[activeTestimonial].name}</p>
                    <p className="text-[10px] text-muted-foreground">{testimonials[activeTestimonial].role}</p>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
          <div className="flex justify-center gap-1.5 mt-4">
            {testimonials.map((_, i) => (
              <button key={i} onClick={() => setActiveTestimonial(i)}
                className={`h-1.5 rounded-full transition-all duration-300 ${i === activeTestimonial ? 'w-6 bg-neon-cyan' : 'w-1.5 bg-white/20'}`} />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA ── */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto">
          <motion.div initial={{ opacity: 0, scale: 0.96 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            className="relative rounded-3xl p-10 sm:p-16 overflow-hidden text-center"
            style={{ background: 'linear-gradient(135deg, rgba(0,198,255,0.06) 0%, rgba(127,0,255,0.06) 50%, rgba(255,45,85,0.06) 100%)', border: '1px solid rgba(0,198,255,0.15)' }}>
            <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 0%, rgba(0,198,255,0.1), transparent 60%)' }} />
            <div className="relative z-10">
              <div className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6"
                style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 40px rgba(0,198,255,0.3)' }}>
                <Shield className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl sm:text-4xl font-grotesk font-black text-foreground mb-4 tracking-tight">
                Deploy NeuraRescue Today
              </h2>
              <p className="text-sm text-muted-foreground mb-4 max-w-sm mx-auto leading-relaxed">
                Protect your community with AI-powered emergency dispatch. Set up in minutes.
              </p>
              <div className="flex items-center justify-center gap-4 flex-wrap mb-8">
                {['No setup fees', 'Instant deployment', '24/7 support'].map(item => (
                  <div key={item} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <CheckCircle className="w-3.5 h-3.5 text-neon-green" /> {item}
                  </div>
                ))}
              </div>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                {user ? (
                  <Link to={getRoleHomePath(user.role)}>
                    <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                      className="flex items-center gap-2 px-8 py-3.5 rounded-2xl font-bold text-sm text-white"
                      style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 30px rgba(0,198,255,0.3)' }}>
                      Open Dashboard <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </Link>
                ) : (
                  <motion.button onClick={handleSignIn} disabled={signingIn}
                    whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                    className="flex items-center gap-2 px-8 py-3.5 rounded-2xl font-bold text-sm text-white disabled:opacity-70"
                    style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 30px rgba(0,198,255,0.3)' }}>
                    {signingIn ? <Loader2 className="w-4 h-4 animate-spin" /> : <LogIn className="w-4 h-4" />}
                    {signingIn ? 'Redirecting...' : 'Sign In to Get Started'}
                  </motion.button>
                )}
                <Link to="/about">
                  <button className="flex items-center gap-2 px-6 py-3.5 rounded-2xl text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors">
                    Learn More
                  </button>
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-white/[0.04] py-10 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2.5">
              <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
                <Radio className="w-3 h-3 text-white" />
              </div>
              <span className="font-grotesk font-black text-sm text-foreground">NeuraRescue</span>
              <span className="text-xs text-muted-foreground">© {new Date().getFullYear()}</span>
            </div>
            <div className="flex items-center gap-6 text-xs text-muted-foreground">
              <Link to="/about" className="hover:text-foreground transition-colors">About</Link>
              <Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link>
              <Link to="/responders" className="hover:text-foreground transition-colors">Responders</Link>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="w-3 h-3 text-neon-green" />
              <span className="text-[10px] text-neon-green font-semibold">SOC2 Compliant</span>
              <span className="text-muted-foreground mx-1">·</span>
              <CheckCircle className="w-3 h-3 text-neon-green" />
              <span className="text-[10px] text-neon-green font-semibold">All systems operational</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}