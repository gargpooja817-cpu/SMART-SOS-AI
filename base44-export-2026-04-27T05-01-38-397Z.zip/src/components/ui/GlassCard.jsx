import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export default function GlassCard({
  children,
  className = '',
  hover = false,
  glow = null,
  delay = 0,
  onClick,
  as = 'div',
}) {
  const glowClass = glow === 'cyan' ? 'hover:shadow-neon-cyan' : glow === 'red' ? 'hover:shadow-neon-red' : glow === 'green' ? 'hover:shadow-neon-green' : '';
  const Tag = motion[as] || motion.div;

  return (
    <Tag
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay, ease: [0.21, 0.47, 0.32, 0.98] }}
      onClick={onClick}
      className={cn(
        'glass-card rounded-2xl transition-all duration-300',
        hover && 'cursor-pointer hover:bg-white/[0.04] hover:-translate-y-0.5',
        glowClass,
        className
      )}
    >
      {children}
    </Tag>
  );
}