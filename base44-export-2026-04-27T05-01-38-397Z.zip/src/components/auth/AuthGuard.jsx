import React, { useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import { useNeuraAuth } from '@/lib/authContext';
import { useAuth } from '@/lib/AuthContext';
import { motion } from 'framer-motion';
import { Radio } from 'lucide-react';

export default function AuthGuard({ children, requiredRole = null }) {
  const { user, loading } = useNeuraAuth();
  const { navigateToLogin } = useAuth();

  // If not loading and no user, trigger login redirect
  useEffect(() => {
    if (!loading && !user) {
      navigateToLogin();
    }
  }, [loading, user, navigateToLogin]);

  if (loading) {
    return (
      <div className="fixed inset-0 bg-background flex items-center justify-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center gap-5"
        >
          <div className="relative w-16 h-16 rounded-2xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #00C6FF22, #7F00FF22)', border: '1px solid rgba(0,198,255,0.2)' }}>
            <Radio className="w-7 h-7 text-neon-cyan animate-pulse" />
          </div>
          <div className="text-center">
            <p className="text-sm font-bold text-foreground font-grotesk">NeuraRescue</p>
            <p className="text-xs text-muted-foreground mt-1">Authenticating...</p>
          </div>
          <div className="flex gap-1.5">
            {[0, 0.15, 0.3].map((d, i) => (
              <motion.div key={i} className="w-1.5 h-1.5 rounded-full bg-neon-cyan"
                animate={{ opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1.2, delay: d, repeat: Infinity }} />
            ))}
          </div>
        </motion.div>
      </div>
    );
  }

  if (!user) {
    return null; // navigateToLogin() called in useEffect above
  }

  if (requiredRole && user.role !== requiredRole && user.role !== 'admin') {
    return <Navigate to="/unauthorized" replace />;
  }

  return children;
}