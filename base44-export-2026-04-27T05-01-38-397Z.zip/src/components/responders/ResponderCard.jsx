import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Star, Activity } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const typeColors = {
  doctor: 'from-green-500/20 to-green-600/5 border-green-500/20',
  police: 'from-blue-500/20 to-blue-600/5 border-blue-500/20',
  firefighter: 'from-orange-500/20 to-orange-600/5 border-orange-500/20',
  volunteer: 'from-purple-500/20 to-purple-600/5 border-purple-500/20',
  paramedic: 'from-red-500/20 to-red-600/5 border-red-500/20'
};

const statusColors = {
  available: 'bg-green-500/20 text-green-400 border-green-500/20',
  busy: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20',
  offline: 'bg-gray-500/20 text-gray-400 border-gray-500/20'
};

export default function ResponderCard({ responder, index = 0 }) {
  const gradient = typeColors[responder.type] || typeColors.volunteer;
  const statusClass = statusColors[responder.status] || statusColors.offline;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      className={`rounded-2xl bg-gradient-to-br ${gradient} border p-5 hover:scale-[1.01] transition-transform duration-200`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center text-lg font-bold text-foreground">
            {responder.name?.charAt(0)}
          </div>
          <div>
            <h3 className="text-sm font-bold text-foreground">{responder.name}</h3>
            <p className="text-xs text-muted-foreground capitalize">{responder.type} {responder.specialization ? `• ${responder.specialization}` : ''}</p>
          </div>
        </div>
        <Badge variant="outline" className={`text-[10px] ${statusClass} border`}>
          {responder.status}
        </Badge>
      </div>

      <div className="flex items-center gap-4 text-xs text-muted-foreground">
        {responder.rating && (
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-yellow-400 fill-yellow-400" />
            {responder.rating.toFixed(1)}
          </span>
        )}
        {responder.total_responses != null && (
          <span className="flex items-center gap-1">
            <Activity className="w-3.5 h-3.5" />
            {responder.total_responses} responses
          </span>
        )}
        {responder.phone && (
          <span className="flex items-center gap-1">
            <Phone className="w-3.5 h-3.5" />
            {responder.phone}
          </span>
        )}
      </div>
    </motion.div>
  );
}