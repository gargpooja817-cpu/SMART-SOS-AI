import React from 'react';
import { Phone } from 'lucide-react';
import { motion } from 'framer-motion';

const QUICK = [
  { label: 'Ambulance', number: '911', color: '#FF2D55', icon: '🚑' },
  { label: 'Police',    number: '911', color: '#FF6B2B', icon: '🚔' },
  { label: 'Fire',      number: '911', color: '#FFD60A', icon: '🚒' },
];

export default function EmergencyQuickActions() {
  return (
    <div className="grid grid-cols-3 gap-2">
      {QUICK.map((q, i) => (
        <motion.a
          key={q.label}
          href={`tel:${q.number}`}
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.07 }}
          whileHover={{ scale: 1.04 }}
          whileTap={{ scale: 0.96 }}
          className="flex flex-col items-center gap-2 p-3 rounded-2xl text-center"
          style={{ background: `${q.color}15`, border: `1px solid ${q.color}35` }}
        >
          <span className="text-2xl">{q.icon}</span>
          <span className="text-[10px] font-black" style={{ color: q.color }}>{q.label}</span>
          <div className="flex items-center gap-1 px-2 py-1 rounded-lg" style={{ background: `${q.color}20` }}>
            <Phone className="w-2.5 h-2.5" style={{ color: q.color }} />
            <span className="text-[9px] font-bold" style={{ color: q.color }}>{q.number}</span>
          </div>
        </motion.a>
      ))}
    </div>
  );
}