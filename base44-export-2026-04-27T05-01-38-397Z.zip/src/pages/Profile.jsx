const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNeuraAuth } from '@/lib/authContext';

import { useQuery } from '@tanstack/react-query';
import { User, Mail, Shield, Clock, AlertTriangle, Edit3, Save, X, Loader2, Phone,
  Zap, Star, TrendingUp, Award, Target, ChevronRight, CheckCircle, Activity } from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';

const PRIORITY_COLORS = { critical: '#FF2D55', high: '#FF6B2B', medium: '#FFD60A', low: '#00FF88' };

function XPBar({ xp, level, nextLevelXP }) {
  const pct = Math.min(100, Math.round((xp / nextLevelXP) * 100));
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Level {level} Progress</span>
        <span className="text-[10px] font-bold text-neon-cyan">{xp} / {nextLevelXP} XP</span>
      </div>
      <div className="h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
        <motion.div className="h-full rounded-full" initial={{ width: 0 }} animate={{ width: `${pct}%` }} transition={{ duration: 1, ease: 'easeOut', delay: 0.3 }}
          style={{ background: 'linear-gradient(90deg, #00C6FF, #7F00FF)', boxShadow: '0 0 10px rgba(0,198,255,0.4)' }} />
      </div>
      <p className="text-[10px] text-muted-foreground">{nextLevelXP - xp} XP until Level {level + 1}</p>
    </div>
  );
}

function AchievementBadge({ icon, label, earned, color }) {
  return (
    <motion.div whileHover={{ scale: 1.05 }}
      className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all ${earned ? 'border-white/10 bg-white/[0.03]' : 'border-white/[0.04] opacity-40'}`}>
      <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg ${earned ? '' : 'grayscale'}`}
        style={earned ? { background: `${color}15`, boxShadow: `0 0 16px ${color}20` } : { background: 'rgba(255,255,255,0.04)' }}>
        {icon}
      </div>
      <span className={`text-[9px] font-bold text-center leading-tight ${earned ? 'text-foreground' : 'text-muted-foreground'}`}>{label}</span>
    </motion.div>
  );
}

const roleConfig = {
  admin: { label: 'Administrator', color: 'text-neon-purple', bg: 'bg-neon-purple/15 border-neon-purple/25', glow: '#7F00FF' },
  responder: { label: 'Responder', color: 'text-neon-cyan', bg: 'bg-neon-cyan/15 border-neon-cyan/25', glow: '#00C6FF' },
  user: { label: 'Civilian', color: 'text-neon-red', bg: 'bg-neon-red/15 border-neon-red/25', glow: '#FF2D55' },
};

export default function Profile() {
  const { user, updateRole } = useNeuraAuth();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState({ phone: user?.phone || '' });

  const { data: myAlerts = [] } = useQuery({
    queryKey: ['my-alerts', user?.email],
    queryFn: () => db.entities.Alert.filter({ created_by: user?.email }, '-created_date', 50),
    enabled: !!user,
  });

  const stats = useMemo(() => {
    const total = myAlerts.length;
    const resolved = myAlerts.filter(a => a.status === 'resolved').length;
    const pending = myAlerts.filter(a => a.status === 'pending').length;
    const critical = myAlerts.filter(a => a.priority === 'critical').length;
    const xp = resolved * 50 + (total - resolved) * 10 + critical * 25;
    const level = Math.max(1, Math.floor(xp / 200) + 1);
    const levelXP = xp % 200;
    const nextLevelXP = 200;
    return { total, resolved, pending, critical, xp, level, levelXP, nextLevelXP };
  }, [myAlerts]);

  const achievements = [
    { icon: '🚨', label: 'First Alert', earned: stats.total >= 1, color: '#FF2D55' },
    { icon: '⚡', label: 'Quick Responder', earned: stats.resolved >= 5, color: '#00C6FF' },
    { icon: '🛡️', label: 'Veteran', earned: stats.total >= 10, color: '#7F00FF' },
    { icon: '🔥', label: 'Critical Handler', earned: stats.critical >= 3, color: '#FF6B2B' },
    { icon: '⭐', label: 'Top Performer', earned: stats.resolved >= 20, color: '#FFD60A' },
    { icon: '🌐', label: 'Always Online', earned: true, color: '#00FF88' },
  ];

  const rc = roleConfig[user?.role] || roleConfig.user;

  const handleSave = async () => {
    if (editForm.phone && !/^[\+\d\s\-\(\)]{7,20}$/.test(editForm.phone)) {
      return toast.error('Please enter a valid phone number');
    }
    setSaving(true);
    try {
      await db.auth.updateMe({ phone: editForm.phone.trim() });
      toast.success('Profile updated');
      setEditing(false);
    } catch {
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      {/* Page header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-1">
          <div className="w-2 h-2 rounded-full bg-neon-cyan animate-ping-slow" />
          <span className="text-[10px] text-neon-cyan font-bold tracking-widest uppercase">Operator Profile</span>
        </div>
        <h1 className="text-2xl font-grotesk font-black text-foreground">My Account</h1>
        <p className="text-sm text-muted-foreground">Your identity, achievements, and emergency history</p>
      </motion.div>

      {/* Profile Hero Card */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
        className="relative rounded-3xl p-6 overflow-hidden border border-white/[0.07]"
        style={{ background: 'rgba(255,255,255,0.02)' }}>
        {/* Glow bg */}
        <div className="absolute inset-0 pointer-events-none" style={{ background: `radial-gradient(ellipse at 10% 50%, ${rc.glow}08 0%, transparent 60%)` }} />

        <div className="relative flex flex-col sm:flex-row items-start gap-5">
          {/* Avatar */}
          <div className="relative shrink-0">
            <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-3xl font-black font-grotesk"
              style={{ background: `linear-gradient(135deg, ${rc.glow}25, ${rc.glow}08)`, border: `1px solid ${rc.glow}30`, boxShadow: `0 0 30px ${rc.glow}15` }}>
              {user?.full_name?.charAt(0)?.toUpperCase() || '?'}
            </div>
            <motion.div animate={{ scale: [1, 1.2, 1], opacity: [1, 0.6, 1] }} transition={{ duration: 2, repeat: Infinity }}
              className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-neon-green border-2 border-background"
              style={{ boxShadow: '0 0 10px #00FF88' }} />
          </div>

          {/* Info + Edit */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <div className="flex items-center gap-3 flex-wrap mb-1.5">
                  <h2 className="text-xl font-grotesk font-black text-foreground">{user?.full_name || 'Unknown Operator'}</h2>
                  <span className={`text-[10px] font-bold px-3 py-1 rounded-full border uppercase tracking-wider ${rc.bg} ${rc.color}`}>{rc.label}</span>
                </div>
                {/* Level badge */}
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full" style={{ background: 'rgba(0,198,255,0.1)', border: '1px solid rgba(0,198,255,0.2)' }}>
                    <Star className="w-3 h-3 text-neon-cyan fill-current" />
                    <span className="text-[10px] font-black text-neon-cyan">Level {stats.level}</span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">{stats.xp} XP total</span>
                </div>
              </div>
              <button onClick={() => setEditing(v => !v)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors shrink-0"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
                {editing ? <X className="w-3.5 h-3.5" /> : <Edit3 className="w-3.5 h-3.5" />}
                {editing ? 'Cancel' : 'Edit'}
              </button>
            </div>

            <AnimatePresence mode="wait">
              {editing ? (
                <motion.div key="edit" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-3">
                  <div>
                    <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Email (read-only)</label>
                    <input value={user?.email || ''} disabled className="w-full px-4 py-2.5 text-sm text-muted-foreground rounded-xl cursor-not-allowed" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }} />
                  </div>
                  <div>
                    <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Phone Number</label>
                    <input value={editForm.phone} onChange={e => setEditForm(f => ({ ...f, phone: e.target.value }))}
                      placeholder="+1 555-0000" className="w-full px-4 py-2.5 text-sm text-foreground rounded-xl placeholder:text-muted-foreground focus:outline-none transition-colors"
                      style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.1)' }} />
                  </div>
                  <button onClick={handleSave} disabled={saving}
                    className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white disabled:opacity-50"
                    style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.25)' }}>
                    {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </motion.div>
              ) : (
                <motion.div key="view" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }} className="space-y-2">
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Mail className="w-3.5 h-3.5" /> {user?.email}
                    </div>
                    {user?.phone && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Phone className="w-3.5 h-3.5" /> {user.phone}
                      </div>
                    )}
                    {user?.created_date && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Clock className="w-3.5 h-3.5" /> Member since {format(new Date(user.created_date), 'MMM yyyy')}
                      </div>
                    )}
                  </div>
                  <XPBar xp={stats.levelXP} level={stats.level} nextLevelXP={stats.nextLevelXP} />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: 'Total Alerts', value: stats.total, color: 'text-foreground', icon: AlertTriangle },
          { label: 'Resolved', value: stats.resolved, color: 'text-neon-green', icon: CheckCircle },
          { label: 'Pending', value: stats.pending, color: 'text-neon-yellow', icon: Activity },
          { label: 'Critical', value: stats.critical, color: 'text-neon-red', icon: Zap },
        ].map((s, i) => (
          <motion.div key={s.label} initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.12 + i * 0.05 }}
            className="rounded-2xl p-4 text-center group hover:bg-white/[0.03] transition-colors border border-white/[0.05]"
            style={{ background: 'rgba(255,255,255,0.02)' }}>
            <s.icon className={`w-4 h-4 mx-auto mb-2 ${s.color} opacity-60`} />
            <p className={`text-2xl font-grotesk font-black ${s.color}`}>{s.value}</p>
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">{s.label}</p>
          </motion.div>
        ))}
      </motion.div>

      {/* Achievements */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
        className="rounded-3xl p-5 border border-white/[0.05]" style={{ background: 'rgba(255,255,255,0.02)' }}>
        <div className="flex items-center gap-2 mb-4">
          <Award className="w-4 h-4 text-neon-yellow" />
          <h3 className="text-sm font-bold text-foreground">Achievements</h3>
          <span className="ml-auto text-[10px] text-muted-foreground">{achievements.filter(a => a.earned).length}/{achievements.length} earned</span>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
          {achievements.map((a, i) => (
            <motion.div key={a.label} initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.18 + i * 0.04 }}>
              <AchievementBadge {...a} />
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Alert History */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
        className="rounded-3xl p-5 border border-white/[0.05]" style={{ background: 'rgba(255,255,255,0.02)' }}>
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle className="w-4 h-4 text-neon-red" />
          <h3 className="text-sm font-bold text-foreground">Alert History</h3>
          <span className="ml-auto text-[10px] text-muted-foreground">{myAlerts.length} alerts</span>
        </div>
        {myAlerts.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-14 h-14 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}>
              <AlertTriangle className="w-6 h-6 text-muted-foreground/40" />
            </div>
            <p className="text-sm text-muted-foreground">No alerts yet</p>
            <p className="text-xs text-muted-foreground/60 mt-1">Use the SOS button on the Dashboard to report an emergency</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
            {myAlerts.map((a, i) => (
              <motion.div key={a.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.02 }}
                className="flex items-center justify-between rounded-xl px-4 py-3 gap-3 border border-white/[0.04] hover:border-white/[0.08] hover:bg-white/[0.02] transition-all"
                style={{ background: 'rgba(255,255,255,0.015)' }}>
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-base shrink-0">
                    {a.alert_type === 'fire' ? '🔥' : a.alert_type === 'medical' ? '🚑' : a.alert_type === 'crime' ? '🚨' : a.alert_type === 'accident' ? '🚗' : a.alert_type === 'natural_disaster' ? '🌊' : '⚠️'}
                  </span>
                  <div className="min-w-0">
                    <p className="text-xs text-foreground/90 truncate">{a.message}</p>
                    <p className="text-[10px] text-muted-foreground">
                      {a.created_date ? formatDistanceToNow(new Date(a.created_date), { addSuffix: true }) : ''}
                      {a.assigned_responder_name && ` · ${a.assigned_responder_name}`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full"
                    style={{ background: `${PRIORITY_COLORS[a.priority]}20`, color: PRIORITY_COLORS[a.priority], border: `1px solid ${PRIORITY_COLORS[a.priority]}35` }}>
                    {a.priority?.toUpperCase()}
                  </span>
                  <span className={`text-[10px] font-semibold capitalize hidden sm:block ${
                    a.status === 'resolved' ? 'text-neon-green' : a.status === 'pending' ? 'text-neon-yellow' : a.status === 'assigned' ? 'text-neon-cyan' : 'text-muted-foreground'
                  }`}>{a.status}</span>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>
    </div>
  );
}