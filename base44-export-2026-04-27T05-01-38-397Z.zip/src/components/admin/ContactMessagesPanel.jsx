const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Mail, Trash2, CheckCircle, Loader2 } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import { toast } from 'sonner';

const STATUS_STYLES = {
  new: 'bg-neon-cyan/15 text-neon-cyan border-neon-cyan/25',
  read: 'bg-white/5 text-muted-foreground border-white/10',
  replied: 'bg-neon-green/15 text-neon-green border-neon-green/25',
};

export default function ContactMessagesPanel() {
  const queryClient = useQueryClient();
  const [expanded, setExpanded] = useState(null);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['contact-messages'],
    queryFn: () => db.entities.ContactMessage.list('-created_date', 50),
    retry: 2,
  });

  const markRead = async (msg) => {
    if (msg.status !== 'new') return;
    try {
      await db.entities.ContactMessage.update(msg.id, { status: 'read' });
      queryClient.invalidateQueries({ queryKey: ['contact-messages'] });
    } catch {
      toast.error('Failed to update message status.');
    }
  };

  const markReplied = async (msg) => {
    try {
      await db.entities.ContactMessage.update(msg.id, { status: 'replied' });
      queryClient.invalidateQueries({ queryKey: ['contact-messages'] });
      toast.success('Marked as replied');
    } catch {
      toast.error('Failed to update status.');
    }
  };

  const deleteMsg = async (msg) => {
    if (!window.confirm('Delete this message?')) return;
    try {
      await db.entities.ContactMessage.delete(msg.id);
      queryClient.invalidateQueries({ queryKey: ['contact-messages'] });
      toast.success('Message deleted');
      if (expanded === msg.id) setExpanded(null);
    } catch {
      toast.error('Failed to delete message.');
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-6 h-6 animate-spin text-neon-cyan" />
      </div>
    );
  }

  if (messages.length === 0) {
    return (
      <div className="glass-card rounded-2xl p-12 text-center">
        <Mail className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
        <p className="text-sm text-muted-foreground">No contact messages yet</p>
      </div>
    );
  }

  const newCount = messages.filter(m => m.status === 'new').length;

  return (
    <div className="space-y-3">
      {newCount > 0 && (
        <div className="flex items-center gap-2 px-1">
          <span className="w-2 h-2 rounded-full bg-neon-cyan animate-ping-slow" />
          <span className="text-xs font-bold text-neon-cyan">{newCount} unread message{newCount > 1 ? 's' : ''}</span>
        </div>
      )}
      {messages.map((msg, i) => (
        <motion.div
          key={msg.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.03 }}
          className={`glass-card rounded-2xl overflow-hidden border ${msg.status === 'new' ? 'border-neon-cyan/20' : 'border-white/[0.06]'}`}
        >
          <div
            className="flex items-start justify-between gap-3 p-4 cursor-pointer hover:bg-white/[0.02] transition-colors"
            onClick={() => { setExpanded(expanded === msg.id ? null : msg.id); markRead(msg); }}
          >
            <div className="flex items-start gap-3 min-w-0 flex-1">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 flex items-center justify-center text-sm font-bold text-neon-cyan shrink-0">
                {msg.name?.charAt(0)?.toUpperCase() || '?'}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-0.5">
                  <span className="text-sm font-bold text-foreground">{msg.name}</span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border capitalize ${STATUS_STYLES[msg.status]}`}>
                    {msg.status}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground truncate">{msg.subject}</p>
                <p className="text-[10px] text-muted-foreground mt-0.5">{msg.email}</p>
              </div>
            </div>
            <span className="text-[10px] text-muted-foreground shrink-0 mt-0.5">
              {msg.created_date ? formatDistanceToNow(new Date(msg.created_date), { addSuffix: true }) : ''}
            </span>
          </div>

          {expanded === msg.id && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t border-white/[0.05] px-4 pb-4 pt-3"
            >
              <p className="text-xs text-foreground/90 leading-relaxed mb-4 whitespace-pre-wrap">{msg.message}</p>
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] text-muted-foreground">
                  {msg.created_date ? format(new Date(msg.created_date), 'MMM d, yyyy · h:mm a') : ''}
                </span>
                <div className="flex gap-2">
                  {msg.status !== 'replied' && (
                    <button onClick={() => markReplied(msg)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold text-neon-green bg-neon-green/10 border border-neon-green/20 hover:bg-neon-green/15 transition-colors">
                      <CheckCircle className="w-3 h-3" /> Mark Replied
                    </button>
                  )}
                  <button onClick={() => deleteMsg(msg)}
                    className="p-1.5 rounded-lg text-muted-foreground hover:text-neon-red hover:bg-neon-red/10 transition-colors">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>
      ))}
    </div>
  );
}