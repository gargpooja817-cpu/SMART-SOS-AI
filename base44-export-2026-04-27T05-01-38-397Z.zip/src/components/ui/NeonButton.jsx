import React from 'react';
import { motion } from 'framer-motion';

const variants = {
  cyan: 'bg-gradient-to-r from-[#00C6FF] to-[#0072FF] text-black shadow-neon-cyan hover:shadow-[0_0_40px_rgba(0,198,255,0.6)]',
  purple: 'bg-gradient-to-r from-[#7F00FF] to-[#B000FF] text-white shadow-neon-purple hover:shadow-[0_0_40px_rgba(127,0,255,0.6)]',
  red: 'bg-gradient-to-r from-[#FF2D55] to-[#FF6B2B] text-white shadow-neon-red hover:shadow-[0_0_40px_rgba(255,45,85,0.7)]',
  green: 'bg-gradient-to-r from-[#00FF88] to-[#00C6FF] text-black shadow-neon-green hover:shadow-[0_0_40px_rgba(0,255,136,0.5)]',
  glass: 'glass border border-white/10 text-foreground hover:bg-white/5 hover:border-white/20',
  outline: 'bg-transparent border border-neon-cyan/30 text-neon-cyan hover:bg-neon-cyan/10 hover:border-neon-cyan/60',
};

const sizes = {
  sm: 'h-8 px-4 text-xs',
  md: 'h-10 px-5 text-sm',
  lg: 'h-12 px-7 text-base',
  xl: 'h-14 px-10 text-lg',
};

export default function NeonButton({
  children,
  variant = 'cyan',
  size = 'md',
  className = '',
  onClick,
  disabled = false,
  icon,
  type = 'button',
}) {
  return (
    <motion.button
      type={type}
      whileHover={disabled ? {} : { scale: 1.03 }}
      whileTap={disabled ? {} : { scale: 0.97 }}
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition-all duration-300 ${variants[variant]} ${sizes[size]} ${disabled ? 'opacity-40 cursor-not-allowed' : ''} ${className}`}
    >
      {icon && <span>{icon}</span>}
      {children}
    </motion.button>
  );
}