const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Radio, Mail, MessageSquare, Send, CheckCircle, ArrowRight, Phone, MapPin } from 'lucide-react';

// ContactMessage entity used for persistent storage of contact submissions
import { toast } from 'sonner';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Valid email required';
    if (!form.subject.trim()) e.subject = 'Subject is required';
    if (!form.message.trim() || form.message.length < 10) e.message = 'Message must be at least 10 characters';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    setSending(true);
    try {
      // Persist to database
      await db.entities.ContactMessage.create({
        name: form.name.trim(),
        email: form.email.trim().toLowerCase(),
        subject: form.subject.trim(),
        message: form.message.trim(),
        status: 'new',
      });
      setSent(true);
      toast.success('Message sent! We\'ll respond within 2 hours.');
    } catch {
      toast.error('Failed to send message. Please try again.');
    } finally {
      setSending(false);
    }
  };

  const F = ({ id, label, type = 'text', multiline = false }) => {
    const Tag = multiline ? 'textarea' : 'input';
    return (
      <div>
        <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wider">{label}</label>
        <Tag
          id={id}
          type={type}
          value={form[id]}
          onChange={e => { setForm(p => ({ ...p, [id]: e.target.value })); setErrors(p => ({ ...p, [id]: '' })); }}
          rows={multiline ? 4 : undefined}
          className={`w-full bg-white/5 border rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-neon-cyan/40 transition-colors resize-none ${errors[id] ? 'border-neon-red/50' : 'border-white/10'}`}
          placeholder={id === 'name' ? 'Your full name' : id === 'email' ? 'your@email.com' : id === 'subject' ? 'How can we help?' : 'Describe your inquiry...'}
        />
        {errors[id] && <p className="text-[11px] text-neon-red mt-1">{errors[id]}</p>}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 inset-x-0 z-50 glass-strong border-b border-white/[0.05] h-14 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
              <Radio className="w-4 h-4 text-white" />
            </div>
            <span className="font-grotesk font-black text-sm">
              <span className="text-gradient-neon">Neura</span><span className="text-foreground">Rescue</span>
            </span>
          </Link>
          <Link to="/dashboard">
            <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
              Dashboard <ArrowRight className="w-3.5 h-3.5" />
            </motion.button>
          </Link>
        </div>
      </nav>

      <div className="pt-20 pb-20 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto">
          {/* Header */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-14">
            <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-2 mb-6 border border-neon-cyan/20">
              <MessageSquare className="w-3.5 h-3.5 text-neon-cyan" />
              <span className="text-xs text-muted-foreground">Get in Touch</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-grotesk font-black text-foreground mb-4">
              Contact <span className="text-gradient-neon">Support</span>
            </h1>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Questions, partnerships, or emergency integration requests — we respond within 2 hours.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-5 gap-6">
            {/* Contact Info */}
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}
              className="md:col-span-2 space-y-4">
              {[
                { icon: Mail, label: 'Email', value: 'support@neurarescue.ai', color: 'text-neon-cyan' },
                { icon: Phone, label: 'Emergency Line', value: '+1 (800) NEU-RESC', color: 'text-neon-red' },
                { icon: MapPin, label: 'Headquarters', value: 'Crisis Tech Hub, San Francisco, CA', color: 'text-neon-purple' },
              ].map((c, i) => (
                <div key={c.label} className="glass-card rounded-2xl p-4 flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-xl bg-white/5 flex items-center justify-center shrink-0 ${c.color}`}>
                    <c.icon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{c.label}</p>
                    <p className="text-sm text-foreground font-semibold mt-0.5">{c.value}</p>
                  </div>
                </div>
              ))}

              <div className="glass-card rounded-2xl p-5 border border-neon-green/15">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-2 h-2 rounded-full bg-neon-green animate-ping-slow" />
                  <span className="text-xs font-bold text-neon-green">Response Time</span>
                </div>
                <p className="text-sm text-foreground font-bold">Under 2 hours</p>
                <p className="text-xs text-muted-foreground">Monday – Sunday, 24/7</p>
              </div>
            </motion.div>

            {/* Form */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 }}
              className="md:col-span-3 glass-card rounded-3xl p-6 border border-white/[0.06]">
              {sent ? (
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}
                  className="flex flex-col items-center justify-center py-12 text-center">
                  <CheckCircle className="w-14 h-14 text-neon-green mb-4" style={{ filter: 'drop-shadow(0 0 16px #00FF88)' }} />
                  <h3 className="text-xl font-grotesk font-black text-foreground mb-2">Message Sent!</h3>
                  <p className="text-sm text-muted-foreground mb-6">We'll get back to you within 2 hours.</p>
                  <button onClick={() => { setSent(false); setForm({ name: '', email: '', subject: '', message: '' }); }}
                    className="px-6 py-2.5 rounded-xl text-sm font-semibold glass-card border border-white/10 hover:bg-white/5 transition-colors text-foreground">
                    Send Another
                  </button>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <h2 className="text-base font-bold text-foreground mb-5">Send a Message</h2>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <F id="name" label="Full Name" />
                    <F id="email" label="Email Address" type="email" />
                  </div>
                  <F id="subject" label="Subject" />
                  <F id="message" label="Message" multiline />
                  <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                    type="submit"
                    disabled={sending}
                    className="w-full h-12 rounded-2xl font-bold text-sm text-white flex items-center justify-center gap-2 disabled:opacity-60 transition-all"
                    style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.25)' }}>
                    {sending ? (
                      <><span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Sending...</>
                    ) : (
                      <><Send className="w-4 h-4" /> Send Message</>
                    )}
                  </motion.button>
                </form>
              )}
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}