const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Loader2, Save } from 'lucide-react';

import { toast } from 'sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const TYPES = [
  { value: 'paramedic', label: '🚑 Paramedic' },
  { value: 'doctor', label: '👨⚕️ Doctor' },
  { value: 'firefighter', label: '🧑🚒 Firefighter' },
  { value: 'police', label: '👮 Police Officer' },
  { value: 'volunteer', label: '🙋 Volunteer' },
];

const STATUSES = [
  { value: 'available', label: '✅ Available' },
  { value: 'busy', label: '🔴 Busy' },
  { value: 'offline', label: '⚫ Offline' },
];

export default function ResponderForm({ responder = null, onClose, onSaved }) {
  const isEdit = !!responder;
  const [form, setForm] = useState({
    name: responder?.name || '',
    type: responder?.type || 'paramedic',
    status: responder?.status || 'available',
    phone: responder?.phone || '',
    specialization: responder?.specialization || '',
    rating: responder?.rating || 4.5,
    total_responses: responder?.total_responses || 0,
    latitude: responder?.latitude || 40.7128,
    longitude: responder?.longitude || -74.006,
  });
  const [saving, setSaving] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return toast.error('Name is required');
    if (form.rating < 0 || form.rating > 5) return toast.error('Rating must be between 0 and 5');
    setSaving(true);
    try {
      if (isEdit) {
        await db.entities.Responder.update(responder.id, form);
        toast.success('Responder updated');
      } else {
        await db.entities.Responder.create(form);
        toast.success('Responder added successfully');
      }
      onSaved?.();
      onClose?.();
    } catch {
      toast.error('Failed to save responder. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 16 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="glass-strong rounded-3xl border border-white/[0.08] shadow-glass-lg w-full max-w-md"
      >
        <form onSubmit={handleSubmit}>
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/[0.06]">
            <h2 className="text-sm font-bold text-foreground font-grotesk">
              {isEdit ? 'Edit Responder' : 'Add Responder'}
            </h2>
            <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/5 text-muted-foreground">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="px-6 py-5 space-y-3">
            {/* Name */}
            <div>
              <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Full Name *</label>
              <input
                value={form.name}
                onChange={e => set('name', e.target.value)}
                placeholder="e.g. Dr. Sarah Chen"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
              />
            </div>

            {/* Type + Status */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Type</label>
                <Select value={form.type} onValueChange={v => set('type', v)}>
                  <SelectTrigger className="bg-white/5 border-white/10 h-10 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPES.map(t => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Status</label>
                <Select value={form.status} onValueChange={v => set('status', v)}>
                  <SelectTrigger className="bg-white/5 border-white/10 h-10 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map(s => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Phone + Specialization */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Phone</label>
                <input
                  value={form.phone}
                  onChange={e => set('phone', e.target.value)}
                  placeholder="+1 555-0100"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Specialization</label>
                <input
                  value={form.specialization}
                  onChange={e => set('specialization', e.target.value)}
                  placeholder="e.g. Trauma"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
              </div>
            </div>

            {/* Rating + Responses */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Rating (0–5)</label>
                <input
                  type="number" min="0" max="5" step="0.1"
                  value={form.rating}
                  onChange={e => set('rating', parseFloat(e.target.value) || 0)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Total Responses</label>
                <input
                  type="number" min="0"
                  value={form.total_responses}
                  onChange={e => set('total_responses', parseInt(e.target.value) || 0)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
              </div>
            </div>

            {/* Location */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Latitude</label>
                <input
                  type="number" step="any"
                  value={form.latitude}
                  onChange={e => set('latitude', parseFloat(e.target.value) || 0)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground font-mono focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground uppercase tracking-wider mb-1 block">Longitude</label>
                <input
                  type="number" step="any"
                  value={form.longitude}
                  onChange={e => set('longitude', parseFloat(e.target.value) || 0)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground font-mono focus:outline-none focus:border-neon-cyan/40 transition-colors"
                />
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="px-6 py-4 border-t border-white/[0.06] flex gap-3">
            <button type="button" onClick={onClose}
              className="flex-1 py-2.5 rounded-xl text-sm font-semibold text-muted-foreground glass-card hover:bg-white/5 transition-colors">
              Cancel
            </button>
            <button type="submit" disabled={saving}
              className="flex-1 py-2.5 rounded-xl text-sm font-bold text-white flex items-center justify-center gap-2 transition-all disabled:opacity-50"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.25)' }}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              {saving ? 'Saving...' : isEdit ? 'Update' : 'Add Responder'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}