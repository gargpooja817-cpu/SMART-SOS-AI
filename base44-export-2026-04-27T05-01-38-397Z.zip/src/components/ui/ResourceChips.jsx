import React from 'react';

const resourceIcons = { ambulances: '🚑', fire_trucks: '🚒', police_units: '🚔', volunteers: '🙋' };
const resourceLabels = { ambulances: 'Ambulances', fire_trucks: 'Fire Trucks', police_units: 'Police Units', volunteers: 'Volunteers' };

export default function ResourceChips({ resources = {}, shortage = {}, compact = false }) {
  const entries = Object.entries(resources).filter(([, n]) => n > 0);
  if (entries.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-1.5">
      {entries.map(([key, count]) => {
        const hasShortage = shortage[key] > 0;
        return (
          <div
            key={key}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors ${
              hasShortage
                ? 'bg-neon-red/10 text-neon-red border-neon-red/30'
                : 'bg-white/5 text-muted-foreground border-white/8'
            }`}
          >
            <span>{resourceIcons[key]}</span>
            {!compact && <span className="text-[10px]">{resourceLabels[key]}</span>}
            <span className="font-mono text-foreground">{count}</span>
            {hasShortage && <span className="text-[9px] text-neon-red">-{shortage[key]}</span>}
          </div>
        );
      })}
    </div>
  );
}