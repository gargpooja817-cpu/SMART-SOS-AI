import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Radio, Brain, Shield, Zap, Users, Globe, ArrowRight, CheckCircle } from 'lucide-react';

const team = [
  { name: 'NeuraRescue AI', role: 'AI Urgency Engine', avatar: '🤖', desc: 'Processes every alert in milliseconds with multi-signal NLP classification.' },
  { name: 'Dispatch Core', role: 'Resource Allocator', avatar: '🚑', desc: 'Matches responders to incidents using proximity, type, and rating signals.' },
  { name: 'TrustShield', role: 'Fake Detection', avatar: '🛡️', desc: 'Multi-rule scoring engine that flags suspicious and duplicate alerts.' },
];

const milestones = [
  { year: '2024', title: 'Project Inception', desc: 'NeuraRescue was conceived as an AI-first emergency response platform.' },
  { year: '2025', title: 'Beta Launch', desc: 'First responders began using the platform in pilot cities.' },
  { year: '2026', title: 'Full Production', desc: 'Platform scaled to handle thousands of concurrent alerts with 99.97% uptime.' },
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="fixed top-0 inset-x-0 z-50 glass-strong border-b border-white/[0.05] h-14 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 w-full flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.3)' }}>
              <Radio className="w-4 h-4 text-white" />
            </div>
            <span className="font-grotesk font-black text-sm">
              <span className="text-gradient-neon">Neura</span><span className="text-foreground">Rescue</span>
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link to="/contact" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Contact</Link>
            <Link to="/dashboard">
              <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-bold text-white"
                style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 20px rgba(0,198,255,0.25)' }}>
                Dashboard <ArrowRight className="w-3.5 h-3.5" />
              </motion.button>
            </Link>
          </div>
        </div>
      </nav>

      <div className="pt-20 pb-20 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto">
          {/* Hero */}
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-20">
            <div className="inline-flex items-center gap-2 glass-card rounded-full px-4 py-2 mb-6 border border-neon-cyan/20">
              <Globe className="w-3.5 h-3.5 text-neon-cyan" />
              <span className="text-xs text-muted-foreground">Our Mission</span>
            </div>
            <h1 className="text-4xl sm:text-6xl font-grotesk font-black tracking-tighter text-foreground mb-5">
              Built to Save <span className="text-gradient-neon">Lives</span>
            </h1>
            <p className="text-base text-muted-foreground max-w-2xl mx-auto leading-relaxed">
              NeuraRescue is an AI-powered emergency response platform designed to bridge the gap between
              civilians in distress and life-saving responders — in under 3 seconds.
            </p>
          </motion.div>

          {/* Mission cards */}
          <div className="grid sm:grid-cols-3 gap-4 mb-20">
            {[
              { icon: Brain, title: 'AI-First', desc: 'Every decision is augmented by machine learning — from urgency scoring to resource allocation.', color: 'text-neon-cyan', border: 'border-neon-cyan/15' },
              { icon: Zap, title: 'Speed', desc: 'Alerts dispatched in milliseconds. Every second of delay costs lives — we eliminate delay.', color: 'text-neon-red', border: 'border-neon-red/15' },
              { icon: Shield, title: 'Trust', desc: 'Multi-layer fake detection ensures responders are never sent on false alarms.', color: 'text-neon-purple', border: 'border-neon-purple/15' },
            ].map((c, i) => (
              <motion.div key={c.title} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                className={`glass-card rounded-2xl p-6 border ${c.border}`}>
                <c.icon className={`w-6 h-6 ${c.color} mb-4`} />
                <h3 className="text-base font-bold text-foreground mb-2">{c.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{c.desc}</p>
              </motion.div>
            ))}
          </div>

          {/* How it works */}
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="mb-20">
            <h2 className="text-2xl font-grotesk font-black text-foreground mb-8 text-center">How NeuraRescue Works</h2>
            <div className="grid sm:grid-cols-3 gap-6">
              {team.map((t, i) => (
                <motion.div key={t.name} initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="glass-card rounded-2xl p-5 text-center">
                  <div className="text-5xl mb-4">{t.avatar}</div>
                  <h3 className="text-sm font-bold text-foreground mb-0.5">{t.name}</h3>
                  <p className="text-[10px] text-neon-cyan font-bold uppercase tracking-wider mb-3">{t.role}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{t.desc}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Timeline */}
          <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="mb-20">
            <h2 className="text-2xl font-grotesk font-black text-foreground mb-8 text-center">Our Journey</h2>
            <div className="space-y-4">
              {milestones.map((m, i) => (
                <motion.div key={m.year} initial={{ opacity: 0, x: -20 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }}
                  className="flex gap-5 items-start glass-card rounded-2xl p-5">
                  <div className="shrink-0 w-14 h-14 rounded-xl glass flex items-center justify-center text-center border border-neon-cyan/20">
                    <span className="text-xs font-black text-neon-cyan">{m.year}</span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <CheckCircle className="w-3.5 h-3.5 text-neon-green" />
                      <h3 className="text-sm font-bold text-foreground">{m.title}</h3>
                    </div>
                    <p className="text-xs text-muted-foreground">{m.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* CTA */}
          <motion.div initial={{ opacity: 0, scale: 0.95 }} whileInView={{ opacity: 1, scale: 1 }} viewport={{ once: true }}
            className="glass-card rounded-3xl p-10 text-center border border-neon-cyan/10">
            <h2 className="text-2xl font-grotesk font-black text-foreground mb-4">Join the Mission</h2>
            <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto">
              Help protect communities. Sign up as a civilian, responder, or administrator.
            </p>
            <Link to="/role-select">
              <motion.button whileHover={{ scale: 1.04 }} whileTap={{ scale: 0.97 }}
                className="px-8 py-3.5 rounded-2xl font-bold text-sm text-white"
                style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 30px rgba(0,198,255,0.3)' }}>
                Get Started Free
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>
    </div>
  );
}