/**
 * Top navbar with user avatar, role badge, and logout
 */
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Radio, ChevronDown, LogOut, Settings, User, Shield } from 'lucide-react';
import { useNeuraAuth, getRoleHomePath } from '@/lib/authContext';
import LivePulse from '@/components/ui/LivePulse';
import NotificationCenter from '@/components/shared/NotificationCenter';

const roleConfig = {
  admin: { label: 'Admin', color: 'text-neon-purple', bg: 'bg-neon-purple/15 border-neon-purple/25', icon: Shield },
  responder: { label: 'Responder', color: 'text-neon-cyan', bg: 'bg-neon-cyan/15 border-neon-cyan/25', icon: User },
  user: { label: 'Civilian', color: 'text-neon-red', bg: 'bg-neon-red/15 border-neon-red/25', icon: User },
};

const navLinks = [
  { path: '/dashboard', label: 'Dashboard', roles: ['user', 'admin', 'responder'] },
  { path: '/nearby', label: '🏥 Nearby Help', roles: ['user', 'admin', 'responder'] },
  { path: '/responders', label: 'Responders', roles: ['responder', 'admin'] },
  { path: '/admin', label: 'Admin', roles: ['admin'] },
];

export default function NeuraNavbar() {
  const { user, logout } = useNeuraAuth();
  const [dropOpen, setDropOpen] = useState(false);
  const loc = useLocation();
  const role = user?.role || 'user';
  const rc = roleConfig[role] || roleConfig.user;
  const RoleIcon = rc.icon;

  const visibleLinks = navLinks.filter(l => l.roles.includes(role));

  return (
    <header className="fixed top-0 inset-x-0 z-50 glass-strong h-14 border-b border-white/[0.06]">
      <div className="h-full max-w-[1600px] mx-auto px-4 md:px-6 flex items-center justify-between gap-4">
        {/* Logo */}
        <Link to={getRoleHomePath(role)} className="flex items-center gap-2.5 shrink-0">
          <div className="relative w-8 h-8 rounded-xl flex items-center justify-center"
            style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
            <Radio className="w-4 h-4 text-white" />
            <div className="absolute inset-0 rounded-xl"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', filter: 'blur(8px)', opacity: 0.4, zIndex: -1 }} />
          </div>
          <span className="font-grotesk font-black text-sm hidden sm:block">
            <span className="text-gradient-neon">Neura</span>
            <span className="text-foreground">Rescue</span>
          </span>
        </Link>

        {/* Center nav */}
        <nav className="hidden md:flex items-center gap-1">
          {visibleLinks.map(l => (
            <Link key={l.path} to={l.path}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                loc.pathname === l.path
                  ? 'bg-white/8 text-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-white/5'
              }`}>
              {l.label}
            </Link>
          ))}
        </nav>

        {/* Right */}
        <div className="flex items-center gap-2.5 shrink-0">
          <LivePulse label="Live" color="green" />
          <NotificationCenter />

          {/* User dropdown */}
          {user && (
            <div className="relative">
              <button
                onClick={() => setDropOpen(v => !v)}
                className="flex items-center gap-2 pl-2 pr-3 py-1.5 glass-card rounded-xl hover:bg-white/5 transition-all"
              >
                <div className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs"
                  style={{ background: 'linear-gradient(135deg, #00C6FF33, #7F00FF33)' }}>
                  {user.full_name?.charAt(0)?.toUpperCase() || '?'}
                </div>
                <div className="hidden sm:block text-left">
                  <p className="text-xs font-semibold text-foreground leading-none">{user.full_name?.split(' ')[0]}</p>
                  <span className={`text-[9px] font-bold uppercase tracking-wider ${rc.color}`}>{rc.label}</span>
                </div>
                <ChevronDown className={`w-3.5 h-3.5 text-muted-foreground transition-transform ${dropOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {dropOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 8, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 8, scale: 0.95 }}
                    className="absolute right-0 top-full mt-2 w-52 glass-strong rounded-2xl border border-white/[0.08] p-1.5 shadow-glass-lg z-50"
                  >
                    {/* Profile section */}
                    <div className="px-3 py-2.5 mb-1">
                      <p className="text-xs font-bold text-foreground">{user.full_name}</p>
                      <p className="text-[10px] text-muted-foreground truncate">{user.email}</p>
                      <span className={`inline-block mt-1.5 text-[9px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${rc.bg} ${rc.color}`}>
                        {rc.label}
                      </span>
                    </div>
                    <div className="h-px bg-white/[0.06] my-1" />
                    <Link to="/profile" onClick={() => setDropOpen(false)}
                      className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors">
                      <User className="w-3.5 h-3.5" /> My Profile
                    </Link>
                    <Link to="/role-select?change=true" onClick={() => setDropOpen(false)}
                      className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors">
                      <Settings className="w-3.5 h-3.5" /> Change Role
                    </Link>
                    <button onClick={logout}
                      className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs text-neon-red/70 hover:text-neon-red hover:bg-neon-red/5 transition-colors">
                      <LogOut className="w-3.5 h-3.5" /> Sign Out
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Backdrop */}
              {dropOpen && <div className="fixed inset-0 z-40" onClick={() => setDropOpen(false)} />}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}