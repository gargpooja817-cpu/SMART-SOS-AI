const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, X, Loader2, MapPin, Clock, User, Brain, Zap } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

import { rankResponders, allocateResources, CATEGORY_CONFIG, PRIORITY_CONFIG } from '@/lib/aiEngine';
import NeuraBadge from '@/components/ui/NeuraBadge';
import ConfidenceMeter from '@/components/ui/ConfidenceMeter';
import ResourceChips from '@/components/ui/ResourceChips';
import NeonButton from '@/components/ui/NeonButton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

function AlertCard({ alert, responders, onUpdate }) {
  const [assigning, setAssigning] = useState(false);
  const [selectedId, setSelectedId] = useState('');
  const cat = CATEGORY_CONFIG[alert.alert_type] || CATEGORY_CONFIG.general;
  const ranked = rankResponders(responders, alert.alert_type, alert.latitude, alert.longitude);
  const resources = allocateResources(alert.alert_type, alert.priority, responders);

  const dispatch = async (responderId) => {
    const responder = responders.find(r => r.id === responderId) || ranked[0];
    if (!responder) { toast.error('No available responders'); return; }
    setAssigning(true);
    try {
      await db.entities.Alert.update(alert.id, {
        status: 'assigned',
        assigned_responder_id: responder.id,
        assigned_responder_name: responder.name,
      });
      await db.entities.Responder.update(responder.id, { status: 'busy' });
      toast.success(`✅ Dispatched to ${responder.name}`);
      onUpdate?.();
    } catch {
      toast.error('Dispatch failed. Please try again.');
    } finally {
      setAssigning(false);
    }
  };

  const resolve = async () => {
    setAssigning(true);
    try {
      await db.entities.Alert.update(alert.id, { status: 'resolved' });
      if (alert.assigned_responder_id) {
        await db.entities.Responder.update(alert.assigned_responder_id, { status: 'available' });
      }
      toast.success('✅ Alert resolved — responder freed');
      onUpdate?.();
    } catch {
      toast.error('Failed to resolve alert.');
    } finally {
      setAssigning(false);
    }
  };

  const dismiss = async () => {
    try {
      await db.entities.Alert.update(alert.id, { status: 'fake' });
      toast.info('Alert dismissed as fake');
      onUpdate?.();
    } catch {
      toast.error('Failed to dismiss alert.');
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.97 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className={`glass-card rounded-2xl p-5 border-l-4 ${
        alert.priority === 'critical' ? 'border-l-neon-red' :
        alert.priority === 'high' ? 'border-l-neon-orange' :
        alert.priority === 'medium' ? 'border-l-neon-yellow' : 'border-l-neon-green'
      }`}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
          <span className="text-2xl">{cat.icon}</span>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <NeuraBadge priority={alert.priority} size="lg" animate />
              <span className="text-xs text-muted-foreground capitalize">{(alert.alert_type || '').replace('_', ' ')}</span>
            </div>
            <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {alert.created_date ? formatDistanceToNow(new Date(alert.created_date), { addSuffix: true }) : ''}
            </p>
          </div>
        </div>
        <ConfidenceMeter score={alert.urgency_score || 0} label="Urgency" size="circle" />
      </div>

      {/* Message */}
      <p className="text-sm text-foreground/90 mb-3 leading-relaxed">{alert.message}</p>

      {/* Meta */}
      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground mb-4">
        {alert.reporter_name && <span className="flex items-center gap-1"><User className="w-3.5 h-3.5" />{alert.reporter_name}</span>}
        {alert.address && <span className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{alert.address}</span>}
      </div>

      {/* Resources */}
      <div className="mb-4">
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Required Resources</p>
        <ResourceChips resources={resources.required} shortage={resources.shortage} />
        {resources.hasShortage && (
          <p className="text-[10px] text-neon-yellow mt-1.5 flex items-center gap-1">
            ⚠️ Resource shortage detected — backup units flagged
          </p>
        )}
      </div>

      {/* AI Best Match */}
      {ranked.length > 0 && (
        <div className="mb-4 glass-card rounded-xl p-3 border border-neon-cyan/15">
          <p className="text-[10px] text-neon-cyan font-semibold uppercase tracking-wider mb-2 flex items-center gap-1">
            <Brain className="w-3 h-3" /> AI Best Match
          </p>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-bold text-foreground">{ranked[0].name}</p>
              <p className="text-[10px] text-muted-foreground capitalize">{ranked[0].type} · Score: {ranked[0].matchScore}</p>
            </div>
            <span className="text-xs font-mono text-neon-green">{ranked[0].status}</span>
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="space-y-2">
        <div className="flex gap-2">
          <Select value={selectedId} onValueChange={setSelectedId}>
            <SelectTrigger className="flex-1 bg-white/5 border-white/10 h-9 text-xs">
              <SelectValue placeholder="Choose responder..." />
            </SelectTrigger>
            <SelectContent>
              {ranked.slice(0, 5).map(r => (
                <SelectItem key={r.id} value={r.id}>
                  {r.name} ({r.type}) — Score {r.matchScore}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <NeonButton variant="cyan" size="sm" onClick={() => dispatch(selectedId || ranked[0]?.id)} disabled={assigning}>
            {assigning ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Zap className="w-3.5 h-3.5" /> Assign</>}
          </NeonButton>
        </div>
        <div className="flex gap-2">
          <NeonButton variant="green" size="sm" className="flex-1" onClick={resolve} disabled={assigning}>
            <CheckCircle className="w-3.5 h-3.5" /> Resolve
          </NeonButton>
          <NeonButton variant="glass" size="sm" className="flex-1" onClick={dismiss} disabled={assigning}>
            <X className="w-3.5 h-3.5" /> Dismiss
          </NeonButton>
        </div>
      </div>
    </motion.div>
  );
}

export default function AlertDispatch({ alerts = [], responders = [], onUpdate }) {
  const pending = alerts.filter(a => a.status === 'pending' && !a.is_fake);
  const assigned = alerts.filter(a => a.status === 'assigned' || a.status === 'in_progress');

  if (pending.length === 0 && assigned.length === 0) {
    return (
      <div className="glass-card rounded-2xl p-12 text-center">
        <div className="w-16 h-16 rounded-full bg-neon-green/10 border border-neon-green/20 flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-8 h-8 text-neon-green" />
        </div>
        <p className="text-sm font-semibold text-foreground mb-1">All Clear</p>
        <p className="text-xs text-muted-foreground">No active alerts — systems nominal</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {pending.length > 0 && (
        <div>
          <p className="text-xs font-bold text-neon-red uppercase tracking-widest mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-neon-red animate-ping-slow" /> Pending ({pending.length})
          </p>
          <div className="space-y-3">
            <AnimatePresence>
              {pending.map(a => <AlertCard key={a.id} alert={a} responders={responders} onUpdate={onUpdate} />)}
            </AnimatePresence>
          </div>
        </div>
      )}
      {assigned.length > 0 && (
        <div>
          <p className="text-xs font-bold text-neon-cyan uppercase tracking-widest mb-3">In Progress ({assigned.length})</p>
          <div className="space-y-3">
            {assigned.map(a => <AlertCard key={a.id} alert={a} responders={responders} onUpdate={onUpdate} />)}
          </div>
        </div>
      )}
    </div>
  );
}