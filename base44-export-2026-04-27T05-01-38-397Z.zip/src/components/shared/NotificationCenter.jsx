const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bell, X, CheckCircle, AlertTriangle, Info, Check } from 'lucide-react';

import { formatDistanceToNow } from 'date-fns';

function useAlertNotifications() {
  const [notifications, setNotifications] = useState([]);
  const seenRef = useRef(new Set());

  useEffect(() => {
    const unsub = db.entities.Alert.subscribe((event) => {
      if (event.type === 'create') {
        const a = event.data;
        if (!seenRef.current.has(event.id)) {
          seenRef.current.add(event.id);
          const n = {
            id: `notif-${event.id}`,
            alertId: event.id,
            type: a.priority === 'critical' ? 'danger' : a.priority === 'high' ? 'warning' : 'info',
            title: `New ${(a.alert_type || 'alert').replace('_', ' ')} alert`,
            message: a.message?.slice(0, 80) || 'New emergency reported',
            time: new Date(),
            read: false,
          };
          setNotifications(prev => [n, ...prev].slice(0, 50));
        }
      }
    });
    return unsub;
  }, []);

  const markAllRead = () => setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  const dismiss = (id) => setNotifications(prev => prev.filter(n => n.id !== id));
  const clearAll = () => setNotifications([]);

  return { notifications, markAllRead, dismiss, clearAll };
}

const TYPE_CFG = {
  danger: { icon: AlertTriangle, color: 'text-neon-red', bg: 'bg-neon-red/10', border: 'border-neon-red/20' },
  warning: { icon: AlertTriangle, color: 'text-neon-yellow', bg: 'bg-neon-yellow/10', border: 'border-neon-yellow/20' },
  info: { icon: Info, color: 'text-neon-cyan', bg: 'bg-neon-cyan/10', border: 'border-neon-cyan/20' },
  success: { icon: CheckCircle, color: 'text-neon-green', bg: 'bg-neon-green/10', border: 'border-neon-green/20' },
};

export default function NotificationCenter() {
  const [open, setOpen] = useState(false);
  const { notifications, markAllRead, dismiss, clearAll } = useAlertNotifications();
  const unread = notifications.filter(n => !n.read).length;
  const panelRef = useRef(null);

  // Close on outside click
  useEffect(() => {
    const handler = (e) => { if (panelRef.current && !panelRef.current.contains(e.target)) setOpen(false); };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  return (
    <div className="relative" ref={panelRef}>
      <button
        onClick={() => { setOpen(v => !v); if (!open) markAllRead(); }}
        className="relative p-2 rounded-xl hover:bg-white/5 transition-colors"
      >
        <Bell className="w-4 h-4 text-muted-foreground" />
        {unread > 0 && (
          <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }}
            className="absolute -top-0.5 -right-0.5 min-w-[16px] h-4 rounded-full text-[9px] font-black flex items-center justify-center text-white px-1"
            style={{ background: '#FF2D55', boxShadow: '0 0 8px #FF2D55' }}>
            {unread > 9 ? '9+' : unread}
          </motion.span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 8, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 top-full mt-2 w-80 glass-strong rounded-2xl border border-white/[0.08] shadow-glass-lg z-50 overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-white/[0.06]">
              <div className="flex items-center gap-2">
                <Bell className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs font-bold text-foreground">Notifications</span>
                {notifications.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-white/5 text-[9px] font-bold text-muted-foreground">
                    {notifications.length}
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2">
                {notifications.length > 0 && (
                  <button onClick={clearAll} className="text-[10px] text-muted-foreground hover:text-foreground transition-colors">
                    Clear all
                  </button>
                )}
              </div>
            </div>

            {/* List */}
            <div className="max-h-[340px] overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <Bell className="w-8 h-8 text-muted-foreground/20 mb-2" />
                  <p className="text-xs text-muted-foreground">No notifications yet</p>
                  <p className="text-[10px] text-muted-foreground/60 mt-0.5">Real-time alerts will appear here</p>
                </div>
              ) : (
                <div className="p-2 space-y-1">
                  <AnimatePresence>
                    {notifications.map((n) => {
                      const cfg = TYPE_CFG[n.type] || TYPE_CFG.info;
                      return (
                        <motion.div key={n.id}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: -20 }}
                          className={`flex items-start gap-3 p-3 rounded-xl border ${cfg.bg} ${cfg.border} group`}>
                          <cfg.icon className={`w-4 h-4 shrink-0 mt-0.5 ${cfg.color}`} />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold text-foreground">{n.title}</p>
                            <p className="text-[10px] text-muted-foreground truncate mt-0.5">{n.message}</p>
                            <p className="text-[9px] text-muted-foreground/60 mt-1">
                              {formatDistanceToNow(n.time, { addSuffix: true })}
                            </p>
                          </div>
                          <button onClick={() => dismiss(n.id)}
                            className="shrink-0 p-0.5 rounded-lg opacity-0 group-hover:opacity-100 hover:bg-white/5 transition-all text-muted-foreground">
                            <X className="w-3 h-3" />
                          </button>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}