import React from 'react';
import { motion } from 'framer-motion';
import { Star, Activity, Phone, Shield, Pencil, Trash2 } from 'lucide-react';

const typeConfig = {
  doctor: { icon: '👨⚕️', bg: 'from-green-500/10 to-transparent', border: 'border-neon-green/15', label: 'Doctor' },
  police: { icon: '👮', bg: 'from-blue-500/10 to-transparent', border: 'border-neon-cyan/15', label: 'Police' },
  firefighter: { icon: '🧑🚒', bg: 'from-orange-500/10 to-transparent', border: 'border-neon-orange/15', label: 'Firefighter' },
  volunteer: { icon: '🙋', bg: 'from-purple-500/10 to-transparent', border: 'border-neon-purple/15', label: 'Volunteer' },
  paramedic: { icon: '🚑', bg: 'from-red-500/10 to-transparent', border: 'border-neon-red/15', label: 'Paramedic' },
};

const statusConfig = {
  available: { dot: 'bg-neon-green', label: 'Available', text: 'text-neon-green', bg: 'bg-neon-green/10 border-neon-green/20' },
  busy: { dot: 'bg-neon-yellow', label: 'Busy', text: 'text-neon-yellow', bg: 'bg-neon-yellow/10 border-neon-yellow/20' },
  offline: { dot: 'bg-muted-foreground', label: 'Offline', text: 'text-muted-foreground', bg: 'bg-white/5 border-white/10' },
};

export default function ResponderGrid({ responders = [], canManage = false, onEdit, onDelete }) {
  if (responders.length === 0) {
    return (
      <div className="glass-card rounded-2xl p-12 text-center">
        <Shield className="w-10 h-10 text-muted-foreground mx-auto mb-3 opacity-30" />
        <p className="text-sm text-muted-foreground">No responders registered</p>
        {canManage && (
          <p className="text-xs text-muted-foreground/60 mt-1">Use "Add Responder" or "Seed Sample Data" to get started</p>
        )}
      </div>
    );
  }

  return (
    <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-3">
      {responders.map((r, i) => {
        const tc = typeConfig[r.type] || typeConfig.volunteer;
        const sc = statusConfig[r.status] || statusConfig.offline;
        return (
          <motion.div
            key={r.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }}
            className={`glass-card bg-gradient-to-br ${tc.bg} border ${tc.border} rounded-2xl p-4 hover:bg-white/[0.03] transition-all group relative`}
          >
            {/* Edit/Delete buttons — admin only */}
            {canManage && (
              <div className="absolute top-3 right-3 flex gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => onEdit?.(r)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-neon-cyan/10 text-muted-foreground hover:text-neon-cyan transition-colors">
                  <Pencil className="w-3 h-3" />
                </button>
                <button onClick={() => onDelete?.(r)}
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-neon-red/10 text-muted-foreground hover:text-neon-red transition-colors">
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            )}

            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white/8 flex items-center justify-center text-2xl group-hover:scale-110 transition-transform">
                  {tc.icon}
                </div>
                <div>
                  <p className="text-sm font-bold text-foreground">{r.name}</p>
                  <p className="text-xs text-muted-foreground">{tc.label}{r.specialization ? ` · ${r.specialization}` : ''}</p>
                </div>
              </div>
              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold border ${sc.bg} ${sc.text}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                {sc.label}
              </span>
            </div>

            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              {r.rating != null && (
                <span className="flex items-center gap-1">
                  <Star className="w-3.5 h-3.5 text-neon-yellow fill-neon-yellow" />
                  <span className="font-semibold text-foreground">{Number(r.rating).toFixed(1)}</span>
                </span>
              )}
              {r.total_responses != null && (
                <span className="flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5" />
                  {r.total_responses} responses
                </span>
              )}
              {r.phone && (
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5" />
                  {r.phone}
                </span>
              )}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}