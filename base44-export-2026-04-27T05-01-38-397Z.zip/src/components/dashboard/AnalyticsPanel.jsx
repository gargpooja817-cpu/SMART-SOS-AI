import React from 'react';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
  AreaChart, Area, PieChart, Pie, Legend,
} from 'recharts';
import GlassCard from '@/components/ui/GlassCard';

const neonColors = ['#FF2D55', '#FF6B2B', '#FFD60A', '#00FF88', '#00C6FF', '#7F00FF'];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="glass-strong rounded-xl px-3 py-2 border border-white/10 text-xs">
      <p className="text-muted-foreground mb-1">{label}</p>
      <p className="font-bold text-foreground">{payload[0].value}</p>
    </div>
  );
};

export default function AnalyticsPanel({ alerts = [], responders = [] }) {
  // By type
  const typeCounts = {};
  alerts.forEach(a => { const t = a.alert_type || 'general'; typeCounts[t] = (typeCounts[t] || 0) + 1; });
  const typeData = Object.entries(typeCounts).map(([name, value]) => ({ name: name.replace('_', ' '), value }));

  // By priority
  const priCounts = { critical: 0, high: 0, medium: 0, low: 0 };
  alerts.forEach(a => { if (priCounts[a.priority] !== undefined) priCounts[a.priority]++; });
  const priData = Object.entries(priCounts).map(([name, value]) => ({ name, value }));
  const priColors = { critical: '#FF2D55', high: '#FF6B2B', medium: '#FFD60A', low: '#00FF88' };

  // Urgency over time (last 10 alerts)
  const trendData = alerts.slice(-10).reverse().map((a, i) => ({ i: i + 1, score: a.urgency_score || 0 }));

  // Responder types
  const responderTypes = {};
  responders.forEach(r => { responderTypes[r.type] = (responderTypes[r.type] || 0) + 1; });
  const responderData = Object.entries(responderTypes).map(([name, value]) => ({ name, value }));

  return (
    <div className="grid md:grid-cols-2 gap-4">
      <GlassCard className="p-5" delay={0}>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Alerts by Category</p>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={typeData} barSize={20}>
            <XAxis dataKey="name" tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
            <Bar dataKey="value" radius={[6, 6, 0, 0]}>
              {typeData.map((_, i) => <Cell key={i} fill={neonColors[i % neonColors.length]} fillOpacity={0.85} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </GlassCard>

      <GlassCard className="p-5" delay={0.05}>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Priority Distribution</p>
        <ResponsiveContainer width="100%" height={180}>
          <PieChart>
            <Pie data={priData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={4} dataKey="value">
              {priData.map((e, i) => <Cell key={i} fill={priColors[e.name] || '#888'} />)}
            </Pie>
            <Legend iconSize={8} iconType="circle" formatter={(v) => <span style={{ color: 'hsl(215 20% 50%)', fontSize: 10 }}>{v}</span>} />
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </GlassCard>

      <GlassCard className="p-5" delay={0.1}>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Urgency Trend (Recent 10)</p>
        <ResponsiveContainer width="100%" height={160}>
          <AreaChart data={trendData}>
            <defs>
              <linearGradient id="urgGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FF2D55" stopOpacity={0.3} />
                <stop offset="100%" stopColor="#FF2D55" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis dataKey="i" tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis domain={[0, 100]} tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="score" stroke="#FF2D55" strokeWidth={2} fill="url(#urgGrad)" dot={{ fill: '#FF2D55', r: 3 }} />
          </AreaChart>
        </ResponsiveContainer>
      </GlassCard>

      <GlassCard className="p-5" delay={0.15}>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Responder Composition</p>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={responderData} layout="vertical" barSize={12}>
            <XAxis type="number" tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
            <YAxis type="category" dataKey="name" tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} width={70} />
            <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
            <Bar dataKey="value" radius={[0, 6, 6, 0]}>
              {responderData.map((_, i) => <Cell key={i} fill={neonColors[i % neonColors.length]} fillOpacity={0.85} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </GlassCard>
    </div>
  );
}