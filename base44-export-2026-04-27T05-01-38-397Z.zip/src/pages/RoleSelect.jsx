/**
 * Role Selection Page
 * Shown after first login to let users pick their role
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useNeuraAuth, getRoleHomePath } from '@/lib/authContext';
import { Loader2, Radio } from 'lucide-react';
import { toast } from 'sonner';

const roles = [
  {
    id: 'user',
    icon: '🆘',
    title: 'Civilian',
    subtitle: 'Emergency Reporter',
    desc: 'Send SOS alerts, track your emergency status in real-time',
    gradient: 'from-neon-red/20 to-neon-orange/10',
    border: 'border-neon-red/25 hover:border-neon-red/50',
    glow: 'hover:shadow-neon-red',
    badge: 'bg-neon-red/15 text-neon-red border-neon-red/20',
    features: ['Send SOS Alerts', 'Live Location Sharing', 'Emergency Status Tracker'],
  },
  {
    id: 'responder',
    icon: '🚑',
    title: 'Responder',
    subtitle: 'Emergency Responder',
    desc: 'Receive and respond to emergency alerts in your area',
    gradient: 'from-neon-cyan/20 to-neon-purple/10',
    border: 'border-neon-cyan/25 hover:border-neon-cyan/50',
    glow: 'hover:shadow-neon-cyan',
    badge: 'bg-neon-cyan/15 text-neon-cyan border-neon-cyan/20',
    features: ['Accept / Reject Alerts', 'Real-time Dispatch', 'Status Updates'],
  },
  {
    id: 'admin',
    icon: '🛡️',
    title: 'Administrator',
    subtitle: 'System Admin',
    desc: 'Full access to all system data, users, and configurations',
    gradient: 'from-neon-purple/20 to-neon-cyan/10',
    border: 'border-neon-purple/25 hover:border-neon-purple/50',
    glow: 'hover:shadow-neon-purple',
    badge: 'bg-neon-purple/15 text-neon-purple border-neon-purple/20',
    features: ['All Alerts & Analytics', 'User Management', 'Resource Allocation'],
  },
];

export default function RoleSelect() {
  const { user, updateRole } = useNeuraAuth();
  const [selected, setSelected] = useState(user?.role || null);
  const [saving, setSaving] = useState(false);
  const navigate = useNavigate();

  // If user already has a role and came here directly (not from change-role link), redirect
  useEffect(() => {
    const isChangingRole = window.location.search.includes('change=true');
    if (user?.role && user.role !== 'user' && !isChangingRole) {
      navigate(getRoleHomePath(user.role), { replace: true });
    }
  }, [user, navigate]);

  const handleConfirm = async () => {
    if (!selected) return toast.error('Please select a role');
    setSaving(true);
    try {
      await updateRole(selected);
      toast.success(`Welcome, ${user?.full_name?.split(' ')[0] || 'Operator'}!`);
      navigate(getRoleHomePath(selected));
    } catch (err) {
      toast.error(err.message || 'Failed to set role. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background grid-bg flex items-center justify-center p-6">
      {/* Background glow */}
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(ellipse, rgba(0,198,255,0.04) 0%, transparent 70%)' }} />

      <div className="w-full max-w-3xl">
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
          <div className="inline-flex items-center gap-2 mb-5">
            <div className="w-10 h-10 rounded-2xl flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)', boxShadow: '0 0 30px rgba(0,198,255,0.3)' }}>
              <Radio className="w-5 h-5 text-white" />
            </div>
            <span className="font-grotesk font-black text-xl text-gradient-neon">NeuraRescue</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-grotesk font-black text-foreground mb-3">
            Choose Your Role
          </h1>
          <p className="text-muted-foreground">
            Welcome, <span className="text-foreground font-semibold">{user?.full_name || 'Operator'}</span>.
            Select how you'll use NeuraRescue.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-3 gap-4 mb-8">
          {roles.map((role, i) => (
            <motion.button
              key={role.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ scale: 1.02, y: -4 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setSelected(role.id)}
              className={`text-left p-5 rounded-2xl glass-card bg-gradient-to-br ${role.gradient} border transition-all duration-300 ${role.border} ${role.glow} ${
                selected === role.id ? `ring-2 ring-offset-2 ring-offset-background ${role.border.replace('hover:', '')}` : ''
              }`}
            >
              <div className="text-4xl mb-3">{role.icon}</div>
              <div className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full border mb-3 ${role.badge}`}>
                {role.subtitle}
              </div>
              <h3 className="text-base font-grotesk font-black text-foreground mb-1">{role.title}</h3>
              <p className="text-xs text-muted-foreground mb-4 leading-relaxed">{role.desc}</p>
              <ul className="space-y-1.5">
                {role.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span className="w-1 h-1 rounded-full bg-neon-cyan shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
              {selected === role.id && (
                <div className="mt-4 flex items-center gap-1.5 text-xs font-bold text-neon-cyan">
                  <span className="w-3 h-3 rounded-full border-2 border-neon-cyan flex items-center justify-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan" />
                  </span>
                  Selected
                </div>
              )}
            </motion.button>
          ))}
        </div>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleConfirm}
          disabled={!selected || saving}
          className="w-full h-14 rounded-2xl font-grotesk font-black text-base transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-3"
          style={{
            background: selected ? 'linear-gradient(135deg, #00C6FF, #7F00FF)' : 'rgba(255,255,255,0.05)',
            boxShadow: selected ? '0 0 30px rgba(0,198,255,0.3)' : 'none',
            color: selected ? '#fff' : 'inherit',
          }}
        >
          {saving ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
          {saving ? 'Setting up your access...' : 'Confirm & Enter System'}
        </motion.button>
      </div>
    </div>
  );
}