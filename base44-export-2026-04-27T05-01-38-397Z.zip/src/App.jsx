import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import { Toaster as SonnerToaster } from 'sonner';

// NeuraRescue Auth Context
import { NeuraAuthProvider } from '@/lib/authContext';

// Pages
import Landing from '@/pages/Landing';
import Dashboard from '@/pages/Dashboard';
import NearbyHelp from '@/pages/NearbyHelp';
import Responders from '@/pages/Responders';
import AdminPanel from '@/pages/AdminPanel';
import RoleSelect from '@/pages/RoleSelect';
import Unauthorized from '@/pages/Unauthorized';
import Profile from '@/pages/Profile';
import About from '@/pages/About';
import Contact from '@/pages/Contact';

// Layouts
import NeuraShell from '@/components/layout/NeuraShell';
import AuthGuard from '@/components/auth/AuthGuard';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="w-10 h-10 border-4 rounded-full animate-spin"
            style={{ borderColor: 'rgba(0,198,255,0.2)', borderTopColor: '#00C6FF' }} />
          <p className="text-sm text-muted-foreground font-semibold font-grotesk">NeuraRescue</p>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') return <UserNotRegisteredError />;
    if (authError.type === 'auth_required') { navigateToLogin(); return null; }
  }

  return (
    <NeuraAuthProvider>
      <Routes>
        {/* Public pages — no auth required */}
        <Route path="/" element={<Landing />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/unauthorized" element={<Unauthorized />} />

        {/* Role selection — authenticated but no role yet */}
        <Route path="/role-select" element={
          <AuthGuard><RoleSelect /></AuthGuard>
        } />

        {/* Nearby Help — standalone page with own nav */}
        <Route path="/nearby" element={
          <AuthGuard><NearbyHelp /></AuthGuard>
        } />

        {/* Authenticated pages inside shell */}
        <Route element={<NeuraShell />}>
          <Route path="/dashboard" element={
            <AuthGuard><Dashboard /></AuthGuard>
          } />
          <Route path="/responders" element={
            <AuthGuard><Responders /></AuthGuard>
          } />
          <Route path="/profile" element={
            <AuthGuard><Profile /></AuthGuard>
          } />
        </Route>

        {/* Admin only */}
        <Route element={<NeuraShell requiredRole="admin" />}>
          <Route path="/admin" element={
            <AuthGuard requiredRole="admin"><AdminPanel /></AuthGuard>
          } />
        </Route>

        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </NeuraAuthProvider>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
        <SonnerToaster
          theme="dark"
          position="top-right"
          toastOptions={{
            style: {
              background: 'rgba(13,18,30,0.95)',
              border: '1px solid rgba(255,255,255,0.08)',
              color: '#fff',
              backdropFilter: 'blur(20px)',
              borderRadius: '12px',
            },
          }}
        />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;