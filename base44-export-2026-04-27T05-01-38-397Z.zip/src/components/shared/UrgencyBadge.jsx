import React from 'react';
import { PRIORITY_CONFIG } from '@/lib/emergencyUtils';

export default function UrgencyBadge({ priority, size = 'sm' }) {
  const config = PRIORITY_CONFIG[priority] || PRIORITY_CONFIG.medium;
  const sizeClasses = size === 'lg' ? 'px-3 py-1.5 text-xs' : 'px-2 py-0.5 text-[10px]';

  return (
    <span className={`inline-flex items-center gap-1 font-bold tracking-wider rounded-full ${config.bg} ${config.text} ${config.border} border ${sizeClasses}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${priority === 'critical' ? 'bg-red-400 animate-pulse' : priority === 'high' ? 'bg-orange-400' : priority === 'medium' ? 'bg-yellow-400' : 'bg-green-400'}`} />
      {config.label}
    </span>
  );
}