import React from 'react';

export default function LivePulse({ label = 'LIVE', color = 'green' }) {
  const colorMap = {
    green: 'bg-neon-green',
    red: 'bg-neon-red',
    cyan: 'bg-neon-cyan',
    yellow: 'bg-neon-yellow',
  };
  const dotColor = colorMap[color] || colorMap.green;

  return (
    <div className="flex items-center gap-2">
      <div className="relative flex items-center justify-center w-2.5 h-2.5">
        <span className={`absolute inline-block w-full h-full rounded-full ${dotColor} opacity-60 animate-ping-slow`} />
        <span className={`relative inline-block w-2 h-2 rounded-full ${dotColor}`} />
      </div>
      <span className={`text-[10px] font-bold tracking-widest uppercase ${color === 'green' ? 'text-neon-green' : color === 'red' ? 'text-neon-red' : 'text-neon-cyan'}`}>
        {label}
      </span>
    </div>
  );
}