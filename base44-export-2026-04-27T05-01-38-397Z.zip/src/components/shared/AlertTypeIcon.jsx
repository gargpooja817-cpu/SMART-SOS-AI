import React from 'react';
import { Heart, Flame, Shield, Car, CloudLightning, AlertTriangle } from 'lucide-react';
import { ALERT_TYPE_CONFIG } from '@/lib/emergencyUtils';

const iconMap = { Heart, Flame, Shield, Car, CloudLightning, AlertTriangle };

export default function AlertTypeIcon({ type, size = 'md' }) {
  const config = ALERT_TYPE_CONFIG[type] || ALERT_TYPE_CONFIG.other;
  const Icon = iconMap[config.icon] || AlertTriangle;
  const sizeClass = size === 'lg' ? 'w-6 h-6' : size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';

  return <Icon className={`${sizeClass} ${config.color}`} />;
}