import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Navigation, Star } from 'lucide-react';
import { getDirectionsUrl } from '@/lib/overpassApi';

const TYPE_CONFIG = {
  hospital: { label: 'Hospital', color: '#FF2D55', bg: 'rgba(255,45,85,0.12)', icon: '🏥' },
  clinic:   { label: 'Clinic',   color: '#00C6FF', bg: 'rgba(0,198,255,0.12)',  icon: '🩺' },
  doctors:  { label: 'Doctor',   color: '#00C6FF', bg: 'rgba(0,198,255,0.12)',  icon: '👨⚕️' },
  pharmacy: { label: 'Pharmacy', color: '#00FF88', bg: 'rgba(0,255,136,0.12)',  icon: '💊' },
};

export default function PlaceCard({ place, isNearest, index, onFocus }) {
  const cfg = TYPE_CONFIG[place.type] || TYPE_CONFIG.hospital;

  return (
    <motion.div
      initial={{ opacity: 0, x: -16 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.04 }}
      onClick={() => onFocus(place)}
      className="rounded-2xl p-4 cursor-pointer transition-all border hover:border-white/15"
      style={{
        background: isNearest ? 'rgba(255,45,85,0.06)' : 'rgba(255,255,255,0.02)',
        border: isNearest ? '1px solid rgba(255,45,85,0.3)' : '1px solid rgba(255,255,255,0.06)',
      }}
    >
      <div className="flex items-start gap-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0"
          style={{ background: cfg.bg }}>
          {cfg.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="text-sm font-bold text-foreground truncate">{place.name}</p>
                {isNearest && (
                  <span className="text-[9px] font-black px-2 py-0.5 rounded-full shrink-0"
                    style={{ background: 'rgba(255,45,85,0.2)', color: '#FF2D55', border: '1px solid rgba(255,45,85,0.4)' }}>
                    ★ NEAREST
                  </span>
                )}
              </div>
              <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full inline-block mt-1"
                style={{ background: cfg.bg, color: cfg.color }}>
                {cfg.label}
              </span>
            </div>
            <div className="text-right shrink-0">
              <p className="text-sm font-black" style={{ color: cfg.color }}>{place.distKm} km</p>
            </div>
          </div>

          {place.address && (
            <div className="flex items-center gap-1.5 mt-2">
              <MapPin className="w-3 h-3 text-muted-foreground shrink-0" />
              <p className="text-[11px] text-muted-foreground truncate">{place.address}</p>
            </div>
          )}

          <div className="flex items-center gap-2 mt-3">
            <a
              href={getDirectionsUrl(place.lat, place.lng)}
              target="_blank"
              rel="noopener noreferrer"
              onClick={e => e.stopPropagation()}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold text-white transition-all hover:opacity-90"
              style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}
            >
              <Navigation className="w-3 h-3" /> Directions
            </a>
            {place.phone && (
              <a
                href={`tel:${place.phone}`}
                onClick={e => e.stopPropagation()}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-bold transition-all hover:bg-white/10"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: '#ccc' }}
              >
                <Phone className="w-3 h-3" /> Call
              </a>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
}