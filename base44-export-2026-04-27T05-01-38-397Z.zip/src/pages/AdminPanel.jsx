const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Users, AlertTriangle, ShieldAlert, BarChart3, Activity,
  CheckCircle, XCircle, Trash2, Eye, RefreshCw, Download, Loader2, Mail
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { formatDistanceToNow, format } from 'date-fns';
import { toast } from 'sonner';
import { analyzeEmergency, allocateResources } from '@/lib/aiEngine';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import ContactMessagesPanel from '@/components/admin/ContactMessagesPanel';

const NEON_COLORS = ['#FF2D55', '#FF6B2B', '#FFD60A', '#00FF88', '#00C6FF', '#7F00FF'];
const PRIORITY_COLORS = { critical: '#FF2D55', high: '#FF6B2B', medium: '#FFD60A', low: '#00FF88' };

/* ── Tiny Stat Card ── */
function AdminStat({ icon: StatIcon, label, value, color }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass-card rounded-2xl p-5"
    >
      <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center mb-3 ${color}`}>
        <StatIcon className="w-5 h-5" />
      </div>
      <p className="text-2xl font-grotesk font-black text-foreground">{value}</p>
      <p className="text-[10px] text-muted-foreground uppercase tracking-wider mt-0.5">{label}</p>
    </motion.div>
  );
}

/* ── Alerts Table ── */
function AlertsTable({ alerts, onResolve, onDelete }) {
  const [search, setSearch] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('all');

  const filtered = alerts.filter(a => {
    const matchSearch = !search || a.message?.toLowerCase().includes(search.toLowerCase()) || a.reporter_name?.toLowerCase().includes(search.toLowerCase());
    const matchPriority = priorityFilter === 'all' || a.priority === priorityFilter;
    return matchSearch && matchPriority;
  });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3 items-center">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Search alerts..."
          className="flex-1 min-w-[200px] bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40"
        />
        <div className="flex gap-1">
          {['all', 'critical', 'high', 'medium', 'low'].map(p => (
            <button key={p} onClick={() => setPriorityFilter(p)}
              className={`px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase transition-all ${
                priorityFilter === p ? 'bg-neon-cyan/15 text-neon-cyan border border-neon-cyan/30' : 'text-muted-foreground hover:bg-white/5'
              }`}
            >{p}</button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto rounded-2xl border border-white/[0.06]">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-white/[0.06] bg-white/[0.02]">
              {['Type', 'Message', 'Reporter', 'Priority', 'Status', 'Score', 'Time', 'Actions'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((a, i) => (
              <motion.tr
                key={a.id}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: i * 0.02 }}
                className={`border-b border-white/[0.03] hover:bg-white/[0.02] transition-colors ${a.is_fake ? 'opacity-50' : ''}`}
              >
                <td className="px-4 py-3">
                  <span className="text-base">{a.alert_type === 'fire' ? '🔥' : a.alert_type === 'medical' ? '🚑' : a.alert_type === 'crime' ? '🚨' : a.alert_type === 'accident' ? '🚗' : a.alert_type === 'natural_disaster' ? '🌊' : '⚠️'}</span>
                </td>
                <td className="px-4 py-3 max-w-[200px]">
                  <p className="truncate text-foreground/90">{a.message}</p>
                  {a.is_fake && <span className="text-[9px] text-neon-yellow">⚠️ FLAGGED</span>}
                </td>
                <td className="px-4 py-3 text-muted-foreground">{a.reporter_name || '—'}</td>
                <td className="px-4 py-3">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold"
                    style={{ background: `${PRIORITY_COLORS[a.priority]}20`, color: PRIORITY_COLORS[a.priority], border: `1px solid ${PRIORITY_COLORS[a.priority]}40` }}>
                    {a.priority?.toUpperCase()}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={`text-[10px] font-semibold capitalize ${
                    a.status === 'resolved' ? 'text-neon-green' :
                    a.status === 'pending' ? 'text-neon-yellow' :
                    a.status === 'assigned' ? 'text-neon-cyan' :
                    a.status === 'fake' ? 'text-muted-foreground' : 'text-foreground'
                  }`}>{a.status}</span>
                </td>
                <td className="px-4 py-3 font-mono text-foreground/70">{a.urgency_score ?? '—'}</td>
                <td className="px-4 py-3 text-muted-foreground">
                  {a.created_date ? formatDistanceToNow(new Date(a.created_date), { addSuffix: true }) : '—'}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    {a.status !== 'resolved' && (
                      <button onClick={() => onResolve(a)} className="p-1.5 rounded-lg hover:bg-neon-green/10 text-neon-green/60 hover:text-neon-green transition-colors" title="Resolve">
                        <CheckCircle className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button onClick={() => onDelete(a)} className="p-1.5 rounded-lg hover:bg-neon-red/10 text-muted-foreground hover:text-neon-red transition-colors" title="Delete">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && (
          <div className="text-center py-10 text-sm text-muted-foreground">No alerts found</div>
        )}
      </div>
    </div>
  );
}

/* ── Users Table ── */
function UsersTable({ users }) {
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('user');
  const [inviting, setInviting] = useState(false);

  const handleInvite = async (e) => {
    e.preventDefault();
    if (!inviteEmail.trim()) return toast.error('Email is required');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(inviteEmail.trim())) return toast.error('Enter a valid email address');
    setInviting(true);
    try {
      await db.users.inviteUser(inviteEmail.trim(), inviteRole);
      toast.success(`Invitation sent to ${inviteEmail}`);
      setInviteEmail('');
    } catch {
      toast.error('Failed to send invitation. Please try again.');
    } finally {
      setInviting(false);
    }
  };

  return (
    <div className="space-y-4">
      {/* Invite Form */}
      <form onSubmit={handleInvite} className="glass-card rounded-2xl p-4 flex flex-wrap gap-3 items-end border border-neon-cyan/10">
        <div className="flex-1 min-w-[200px]">
          <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Email Address</label>
          <input
            type="email"
            value={inviteEmail}
            onChange={e => setInviteEmail(e.target.value)}
            placeholder="user@example.com"
            required
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
          />
        </div>
        <div>
          <label className="text-[10px] text-muted-foreground uppercase tracking-wider block mb-1">Role</label>
          <select
            value={inviteRole}
            onChange={e => setInviteRole(e.target.value)}
            className="bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-foreground focus:outline-none focus:border-neon-cyan/40 transition-colors"
          >
            <option value="user">Civilian</option>
            <option value="responder">Responder</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <button type="submit" disabled={inviting}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-bold text-white disabled:opacity-50"
          style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
          {inviting ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
          {inviting ? 'Sending...' : 'Invite User'}
        </button>
      </form>

      <div className="overflow-x-auto rounded-2xl border border-white/[0.06]">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-white/[0.06] bg-white/[0.02]">
              {['User', 'Email', 'Role', 'Joined'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-[10px] text-muted-foreground uppercase tracking-wider font-semibold">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {users.map((u, i) => (
              <motion.tr key={u.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.03 }}
                className="border-b border-white/[0.03] hover:bg-white/[0.02] transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-neon-cyan/20 to-neon-purple/20 flex items-center justify-center text-sm font-bold text-neon-cyan">
                      {u.full_name?.charAt(0)?.toUpperCase() || '?'}
                    </div>
                    <span className="font-semibold text-foreground">{u.full_name || 'Unknown'}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                <td className="px-4 py-3">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold capitalize border ${
                    u.role === 'admin' ? 'bg-neon-purple/15 text-neon-purple border-neon-purple/25' :
                    u.role === 'responder' ? 'bg-neon-cyan/15 text-neon-cyan border-neon-cyan/25' :
                    'bg-white/5 text-muted-foreground border-white/10'
                  }`}>
                    {u.role || 'user'}
                  </span>
                </td>
                <td className="px-4 py-3 text-muted-foreground">
                  {u.created_date ? format(new Date(u.created_date), 'MMM d, yyyy') : '—'}
                </td>
              </motion.tr>
            ))}
            {users.length === 0 && (
              <tr><td colSpan={4} className="text-center py-8 text-sm text-muted-foreground">No users found</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ── Fake Alert Panel ── */
function FakeAlertPanel({ alerts }) {
  const flagged = alerts.filter(a => a.is_fake);
  return (
    <div className="space-y-3">
      {flagged.length === 0 ? (
        <div className="glass-card rounded-2xl p-10 text-center">
          <ShieldAlert className="w-10 h-10 text-neon-green mx-auto mb-3 opacity-50" />
          <p className="text-sm text-muted-foreground">No fake alerts detected</p>
        </div>
      ) : flagged.map((a, i) => (
        <motion.div key={a.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.05 }}
          className="glass-card rounded-2xl p-4 border border-neon-yellow/20">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold text-neon-yellow px-2 py-0.5 rounded-full bg-neon-yellow/10 border border-neon-yellow/20">⚠️ FLAGGED</span>
                <span className="text-[10px] text-muted-foreground">
                  {a.created_date ? formatDistanceToNow(new Date(a.created_date), { addSuffix: true }) : ''}
                </span>
              </div>
              <p className="text-sm text-foreground/80 mb-2">{a.message}</p>
              <p className="text-xs text-neon-yellow/80">{a.fake_reason}</p>
            </div>
            <div className="text-right shrink-0 ml-3">
              <p className="text-xs text-muted-foreground">Reporter</p>
              <p className="text-xs font-semibold text-foreground">{a.reporter_name || 'Anonymous'}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

/* ── Resource Dashboard ── */
function ResourceDashboard({ alerts, responders }) {
  const active = alerts.filter(a => ['pending', 'assigned'].includes(a.status) && !a.is_fake);
  const totalRequired = { ambulances: 0, fire_trucks: 0, police_units: 0 };
  const shortage = { ambulances: 0, fire_trucks: 0, police_units: 0 };

  active.forEach(a => {
    const ai = analyzeEmergency(a.message);
    const alloc = allocateResources(ai.category, a.priority || ai.priorityLabel, responders);
    Object.keys(totalRequired).forEach(k => {
      totalRequired[k] += alloc.required[k] || 0;
      shortage[k] += alloc.shortage[k] || 0;
    });
  });

  const available = {
    ambulances: responders.filter(r => ['paramedic', 'doctor'].includes(r.type) && r.status === 'available').length,
    fire_trucks: responders.filter(r => r.type === 'firefighter' && r.status === 'available').length,
    police_units: responders.filter(r => r.type === 'police' && r.status === 'available').length,
  };

  const resources = [
    { key: 'ambulances', icon: '🚑', label: 'Ambulances', required: totalRequired.ambulances, available: available.ambulances },
    { key: 'fire_trucks', icon: '🚒', label: 'Fire Trucks', required: totalRequired.fire_trucks, available: available.fire_trucks },
    { key: 'police_units', icon: '🚔', label: 'Police Units', required: totalRequired.police_units, available: available.police_units },
  ];

  return (
    <div className="space-y-4">
      <div className="grid sm:grid-cols-3 gap-4">
        {resources.map((r, i) => {
          const pct = r.required > 0 ? Math.round((r.available / r.required) * 100) : 100;
          const hasShortage = r.available < r.required;
          return (
            <motion.div key={r.key} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}
              className={`glass-card rounded-2xl p-5 border ${hasShortage ? 'border-neon-red/25' : 'border-neon-green/15'}`}>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <span className="text-3xl">{r.icon}</span>
                  <p className="text-sm font-bold text-foreground mt-2">{r.label}</p>
                </div>
                {hasShortage
                  ? <span className="text-[10px] font-bold text-neon-red bg-neon-red/10 border border-neon-red/20 px-2 py-0.5 rounded-full">SHORTAGE</span>
                  : <span className="text-[10px] font-bold text-neon-green bg-neon-green/10 border border-neon-green/20 px-2 py-0.5 rounded-full">OK</span>
                }
              </div>
              <div className="flex items-end justify-between mb-2">
                <div>
                  <p className="text-[10px] text-muted-foreground">Available</p>
                  <p className="text-xl font-grotesk font-black text-foreground">{r.available}</p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-muted-foreground">Required</p>
                  <p className="text-xl font-grotesk font-black" style={{ color: hasShortage ? '#FF2D55' : '#00FF88' }}>{r.required}</p>
                </div>
              </div>
              <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                <div className="h-full rounded-full transition-all duration-700"
                  style={{ width: `${Math.min(100, pct)}%`, background: hasShortage ? '#FF2D55' : '#00FF88', boxShadow: hasShortage ? '0 0 8px #FF2D55' : '0 0 8px #00FF88' }} />
              </div>
            </motion.div>
          );
        })}
      </div>

      <div className="glass-card rounded-2xl p-5">
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Active Alerts Requiring Resources</p>
        {active.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-6">No active alerts</p>
        ) : (
          <div className="space-y-2">
            {active.slice(0, 8).map(a => {
              const ai = analyzeEmergency(a.message);
              return (
                <div key={a.id} className="flex items-center justify-between glass-card rounded-xl px-4 py-2.5">
                  <div className="flex items-center gap-3">
                    <span className="text-base">{ai.icon}</span>
                    <div>
                      <p className="text-xs text-foreground/90 truncate max-w-[200px]">{a.message}</p>
                      <p className="text-[10px] text-muted-foreground capitalize">{a.priority}</p>
                    </div>
                  </div>
                  <div className="flex gap-1.5 text-[10px]">
                    {Object.entries(ai.resources).filter(([, n]) => n > 0).map(([k, n]) => (
                      <span key={k} className="bg-white/5 border border-white/8 px-2 py-0.5 rounded-lg text-muted-foreground">
                        {k === 'ambulances' ? '🚑' : k === 'fire_trucks' ? '🚒' : '🚔'} {n}
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ── Main Admin Panel ── */
export default function AdminPanel() {
  const queryClient = useQueryClient();

  const { data: alerts = [] } = useQuery({
    queryKey: ['alerts'],
    queryFn: () => db.entities.Alert.list('-created_date', 200),
    refetchInterval: 8000,
  });
  const { data: responders = [] } = useQuery({
    queryKey: ['responders'],
    queryFn: () => db.entities.Responder.list(),
    refetchInterval: 10000,
  });
  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => db.entities.User.list(),
    refetchInterval: 30000,
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['contact-messages'],
    queryFn: () => db.entities.ContactMessage.list('-created_date', 100),
    refetchInterval: 30000,
  });
  const unreadMessages = messages.filter(m => m.status === 'new').length;

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ['alerts'] });
    queryClient.invalidateQueries({ queryKey: ['responders'] });
    queryClient.invalidateQueries({ queryKey: ['users'] });
    queryClient.invalidateQueries({ queryKey: ['contact-messages'] });
    toast.success('Data refreshed');
  };

  const handleResolve = async (a) => {
    try {
      await db.entities.Alert.update(a.id, { status: 'resolved' });
      if (a.assigned_responder_id) await db.entities.Responder.update(a.assigned_responder_id, { status: 'available' });
      queryClient.invalidateQueries({ queryKey: ['alerts'] });
      toast.success('Alert resolved');
    } catch {
      toast.error('Failed to resolve alert.');
    }
  };
  const handleDelete = async (a) => {
    if (!window.confirm('Delete this alert permanently?')) return;
    try {
      await db.entities.Alert.delete(a.id);
      queryClient.invalidateQueries({ queryKey: ['alerts'] });
      toast.success('Alert deleted');
    } catch {
      toast.error('Failed to delete alert.');
    }
  };

  // Stats
  const active = alerts.filter(a => ['pending', 'assigned', 'in_progress'].includes(a.status) && !a.is_fake).length;
  const critical = alerts.filter(a => a.priority === 'critical' && a.status !== 'resolved').length;
  const flagged = alerts.filter(a => a.is_fake).length;
  const availResp = responders.filter(r => r.status === 'available').length;

  // Chart data
  const typeCounts = {};
  alerts.forEach(a => { const t = a.alert_type || 'general'; typeCounts[t] = (typeCounts[t] || 0) + 1; });
  const typeData = Object.entries(typeCounts).map(([name, value]) => ({ name: name.replace('_', ' '), value }));

  const priCounts = {};
  alerts.forEach(a => { priCounts[a.priority] = (priCounts[a.priority] || 0) + 1; });
  const priData = Object.entries(priCounts).map(([name, value]) => ({ name, value }));

  const CustomTip = ({ active, payload }) => active && payload?.length
    ? <div className="glass-strong rounded-xl px-3 py-2 text-xs border border-white/10"><p className="font-bold text-foreground">{payload[0].value}</p></div>
    : null;

  return (
    <div className="p-4 md:p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-neon-cyan animate-ping-slow" />
            <span className="text-[10px] text-neon-cyan font-bold tracking-widest uppercase">Admin Access</span>
          </div>
          <h1 className="text-2xl font-grotesk font-black text-foreground">Command Administration</h1>
          <p className="text-sm text-muted-foreground">Full system oversight & control</p>
        </div>
        <button onClick={refresh} className="flex items-center gap-2 px-4 py-2 glass-card rounded-xl text-xs font-semibold text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all">
          <RefreshCw className="w-3.5 h-3.5" /> Refresh
        </button>
      </motion.div>

      {/* Stat grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <AdminStat icon={AlertTriangle} label="Active Alerts" value={active} color="text-neon-red" />
        <AdminStat icon={Activity} label="Critical" value={critical} color="text-neon-orange" />
        <AdminStat icon={ShieldAlert} label="Flagged Fake" value={flagged} color="text-neon-yellow" />
        <AdminStat icon={Users} label="Responders Online" value={availResp} color="text-neon-cyan" />
      </div>

      {/* Charts row */}
      <div className="grid md:grid-cols-2 gap-4">
        <div className="glass-card rounded-2xl p-5">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Alerts by Type</p>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={typeData} barSize={18}>
              <XAxis dataKey="name" tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'hsl(215 20% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTip />} cursor={{ fill: 'rgba(255,255,255,0.03)' }} />
              <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                {typeData.map((_, i) => <Cell key={i} fill={NEON_COLORS[i % NEON_COLORS.length]} fillOpacity={0.85} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="glass-card rounded-2xl p-5">
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-4">Priority Split</p>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={priData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={4} dataKey="value">
                {priData.map((e, i) => <Cell key={i} fill={PRIORITY_COLORS[e.name] || '#888'} />)}
              </Pie>
              <Tooltip content={<CustomTip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs defaultValue="alerts">
        <TabsList className="glass border border-white/10 p-1 flex flex-wrap gap-1">
          {[
            { v: 'alerts', icon: AlertTriangle, label: 'All Alerts', badge: alerts.length },
            { v: 'users', icon: Users, label: 'Users', badge: users.length },
            { v: 'fake', icon: ShieldAlert, label: 'Fake Alerts', badge: flagged },
            { v: 'resources', icon: Activity, label: 'Resources' },
            { v: 'messages', icon: Mail, label: 'Messages', badge: unreadMessages },
          ].map(({ v, icon: TabIcon, label, badge }) => (
            <TabsTrigger key={v} value={v} className="text-xs data-[state=active]:bg-white/10 gap-1.5">
              <TabIcon className="w-3.5 h-3.5" /> {label}
              {badge > 0 && <span className="px-1.5 py-0.5 rounded-full bg-neon-cyan/20 text-neon-cyan text-[9px] font-bold">{badge}</span>}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="alerts" className="mt-4">
          <AlertsTable alerts={alerts} onResolve={handleResolve} onDelete={handleDelete} />
        </TabsContent>
        <TabsContent value="users" className="mt-4">
          <UsersTable users={users} />
        </TabsContent>
        <TabsContent value="fake" className="mt-4">
          <FakeAlertPanel alerts={alerts} />
        </TabsContent>
        <TabsContent value="resources" className="mt-4">
          <ResourceDashboard alerts={alerts} responders={responders} />
        </TabsContent>
        <TabsContent value="messages" className="mt-4">
          <ContactMessagesPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}