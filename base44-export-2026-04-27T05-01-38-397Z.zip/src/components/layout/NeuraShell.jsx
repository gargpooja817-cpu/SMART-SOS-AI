/**
 * Authenticated shell layout — wraps all protected pages
 */
import React from 'react';
import { Outlet } from 'react-router-dom';
import NeuraNavbar from './NeuraNavbar';
import MobileBottomNav from './MobileBottomNav';
import AuthGuard from '@/components/auth/AuthGuard';
import AppFooter from '@/components/shared/AppFooter';

export default function NeuraShell({ requiredRole = null }) {
  return (
    <AuthGuard requiredRole={requiredRole}>
      <div className="min-h-screen bg-background flex flex-col">
        <NeuraNavbar />
        <main className="pt-14 pb-20 md:pb-6 p-4 md:p-6 max-w-[1600px] mx-auto w-full flex-1">
          <Outlet />
        </main>
        <div className="hidden md:block">
          <AppFooter />
        </div>
        <MobileBottomNav />
      </div>
    </AuthGuard>
  );
}