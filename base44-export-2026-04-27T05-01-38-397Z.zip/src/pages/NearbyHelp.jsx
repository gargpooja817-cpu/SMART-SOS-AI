import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Zap, MapPin, RefreshCw, AlertTriangle, Phone, X, Loader2, WifiOff, Radio
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { fetchNearbyMedical, getCachedPlaces, haversineKm } from '@/lib/overpassApi';
import PlaceCard from '@/components/nearbyhelp/PlaceCard';
import FilterBar from '@/components/nearbyhelp/FilterBar';
import EmergencyQuickActions from '@/components/nearbyhelp/EmergencyQuickActions';
import NearbyMap from '@/components/nearbyhelp/NearbyMap';

const RADIUS = 3000; // 3 km

export default function NearbyHelp() {
  const [userLoc, setUserLoc] = useState(null);
  const [locError, setLocError] = useState(null);
  const [places, setPlaces] = useState([]);
  const [loading, setLoading] = useState(false);
  const [apiError, setApiError] = useState(null);
  const [filter, setFilter] = useState('all');
  const [focusedPlace, setFocusedPlace] = useState(null);
  const [sosActive, setSosActive] = useState(false);
  const [offline, setOffline] = useState(!navigator.onLine);

  // Detect online status
  useEffect(() => {
    const on = () => setOffline(false);
    const off = () => setOffline(true);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => { window.removeEventListener('online', on); window.removeEventListener('offline', off); };
  }, []);

  const fetchPlaces = useCallback(async (lat, lng) => {
    setLoading(true);
    setApiError(null);
    try {
      const results = await fetchNearbyMedical(lat, lng, RADIUS);
      setPlaces(results);
    } catch {
      setApiError('Unable to load nearby places. Showing cached data.');
      const cached = getCachedPlaces();
      if (cached) setPlaces(cached.places);
    } finally {
      setLoading(false);
    }
  }, []);

  const getLocation = useCallback(() => {
    setLocError(null);
    if (!navigator.geolocation) {
      setLocError('Geolocation is not supported by your browser.');
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy };
        setUserLoc(loc);
        fetchPlaces(loc.lat, loc.lng);
      },
      () => {
        setLocError('Location access denied. Please enable location permissions and refresh.');
        // Try to show cached
        const cached = getCachedPlaces();
        if (cached) { setPlaces(cached.places); setUserLoc({ lat: cached.lat, lng: cached.lng }); }
      },
      { enableHighAccuracy: true, timeout: 12000 }
    );
  }, [fetchPlaces]);

  // Auto-fetch on mount
  useEffect(() => { getLocation(); }, []);

  const handleSOS = () => {
    setSosActive(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const nearest = places.find(p => p.type === 'hospital') || places[0];

  const filtered = filter === 'all'
    ? places
    : places.filter(p => p.type === filter || (filter === 'clinic' && p.type === 'doctors'));

  return (
    <div className="min-h-screen" style={{ background: sosActive ? 'rgba(40,0,10,0.98)' : undefined }}>
      {/* ── NAVBAR ── */}
      <nav className="fixed top-0 inset-x-0 z-50 h-14 flex items-center"
        style={{ background: sosActive ? 'rgba(60,0,0,0.97)' : 'rgba(8,11,22,0.9)', backdropFilter: 'blur(30px)', borderBottom: `1px solid ${sosActive ? 'rgba(255,45,85,0.3)' : 'rgba(255,255,255,0.05)'}` }}>
        <div className="max-w-7xl mx-auto px-4 w-full flex items-center justify-between">
          <Link to="/dashboard" className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #00C6FF, #7F00FF)' }}>
              <Radio className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-grotesk font-black text-sm text-gradient-neon">NearbyHelp</span>
          </Link>

          <div className="flex items-center gap-2">
            {offline && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold text-neon-yellow" style={{ background: 'rgba(255,214,10,0.12)', border: '1px solid rgba(255,214,10,0.3)' }}>
                <WifiOff className="w-3 h-3" /> Offline
              </div>
            )}
            {userLoc && (
              <button onClick={() => fetchPlaces(userLoc.lat, userLoc.lng)} disabled={loading}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-muted-foreground hover:text-foreground transition-colors"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.08)' }}>
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
              </button>
            )}
          </div>
        </div>
      </nav>

      <div className="pt-14 max-w-7xl mx-auto px-4 py-4 md:py-6">
        {/* ── SOS BANNER ── */}
        <AnimatePresence>
          {sosActive && (
            <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              className="mb-4 rounded-2xl p-4 flex items-center justify-between"
              style={{ background: 'rgba(255,45,85,0.15)', border: '1px solid rgba(255,45,85,0.4)', boxShadow: '0 0 40px rgba(255,45,85,0.2)' }}>
              <div className="flex items-center gap-3">
                <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ duration: 1, repeat: Infinity }}
                  className="w-10 h-10 rounded-full flex items-center justify-center font-black text-base text-white"
                  style={{ background: '#FF2D55', boxShadow: '0 0 20px rgba(255,45,85,0.6)' }}>
                  SOS
                </motion.div>
                <div>
                  <p className="text-sm font-black text-neon-red">EMERGENCY MODE ACTIVE</p>
                  <p className="text-xs text-muted-foreground">Showing nearest medical help</p>
                </div>
              </div>
              <button onClick={() => setSosActive(false)} className="p-2 rounded-xl hover:bg-white/10 transition-colors">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* ── ERRORS ── */}
        {locError && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="mb-4 rounded-2xl p-4 flex items-start gap-3"
            style={{ background: 'rgba(255,45,85,0.08)', border: '1px solid rgba(255,45,85,0.25)' }}>
            <AlertTriangle className="w-5 h-5 text-neon-red shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-neon-red">{locError}</p>
              <button onClick={getLocation} className="mt-2 text-xs font-bold text-neon-cyan underline">Try again</button>
            </div>
          </motion.div>
        )}

        {apiError && (
          <div className="mb-4 rounded-2xl p-3 flex items-center gap-2 text-xs text-neon-yellow"
            style={{ background: 'rgba(255,214,10,0.08)', border: '1px solid rgba(255,214,10,0.2)' }}>
            <WifiOff className="w-4 h-4 shrink-0" /> {apiError}
          </div>
        )}

        {/* ── NEAREST HOSPITAL HIGHLIGHT ── */}
        {(sosActive || nearest) && nearest && (
          <motion.div initial={{ opacity: 0, scale: 0.97 }} animate={{ opacity: 1, scale: 1 }}
            className="mb-4 rounded-2xl p-4 flex items-center justify-between gap-4"
            style={{ background: 'rgba(255,45,85,0.08)', border: '1px solid rgba(255,45,85,0.3)' }}>
            <div className="flex items-center gap-3">
              <div className="text-3xl">🏥</div>
              <div>
                <p className="text-[10px] font-black text-neon-red uppercase tracking-wider mb-0.5">Nearest Medical Facility</p>
                <p className="text-base font-black text-foreground">{nearest.name}</p>
                <p className="text-xs text-muted-foreground capitalize">{nearest.type} · <span className="font-bold text-neon-red">{nearest.distKm} km away</span></p>
              </div>
            </div>
            <a href={`https://www.google.com/maps/dir/?api=1&destination=${nearest.lat},${nearest.lng}`}
              target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-xs text-white shrink-0"
              style={{ background: 'linear-gradient(135deg,#FF2D55,#FF6B2B)', boxShadow: '0 0 20px rgba(255,45,85,0.4)' }}>
              🧭 Go Now
            </a>
          </motion.div>
        )}

        {/* ── QUICK CALL ACTIONS ── */}
        {sosActive && (
          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="mb-4">
            <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold mb-2">Quick Call</p>
            <EmergencyQuickActions />
          </motion.div>
        )}

        {/* ── MAIN GRID ── */}
        <div className="grid lg:grid-cols-5 gap-4">
          {/* LEFT — List */}
          <div className="lg:col-span-2 space-y-3">
            {/* Header + SOS trigger */}
            <div className="flex items-center justify-between gap-3">
              <div>
                {userLoc ? (
                  <div className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-neon-cyan" />
                    <span className="text-xs text-muted-foreground">
                      {userLoc.lat.toFixed(4)}, {userLoc.lng.toFixed(4)}
                    </span>
                  </div>
                ) : (
                  <span className="text-xs text-muted-foreground">Getting location…</span>
                )}
              </div>
              {!sosActive && (
                <motion.button
                  onClick={handleSOS}
                  whileHover={{ scale: 1.06 }}
                  whileTap={{ scale: 0.94 }}
                  className="flex items-center gap-2 px-4 py-2 rounded-xl font-black text-sm text-white"
                  style={{ background: 'linear-gradient(135deg,#FF2D55,#FF6B2B)', boxShadow: '0 0 20px rgba(255,45,85,0.4)' }}
                >
                  <Zap className="w-4 h-4" /> SOS
                </motion.button>
              )}
            </div>

            {/* Filter */}
            <FilterBar active={filter} onChange={setFilter} total={filtered.length} />

            {/* Places list */}
            <div className="space-y-2 max-h-[60vh] overflow-y-auto pr-1">
              {loading && places.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-16 text-muted-foreground">
                  <Loader2 className="w-8 h-8 animate-spin text-neon-cyan" />
                  <p className="text-sm">Finding nearby medical facilities…</p>
                </div>
              ) : !locError && places.length === 0 && !loading ? (
                <div className="text-center py-12">
                  <p className="text-sm text-muted-foreground">No places found within {RADIUS / 1000} km.</p>
                  <button onClick={getLocation} className="mt-3 text-xs text-neon-cyan font-bold underline">Retry</button>
                </div>
              ) : (
                filtered.map((place, i) => (
                  <PlaceCard
                    key={place.id}
                    place={place}
                    isNearest={place.id === nearest?.id}
                    index={i}
                    onFocus={setFocusedPlace}
                  />
                ))
              )}
            </div>
          </div>

          {/* RIGHT — Map */}
          <div className="lg:col-span-3" style={{ height: 'calc(100vh - 140px)', minHeight: 400 }}>
            <div className="w-full h-full rounded-2xl overflow-hidden" style={{ border: sosActive ? '1px solid rgba(255,45,85,0.3)' : '1px solid rgba(255,255,255,0.06)' }}>
              {!userLoc && !locError ? (
                <div className="w-full h-full flex flex-col items-center justify-center gap-4"
                  style={{ background: 'rgba(255,255,255,0.02)' }}>
                  <Loader2 className="w-8 h-8 animate-spin text-neon-cyan" />
                  <p className="text-sm text-muted-foreground">Acquiring location…</p>
                </div>
              ) : locError && !userLoc ? (
                <div className="w-full h-full flex flex-col items-center justify-center gap-4 p-8 text-center"
                  style={{ background: 'rgba(255,255,255,0.02)' }}>
                  <AlertTriangle className="w-10 h-10 text-neon-red opacity-50" />
                  <p className="text-sm text-muted-foreground">Map unavailable — location access is required.</p>
                  <button onClick={getLocation}
                    className="px-4 py-2 rounded-xl text-xs font-bold text-white"
                    style={{ background: 'linear-gradient(135deg,#00C6FF,#7F00FF)' }}>
                    Allow Location
                  </button>
                </div>
              ) : (
                <NearbyMap
                  userLoc={userLoc}
                  places={filtered}
                  focusedPlace={focusedPlace}
                  nearestId={nearest?.id}
                />
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}