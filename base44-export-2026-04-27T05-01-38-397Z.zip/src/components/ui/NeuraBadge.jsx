import React from 'react';
import { PRIORITY_CONFIG } from '@/lib/aiEngine';

export default function NeuraBadge({ priority, size = 'sm', animate = false }) {
  const cfg = PRIORITY_CONFIG[priority] || PRIORITY_CONFIG.low;
  const sizeClass = size === 'lg' ? 'px-3 py-1 text-xs tracking-widest' : 'px-2 py-0.5 text-[10px] tracking-wider';

  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-bold uppercase ${cfg.bg} ${cfg.text} border ${cfg.border} ${sizeClass}`}>
      <span className={`inline-block w-1.5 h-1.5 rounded-full ${cfg.dot} ${animate && priority === 'critical' ? 'animate-ping-slow' : ''}`} />
      {cfg.label}
    </span>
  );
}