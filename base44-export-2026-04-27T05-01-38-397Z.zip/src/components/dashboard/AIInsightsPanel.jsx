import React, { useMemo } from 'react';
import { motion } from 'framer-motion';
import { Brain, TrendingUp, AlertTriangle, Clock, Zap, Target, ChevronRight } from 'lucide-react';
import { analyzeEmergency } from '@/lib/aiEngine';
import { formatDistanceToNow } from 'date-fns';

function InsightCard({ icon: IconComp, title, value, sub, color, delay = 0 }) {
  const Icon = IconComp;
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay }}
      className="glass-card rounded-2xl p-4 border border-white/[0.05] hover:border-white/10 transition-colors group">
      <div className={`w-8 h-8 rounded-xl flex items-center justify-center mb-3 ${color} bg-white/5`}>
        <Icon className="w-4 h-4" />
      </div>
      <p className="text-lg font-grotesk font-black text-foreground">{value}</p>
      <p className="text-xs font-semibold text-foreground/70 mt-0.5">{title}</p>
      {sub && <p className="text-[10px] text-muted-foreground mt-1">{sub}</p>}
    </motion.div>
  );
}

export default function AIInsightsPanel({ alerts = [], responders = [] }) {
  const insights = useMemo(() => {
    const recent = alerts.slice(0, 50);
    const active = recent.filter(a => !['resolved', 'fake'].includes(a.status));
    const resolved = recent.filter(a => a.status === 'resolved');
    const critical = recent.filter(a => a.priority === 'critical' && a.status !== 'resolved');

    // Most common type
    const typeCounts = {};
    recent.forEach(a => { typeCounts[a.alert_type || 'general'] = (typeCounts[a.alert_type] || 0) + 1; });
    const topType = Object.entries(typeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || 'N/A';

    // Avg urgency
    const scored = recent.filter(a => a.urgency_score);
    const avgUrgency = scored.length > 0 ? Math.round(scored.reduce((s, a) => s + a.urgency_score, 0) / scored.length) : 0;

    // Resolution rate
    const resRate = recent.length > 0 ? Math.round((resolved.length / recent.length) * 100) : 0;

    // Peak hour detection
    const hourCounts = {};
    recent.forEach(a => {
      if (a.created_date) {
        const h = new Date(a.created_date).getHours();
        hourCounts[h] = (hourCounts[h] || 0) + 1;
      }
    });
    const peakHour = Object.entries(hourCounts).sort((a, b) => b[1] - a[1])[0]?.[0];
    const peakLabel = peakHour !== undefined ? `${peakHour}:00–${(+peakHour + 1) % 24}:00` : 'N/A';

    // AI recommendations
    const recs = [];
    if (critical.length > 2) recs.push({ text: `${critical.length} critical alerts need immediate attention`, type: 'urgent', icon: AlertTriangle });
    if (resRate < 50) recs.push({ text: 'Resolution rate is below 50% — consider adding responders', type: 'warning', icon: TrendingUp });
    if (responders.filter(r => r.status === 'available').length < active.length) recs.push({ text: 'Active alerts outnumber available responders', type: 'warning', icon: Target });
    if (recs.length === 0) recs.push({ text: 'System operating within normal parameters', type: 'ok', icon: Zap });
    if (peakHour !== undefined) recs.push({ text: `Peak activity detected at ${peakLabel}`, type: 'info', icon: Clock });

    return { active: active.length, resRate, avgUrgency, topType, peakLabel, recs };
  }, [alerts, responders]);

  const recColors = { urgent: 'text-neon-red border-neon-red/20 bg-neon-red/5', warning: 'text-neon-yellow border-neon-yellow/20 bg-neon-yellow/5', ok: 'text-neon-green border-neon-green/20 bg-neon-green/5', info: 'text-neon-cyan border-neon-cyan/20 bg-neon-cyan/5' };

  return (
    <div className="glass-card rounded-2xl p-5 border border-white/[0.06] space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: 'linear-gradient(135deg, rgba(0,198,255,0.2), rgba(127,0,255,0.2))' }}>
          <Brain className="w-4 h-4 text-neon-cyan" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-foreground">AI Insights</h3>
          <p className="text-[10px] text-muted-foreground">Live pattern analysis</p>
        </div>
        <div className="ml-auto flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-neon-cyan animate-ping-slow" />
          <span className="text-[9px] text-neon-cyan font-bold uppercase tracking-wider">Active</span>
        </div>
      </div>

      {/* Mini stats grid */}
      <div className="grid grid-cols-2 gap-2">
        <InsightCard icon={AlertTriangle} title="Active Incidents" value={insights.active} sub="Pending or assigned" color="text-neon-red" delay={0} />
        <InsightCard icon={TrendingUp} title="Resolution Rate" value={`${insights.resRate}%`} sub="Last 50 alerts" color="text-neon-green" delay={0.05} />
        <InsightCard icon={Zap} title="Avg Urgency" value={`${insights.avgUrgency}/100`} sub="AI computed score" color="text-neon-yellow" delay={0.1} />
        <InsightCard icon={Clock} title="Peak Hour" value={insights.peakLabel} sub="Most active window" color="text-neon-purple" delay={0.15} />
      </div>

      {/* AI Recommendations */}
      <div>
        <p className="text-[10px] text-muted-foreground uppercase tracking-wider font-semibold mb-2">AI Recommendations</p>
        <div className="space-y-2">
          {insights.recs.map((rec, i) => (
            <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.05 }}
              className={`flex items-start gap-2.5 px-3 py-2.5 rounded-xl border text-xs ${recColors[rec.type]}`}>
              <rec.icon className="w-3.5 h-3.5 shrink-0 mt-0.5" />
              <span className="leading-relaxed">{rec.text}</span>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Top alert type */}
      {insights.topType !== 'N/A' && (
        <div className="flex items-center justify-between px-3 py-2.5 rounded-xl" style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)' }}>
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Most Common Type</span>
          <span className="text-xs font-bold text-neon-cyan capitalize">{insights.topType.replace('_', ' ')}</span>
        </div>
      )}
    </div>
  );
}