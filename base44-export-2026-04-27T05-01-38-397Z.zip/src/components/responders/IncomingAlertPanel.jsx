const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, XCircle, MapPin, Clock, User, Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

import { format } from 'date-fns';
import UrgencyBadge from '@/components/shared/UrgencyBadge';
import AlertTypeIcon from '@/components/shared/AlertTypeIcon';
import { findBestResponder } from '@/lib/emergencyUtils';
import { toast } from 'sonner';

export default function IncomingAlertPanel({ alerts = [], responders = [], onUpdate }) {
  const [assigning, setAssigning] = useState(null);
  const [selectedResponder, setSelectedResponder] = useState({});

  const pendingAlerts = alerts.filter(a => a.status === 'pending' && !a.is_fake);

  const handleAssign = async (alert) => {
    const responderId = selectedResponder[alert.id];
    const responder = responders.find(r => r.id === responderId);

    if (!responder) {
      const best = findBestResponder(responders, alert.alert_type, alert.latitude, alert.longitude);
      if (!best) {
        toast.error('No available responders');
        return;
      }
      setAssigning(alert.id);
      await db.entities.Alert.update(alert.id, {
        status: 'assigned',
        assigned_responder_id: best.id,
        assigned_responder_name: best.name
      });
      await db.entities.Responder.update(best.id, { status: 'busy' });
      toast.success(`Auto-assigned to ${best.name}`);
    } else {
      setAssigning(alert.id);
      await db.entities.Alert.update(alert.id, {
        status: 'assigned',
        assigned_responder_id: responder.id,
        assigned_responder_name: responder.name
      });
      await db.entities.Responder.update(responder.id, { status: 'busy' });
      toast.success(`Assigned to ${responder.name}`);
    }

    setAssigning(null);
    if (onUpdate) onUpdate();
  };

  const handleResolve = async (alert) => {
    setAssigning(alert.id);
    await db.entities.Alert.update(alert.id, { status: 'resolved' });
    if (alert.assigned_responder_id) {
      await db.entities.Responder.update(alert.assigned_responder_id, { status: 'available' });
    }
    toast.success('Alert resolved');
    setAssigning(null);
    if (onUpdate) onUpdate();
  };

  if (pendingAlerts.length === 0) {
    return (
      <div className="glass rounded-2xl p-8 text-center">
        <CheckCircle className="w-10 h-10 text-green-400 mx-auto mb-3 opacity-40" />
        <p className="text-sm text-muted-foreground">No pending alerts</p>
        <p className="text-xs text-muted-foreground/60 mt-1">All caught up!</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <AnimatePresence>
        {pendingAlerts.map((alert, index) => (
          <motion.div
            key={alert.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ delay: index * 0.05 }}
            className={`glass rounded-2xl p-5 border-l-4 ${
              alert.priority === 'critical' ? 'border-l-red-500' :
              alert.priority === 'high' ? 'border-l-orange-500' :
              alert.priority === 'medium' ? 'border-l-yellow-500' : 'border-l-green-500'
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <AlertTypeIcon type={alert.alert_type} />
                <UrgencyBadge priority={alert.priority} size="lg" />
                <span className="text-xs text-muted-foreground font-mono">
                  Score: {alert.urgency_score}/100
                </span>
              </div>
              <span className="text-xs text-muted-foreground flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {alert.created_date ? format(new Date(alert.created_date), 'h:mm a') : ''}
              </span>
            </div>

            <p className="text-sm text-foreground mb-2">{alert.message}</p>

            <div className="flex items-center gap-4 text-xs text-muted-foreground mb-4">
              {alert.reporter_name && (
                <span className="flex items-center gap-1"><User className="w-3 h-3" /> {alert.reporter_name}</span>
              )}
              {alert.address && (
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {alert.address}</span>
              )}
            </div>

            <div className="flex items-center gap-2">
              <Select
                value={selectedResponder[alert.id] || ''}
                onValueChange={(v) => setSelectedResponder(prev => ({ ...prev, [alert.id]: v }))}
              >
                <SelectTrigger className="flex-1 bg-white/5 border-white/10 h-9 text-xs">
                  <SelectValue placeholder="Auto-assign best match" />
                </SelectTrigger>
                <SelectContent>
                  {responders.filter(r => r.status === 'available').map(r => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name} ({r.type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                size="sm"
                onClick={() => handleAssign(alert)}
                disabled={assigning === alert.id}
                className="bg-blue-500/20 text-blue-400 hover:bg-blue-500/30 border border-blue-500/20 h-9"
              >
                {assigning === alert.id ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Assign'}
              </Button>

              <Button
                size="sm"
                onClick={() => handleResolve(alert)}
                disabled={assigning === alert.id}
                className="bg-green-500/20 text-green-400 hover:bg-green-500/30 border border-green-500/20 h-9"
              >
                Resolve
              </Button>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}