/**
 * Full-screen Emergency Mode overlay — activates when SOS is sent
 */
import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, MapPin, Phone, Navigation, Clock, Users, Shield, AlertTriangle, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getLastKnownLocation, subscribeLocation } from '@/lib/locationStore';
import { getMapsLink } from '@/lib/placesApi';

export default function EmergencyMode({ alert, onDismiss }) {
  const [location, setLocation] = useState(getLastKnownLocation());
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const unsub = subscribeLocation(pos => setLocation(pos));
    const timer = setInterval(() => setElapsed(s => s + 1), 1000);
    return () => { unsub(); clearInterval(timer); };
  }, []);

  const formatElapsed = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[9999] flex flex-col"
      style={{ background: 'rgba(8, 4, 8, 0.97)', backdropFilter: 'blur(20px)' }}
    >
      {/* Animated red border pulse */}
      <motion.div className="absolute inset-0 border-2 border-neon-red rounded-none pointer-events-none"
        animate={{ opacity: [0.3, 0.8, 0.3] }} transition={{ duration: 1.5, repeat: Infinity }} />

      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-neon-red/20">
        <motion.div className="flex items-center gap-2"
          animate={{ opacity: [1, 0.5, 1] }} transition={{ duration: 1, repeat: Infinity }}>
          <div className="w-3 h-3 rounded-full bg-neon-red" style={{ boxShadow: '0 0 12px #FF2D55' }} />
          <span className="text-neon-red font-black text-sm uppercase tracking-widest">Emergency Active</span>
        </motion.div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-neon-red/80 text-sm font-mono font-bold">
            <Clock className="w-3.5 h-3.5" /> {formatElapsed(elapsed)}
          </div>
          <button onClick={onDismiss} className="p-1.5 rounded-lg hover:bg-white/10 transition-colors text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-4 max-w-lg mx-auto w-full">
        {/* SOS indicator */}
        <div className="flex flex-col items-center py-6">
          <div className="relative">
            {[1, 2, 3].map(i => (
              <motion.div key={i} className="absolute inset-0 rounded-full border border-neon-red"
                animate={{ scale: [1, 1 + i * 0.5], opacity: [0.6, 0] }}
                transition={{ duration: 2, delay: i * 0.5, repeat: Infinity }} />
            ))}
            <motion.div
              animate={{ boxShadow: ['0 0 40px rgba(255,45,85,0.6)', '0 0 80px rgba(255,45,85,0.9)', '0 0 40px rgba(255,45,85,0.6)'] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-28 h-28 rounded-full flex items-center justify-center"
              style={{ background: 'linear-gradient(135deg, #FF2D55, #FF6B2B)' }}>
              <span className="text-4xl font-grotesk font-black text-white">SOS</span>
            </motion.div>
          </div>
          <p className="mt-6 text-sm text-muted-foreground">Help is on the way</p>
          {alert?.assigned_responder_name && (
            <p className="text-xs text-neon-cyan mt-1 font-semibold">Assigned: {alert.assigned_responder_name}</p>
          )}
        </div>

        {/* Alert info */}
        {alert && (
          <div className="rounded-2xl p-4 border border-neon-red/20 bg-neon-red/5 space-y-2">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-neon-red" />
              <span className="text-xs font-bold text-neon-red uppercase tracking-wider">Alert Details</span>
            </div>
            <p className="text-sm text-foreground">{alert.message}</p>
            <div className="flex flex-wrap gap-x-4 gap-y-1 text-[10px] text-muted-foreground">
              <span>Type: <span className="text-foreground capitalize">{alert.alert_type}</span></span>
              <span>Priority: <span className="text-neon-red font-bold uppercase">{alert.priority}</span></span>
              <span>Status: <span className="text-neon-yellow capitalize">{alert.status}</span></span>
            </div>
          </div>
        )}

        {/* Location */}
        {location && (
          <div className="rounded-2xl p-4 border border-neon-cyan/20 bg-neon-cyan/5">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-neon-cyan" />
                <span className="text-xs font-bold text-neon-cyan uppercase tracking-wider">Live Location</span>
              </div>
              <motion.div className="w-2 h-2 rounded-full bg-neon-green"
                animate={{ opacity: [1, 0.3, 1] }} transition={{ duration: 1, repeat: Infinity }}
                style={{ boxShadow: '0 0 8px #00FF88' }} />
            </div>
            <p className="text-xs font-mono text-foreground/80 mb-3">
              {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
              {location.accuracy && <span className="text-muted-foreground ml-2">(±{Math.round(location.accuracy)}m)</span>}
            </p>
            <a href={getMapsLink(location.lat, location.lng)} target="_blank" rel="noreferrer"
              className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-neon-cyan border border-neon-cyan/25 bg-neon-cyan/10 hover:bg-neon-cyan/15 transition-colors w-fit">
              <ExternalLink className="w-3 h-3" /> Open in Maps
            </a>
          </div>
        )}

        {/* Quick calls */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: 'Ambulance', icon: '🚑', number: '911', color: '#FF2D55' },
            { label: 'Police', icon: '🚔', number: '911', color: '#7F00FF' },
            { label: 'Fire', icon: '🚒', number: '911', color: '#FF6B2B' },
          ].map(c => (
            <a key={c.label} href={`tel:${c.number}`}
              className="flex flex-col items-center gap-2 p-4 rounded-2xl border text-center active:scale-95 transition-transform"
              style={{ background: `${c.color}15`, border: `1px solid ${c.color}35`, boxShadow: `0 0 20px ${c.color}10` }}>
              <span className="text-3xl">{c.icon}</span>
              <div>
                <p className="text-xs font-black text-foreground">{c.label}</p>
                <p className="text-lg font-black" style={{ color: c.color }}>{c.number}</p>
              </div>
            </a>
          ))}
        </div>

        {/* Find nearby hospitals */}
        <Link to="/nearby" onClick={onDismiss}>
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.97 }}
            className="flex items-center justify-between p-4 rounded-2xl border border-neon-green/25 bg-neon-green/5 cursor-pointer hover:bg-neon-green/8 transition-colors">
            <div className="flex items-center gap-3">
              <span className="text-2xl">🏥</span>
              <div>
                <p className="text-sm font-bold text-foreground">Find Nearest Hospital</p>
                <p className="text-[10px] text-muted-foreground">View map with nearby medical facilities</p>
              </div>
            </div>
            <Navigation className="w-4 h-4 text-neon-green" />
          </motion.div>
        </Link>

        {/* Dismiss */}
        <button onClick={onDismiss}
          className="w-full py-3.5 rounded-2xl text-sm font-semibold text-muted-foreground hover:text-foreground border border-white/10 hover:bg-white/5 transition-all">
          Dismiss Emergency Mode
        </button>
      </div>
    </motion.div>
  );
}